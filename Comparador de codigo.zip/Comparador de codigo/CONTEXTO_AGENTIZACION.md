# Contexto para Claude Code: Comparador de implementación dentro del programa de agentización

> Leer este documento antes de diseñar o modificar código. Define **para qué existe** el comparador, **dónde encaja** y **qué no puede hacer**.
> Clasificación: uso interno. No contiene datos de modelos, credenciales, rutas personales ni correos.

---

## 1. Qué se está construyendo

Una **herramienta de comparación de implementación** que verifica si un modelo implementado (Python, SAS, Databricks) reproduce la lógica y los parámetros de su referencia metodológica (Excel, documentación Word/PDF, código de referencia).

No es un agente autónomo. Es una **herramienta con contrato** que consumirán uno o varios agentes del área.

```text
Primera línea pulsa "Validar"
        │
        ▼
Agente validador de implementación (orquestador)
        │  selecciona herramientas según tipología, tier y controles
        ├── Herramienta: revisor de controles de primera línea
        ├── Herramienta: COMPARADOR DE IMPLEMENTACIÓN   ← este repositorio
        ├── Herramienta: calidad y trazabilidad de datos
        └── Herramienta: generador de entregables
        │
        ▼
Validador humano revisa, corrige y aprueba
```

---

## 2. Contexto organizacional

### 2.1 Problema que se ataca

- La validación de implementación de un modelo Tier 1 toma alrededor de **66 horas (8.25 días)**.
- Las actividades de mayor esfuerzo son: análisis funcional del flujo del modelo, **comparación de código y objetos**, y preparación de resultados.
- La comparación puede involucrar SAS, Python, Excel, Databricks y GitHub, con la versión metodológica y la productiva en lenguajes distintos.

### 2.2 Plan de agentización del ámbito de implementación

Primera ola de cuatro agentes, con meta de pasar de **66 h a 39 h** (≈ -41 %):

| Agente | Etapa del flujo | Tipo |
|---|---|---|
| Revisor de controles de primera línea | Controles de 1ra línea | Adaptación |
| **Comparador SAS ↔ Databricks ↔ Excel ↔ Python** | Controles de 2da línea | Desarrollo nuevo |
| Revisor de calidad y trazabilidad de datos | Controles de 2da línea | Desarrollo nuevo |
| Generador de entregables de validación | Presentación de resultados | Adaptación |

Requisito explícito para el comparador: **no limitarse a comparar dos scripts**. Debe recorrer programas completos, carpetas, funciones, archivos de entrada y cambios implementados, y determinar si la lógica y los cálculos son equivalentes aunque estén en lenguajes distintos.

Evolución prevista:
- Un **agente orquestador** que coordine los agentes especializados desde un solo flujo.
- Reutilización para **monitoreo postimplementación**: verificar periódicamente que el código no cambió, que las fuentes siguen consistentes y que el modelo sigue funcionando.
- Generalización a otros ámbitos (riesgo financiero, no financiero, subsidiarias) cuando sea viable.
- Evitar soluciones duplicadas entre equipos: diseñar componentes **genéricos y personalizables**.

### 2.3 Principio de arquitectura del área

> **Centralizar las herramientas, no los agentes.**

- Cada integración se publica **una sola vez** en un catálogo compartido.
- Cada herramienta tiene un **contrato claro**: qué recibe, qué devuelve, qué permisos exige y quién la mantiene.
- El agente **declara** las herramientas que necesita y toma solo esas.
- Lo que se centraliza es la plomería: credenciales, permisos, registro de uso y control de costo. No la lógica de cada agente.
- Indicadores: tiempo para lanzar un agente nuevo, porcentaje de agentes sobre la base común, integraciones duplicadas, **costo por tarea**, tareas resueltas sin intervención.

### 2.4 Framework de construcción de agentes del área

Cuatro planos que corren en paralelo durante seis etapas:

| Plano | Pregunta |
|---|---|
| 1. Descomposición del dominio | ¿Cómo partimos la validación en piezas construibles sin que la casuística explote? |
| 2. Construcción | ¿Cómo se especifica e implementa cada pieza, revisable y versionada? |
| 3. Verificación | ¿Cómo probamos con números que el agente valida bien? |
| 4. Gobierno | ¿Cómo lo hacemos auditable, con guardrails, human-in-the-loop y validación independiente? |

**Autonomía graduada.** Nunca se pasa de cero a autónomo:

1. **Sombra:** corre en paralelo al validador humano; nadie fuera del equipo ve la salida. Salida: concordancia sostenida.
2. **Copiloto:** la salida es insumo del validador, que revisa el 100 % de los hallazgos. Salida: tasa de corrección humana bajo umbral.
3. **Autónomo con excepción:** cierra controles determinísticos y de juicio de baja severidad; el resto escala a humano.

El comparador debe diseñarse **desde el día uno** para soportar las tres etapas (registrar concordancia con el humano, exponer evidencia para revisión, marcar severidad).

---

## 3. Qué controles debe soportar

El comparador alimenta controles concretos de los checklists de validación de implementación (versión v12 por tipología). Los más relevantes:

| Control | Qué necesita del comparador |
|---|---|
| **Validación de la fórmula del modelo** (control killer) | Equivalencia lógica y numérica entre referencia y producción |
| **Certificación del modelo** (control killer) | Comparación base productiva vs Excel vs Python/.NET |
| **Precisión de variables insumo y modelo** (control SOX) | Reconciliación numérica con tolerancia declarada |
| Revisión de código documentado | Inventario de funciones y trazabilidad |
| Versionamiento y control de cambios | Detección de qué versión de código y parámetros se usa realmente |

Los controles dependen del **tier** del modelo. El tier es un **atributo del control**, no un modo del comparador.

---

## 4. Lecciones de los casos de prueba (requisitos obligatorios)

El comparador actual (AS-IS) se evaluó en tres casos. Sus fallos son los requisitos del nuevo diseño.

| # | Hallazgo en el AS-IS | Requisito |
|---|---|---|
| R1 | Asume **una sola estrategia** por caso; dos casos distintos quedaron `AMBIGUOUS` (0.95 vs 0.93/0.97) | Ejecutar **varias estrategias** por caso y combinar resultados por componente |
| R2 | `temporal_curve` recalcula el Excel contra sí mismo; **ninguna ruta ejecuta Python** | Ruta real de ejecución: correr la función productiva y comparar contra la referencia |
| R3 | El evaluador de fórmulas **no soporta `IF`** | Construir un **oráculo** desde las fórmulas del Excel y validarlo contra los valores en caché antes de usarlo |
| R4 | No detectó que el código cargaba una **versión de parámetros distinta** a la del Excel (0/70 vs 70/70) | Identificar qué archivos de parámetros **lee realmente** el código y compararlos contra la referencia |
| R5 | No puede decir "se usa 1 de N archivos de parámetros" | Cruce explícito: valores de referencia ↔ archivos ↔ referencias en código (usados, no usados, comentados, rutas dinámicas) |
| R6 | Tablas de valores sin fórmulas (coeficientes) **no generan reglas** y nunca se comparan | Comparar también tablas de parámetros no referenciadas por fórmulas |
| R7 | Detector de parámetros solo reconoce pares nombre-valor | Reconocer **tablas anchas** (fila por segmento, columnas de coeficientes) |
| R8 | El LLM marca falsos negativos: no reconoce `merge` como `VLOOKUP`, filtros booleanos como `IF`, ni equivalencias algebraicas (logit/logística) | El LLM **propone** correspondencias; la **evidencia ejecutable decide** |
| R9 | `NO_LOCALIZADO` se confundía con ausencia | Separar estados: aplicabilidad, ejecución y veredicto |
| R10 | Nombres de estrategias en config no coincidían con los internos (`NOT_SELECTED`) | Validar la configuración contra un registro de herramientas al arrancar |
| R11 | Precisión distinta entre fuentes (redondeo visual vs valor guardado) | Tolerancias declaradas por componente y registro del formato origen |
| R12 | Límites de rango distintos (`<=19` vs `19-24`) solo visibles leyendo fórmulas | Probar fronteras de rangos con una matriz de casos |

**Caso de regresión obligatorio:** el nuevo comparador debe reproducir automáticamente el resultado del caso controlado: versión activa de parámetros **0/70** coincidencias y versión alternativa **70/70** contra la curva de referencia, más la divergencia en la extensión lineal.

---

## 5. Arquitectura objetivo

```text
          ┌─────────────────────────────┐
          │  Contrato de entrada         │  referencia + implementación + config + tier
          └──────────────┬──────────────┘
                         ▼
  Extractores (determinísticos)          Excel · Word/PDF texto · Python AST · SAS · CSV/JSON
                         ▼
  Representación canónica               entradas, constantes, operaciones, condiciones,
                                         salidas, parámetros, evidencia (archivo, celda/línea)
                         ▼
  Estrategias (varias por caso)          parámetros · fórmula escalar · tabular · curva ·
                                         ejecución productiva · uso de parámetros
                         ▼
  Motor de comparación                   tolerancias declaradas, oráculo validado
                         ▼
  Resultado por componente               aplicabilidad · ejecución · veredicto · evidencia
                         ▼
  Expediente auditable                   JSON + Markdown + CSV de detalle
```

### 5.1 Contrato de resultado por componente

```yaml
component_id: string
control_id: string            # control del checklist que alimenta
applicability: APPLIES | DOES_NOT_APPLY
execution_status: COMPLETED | ERROR | NOT_EXECUTED
verdict: MATCH | DIVERGE | PARTIAL | INCONCLUSIVE | null
severity: HIGH | MEDIUM | LOW | null
compared: integer
matches: integer
max_abs_diff: number | null
tolerance: {absolute: number, relative: number}
evidence: [{source, location, value}]
limitations: [string]
requires_human_review: boolean
```

Reglas:
- Un `ERROR` técnico **nunca** produce `MATCH` ni `DIVERGE`.
- La ausencia de evidencia **nunca** produce `MATCH`.
- El veredicto integral no puede ser mejor que el peor componente aplicable.

### 5.2 Reglas de diseño

1. **Determinístico primero.** Lo que se puede calcular, se calcula. El LLM solo propone correspondencias o redacta explicaciones.
2. **Herramientas pequeñas con contrato.** Cada estrategia es una herramienta registrada con entrada, salida, permisos y versión.
3. **Configuración, no hardcoding.** Rutas, nombres de hojas, funciones y tolerancias van en configuración versionada. Nada específico de un modelo (por ejemplo EAD o CLV) en el núcleo.
4. **Aislamiento.** Nunca modificar el proyecto evaluado. Ejecutar sobre copias verificadas por SHA-256.
5. **Reproducibilidad.** Cada corrida registra hashes de entradas, versión del comparador, configuración efectiva y deltas aplicados.
6. **Costo medido.** Registrar tiempo y llamadas al LLM por corrida.

---

## 6. Visión de autoservicio

Objetivo final: **la primera línea pulsa un botón y el agente validador revisa automáticamente**.

Implicaciones para este repositorio desde ahora:

- Entrada **sin intervención manual**: el comparador debe poder descubrir qué comparar a partir de la referencia y el repositorio, y **pedir confirmación** solo cuando la ambigüedad lo exija.
- Salida **legible por personas no técnicas**: resumen ejecutivo + detalle técnico separado.
- **Nunca** emitir aprobación final. El resultado es insumo; la decisión es del validador humano (segunda línea independiente).
- Diferenciar lo que la primera línea puede corregir sola (evidencia faltante, versión de archivo) de lo que requiere juicio del validador.
- Soportar re-ejecución tras correcciones sin rehacer todo (idempotencia por componente).

---

## 7. Seguridad y datos

Obligatorio:

- **No** incluir en código, logs, prompts, fixtures ni documentación: tokens, contraseñas, claves, correos, nombres de personas, rutas personales de Workspace, URLs de SharePoint ni IDs de tenant.
- Los insumos pueden ser **datos de alta criticidad (DAC)**. No enviar valores numéricos reales al LLM salvo autorización explícita; preferir enviar estructura (nombres, fórmulas, firmas) y comparar valores localmente.
- Leer secretos solo desde variables de entorno o el gestor de secretos de la plataforma.
- No escribir datos reales en tests: usar fixtures sintéticos o anonimizados.
- Respetar los lineamientos de almacenamiento autorizados del workspace; las rutas de lectura y escritura son configuración, no constantes.
- Todo acceso a archivos y toda llamada al LLM deben quedar en log (qué, cuándo, con qué entrada resumida), sin volcar datos sensibles.

---

## 8. Fuera de alcance de este repositorio

- Decidir la versión productiva correcta de parámetros (decisión humana).
- Aprobar o rechazar un modelo.
- Registrar resultados en la herramienta de inventario MRM (lo hará el orquestador o el generador de entregables).
- OCR de PDFs escaneados (capacidad separada, posterior).
- Revisión de controles documentales de primera línea (otro agente).

---

## 9. Orden de trabajo sugerido para Claude Code

1. Leer este documento, el `README.md` del repositorio y la evidencia de los casos de prueba.
2. Proponer el **contrato de entrada y de resultado** antes de escribir código.
3. Escribir tests a partir de los requisitos R1-R12 con fixtures sintéticos.
4. Implementar extractores y representación canónica.
5. Implementar la herramienta de **uso de parámetros** (R4, R5, R6) y la de **ejecución productiva** (R2, R3).
6. Implementar la ejecución de varias estrategias por caso (R1).
7. Reproducir el caso de regresión (0/70 vs 70/70).
8. Solo después, integrar el LLM para correspondencias semánticas, siempre subordinado a evidencia ejecutable.

Antes de cada cambio relevante: explicar qué requisito cubre, qué contrato toca y cómo se prueba.
