# AS_IS_CODE_INSPECTION.md

## 0. Propósito

Este documento consolida la inspección técnica del código existente del comparador antes de aplicar la metodología objetivo.

Su finalidad es establecer una línea base verificable del sistema actual, identificar qué componentes deben conservarse, cuáles requieren refactorización y cuáles todavía no cuentan con evidencia suficiente.

Este documento describe el estado observado. No define todavía la arquitectura objetivo, no agrega funcionalidades y no autoriza cambios en el código productivo.

---

## 1. Alcance de la inspección

### 1.1 Archivos de contexto y migración revisados

- `migration/ACTUAL_REPOSITORY_TREE.txt`
- `migration/HANDOFF_AS_IS.md`
- `migration/HANDOFF_AS_IS_REVIEWED.md`
- `migration/CURRENT_REPOSITORY_TREE.txt`
- `migration/CURRENT_REQUIREMENTS.md`
- `migration/CURRENT_KNOWN_ISSUES.md`
- `migration/CURRENT_TEST_CASES.md`
- `migration/CURRENT_DEPENDENCIES.txt`
- `migration/CURRENT_DECISIONS.md`
- `migration/AS_IS_GAP_ANALYSIS.md`

### 1.2 Archivos de configuración, ejecución y código inspeccionados

- `README.md`
- `pyproject.toml`
- `requirements.txt`
- `config.example.yaml`
- `notebooks/00_ejecutar_en_databricks`
- `excel_code_compare/cli.py`
- `excel_code_compare/__init__.py`
- `excel_code_compare/strategies/__init__.py`
- `excel_code_compare/adapters/__init__.py`
- `excel_code_compare/strategies/base.py`
- `excel_code_compare/strategy_discovery.py`
- `excel_code_compare/strategies/parameter_table.py`
- `excel_code_compare/strategies/scalar_formula.py`
- `excel_code_compare/strategies/tabular_formula.py`
- `excel_code_compare/strategies/temporal_curve.py`
- `excel_code_compare/strategies/production_function.py`
- `excel_code_compare/reconciliation.py`
- `excel_code_compare/reconcile.py`
- `excel_code_compare/formulas.py`
- `excel_code_compare/excel_inventory.py`
- `excel_code_compare/project_scan.py`
- `excel_code_compare/callgraph.py`
- `excel_code_compare/mapping.py`
- `excel_code_compare/llm.py`
- `excel_code_compare/report.py`
- `excel_code_compare/utils.py`
- `excel_code_compare/adapters/ead_curve.py`
- `tests/test_canonical.py`

### 1.3 Archivos del árbol todavía no inspeccionados en contenido

No se ha completado una inspección específica de contenido para módulos no incluidos en la lista anterior. Cualquier afirmación sobre componentes no revisados debe mantenerse como `NO CONFIRMADO`.

---

## 2. Resumen ejecutivo

El proyecto actual ya contiene una base funcional más amplia que un script monolítico. Existe un paquete instalable, un punto de entrada CLI, inventario de Excel, extracción y agrupación de fórmulas, exploración de repositorios Python, construcción de grafo estático, comparación semántica mediante LLM, reconciliación numérica por estrategias y generación de un reporte final.

Sin embargo, el sistema combina dos niveles de madurez:

1. **Componentes generalizables**, como inventario de Excel, exploración de proyecto, utilidades, contratos base de estrategias y reglas de seguridad del veredicto final.
2. **Componentes o decisiones específicas de EAD**, presentes en selección de evidencia, reconciliación y reporte.

La causa del resultado `NOT_SELECTED` quedó confirmada: la configuración del notebook utiliza identificadores que no coinciden con los nombres internos de las cinco estrategias. Como el descubridor exige coincidencia exacta, todas las estrategias pueden quedar excluidas antes de ejecutar `detect()`.

El estado `NOT_RUN` no es una causa independiente. Es la consecuencia esperada en `reconciliation.py` cuando el descubrimiento no devuelve `SELECTED`.

La prueba `tests/test_canonical.py` está desalineada con la implementación actual porque importa `canonicalize`, mientras `formulas.py` expone `canonicalize_with_context` y `canonicalize_structural`.

El reporte final contiene una protección valiosa: no emite un veredicto positivo cuando la reconciliación no se ejecuta, ocurre un error o quedan reglas semánticas pendientes. No obstante, su estructura y varios mensajes mantienen supuestos específicos de EAD.

La recomendación de migración es **incremental**. No corresponde reescribir el proyecto completo. Primero deben congelarse el baseline y los contratos observados, después corregirse los defectos confirmados mediante un delta controlado y finalmente separarse la lógica general del contenido específico de EAD.

---

## 3. Flujo real confirmado

El punto de entrada declarado por el paquete es:

```text
excel-code-compare = excel_code_compare.cli:main
```

El flujo principal observado es:

```text
Configuración YAML
        ↓
Resolución de rutas y parámetros
        ↓
Creación opcional de DatabricksChatClient
        ↓
Inventario del Excel
        ↓
Extracción y agrupación de reglas Excel
        ↓
Exploración del repositorio de implementación
        ↓
Construcción del grafo estático de llamadas
        ↓
Mapping semántico Excel contra código
        ↓
Reconciliación numérica
        ↓
Reporte final
```

### 3.1 Fase de configuración

El sistema lee una configuración YAML que contiene rutas, configuración de proyecto, modelo LLM, parámetros de mapping y reconciliación.

Se observaron dos formas de convertir la configuración en ejecución:

- Ejecución CLI documentada mediante `python -m excel_code_compare.cli --config config.yaml`.
- Notebook de Databricks que construye o modifica la configuración antes de invocar el paquete.

### 3.2 Fase de inventario Excel

`inventory_excel()` abre el libro dos veces:

- Con `data_only=False` para conservar fórmulas.
- Con `data_only=True` para recuperar valores almacenados en caché.

Produce:

```text
artifacts/excel_inventory.json
artifacts/raw_cells.json
01_mapa_excel.md
```

Retorna:

```text
wb_formula
workbook
raw_cells
```

### 3.3 Fase de extracción de reglas

`extract_rules()` recibe el workbook y `raw_cells`.

Produce:

```text
02_celdas.csv
03_reglas_excel.md
04_parametros.json
artifacts/rules.json
```

El procesamiento incluye:

- Clasificación de fórmulas.
- Canonicalización contextual.
- Canonicalización estructural.
- Agrupación por hoja, tipo y firma estructural.
- Detección heurística de parámetros.
- Traducción opcional de reglas mediante LLM.

### 3.4 Fase de exploración del proyecto

`find_candidates()` recorre extensiones configuradas y excluye carpetas definidas por configuración.

Produce:

```text
artifacts/candidates.json
05_candidatos.md
```

El puntaje utiliza tres canales:

```text
Léxico: máximo 40
Estructural: máximo 35
Aritmético: máximo 25
Total: máximo 100
```

Para archivos `.py` utiliza AST. Para otros formatos utiliza expresiones regulares.

### 3.5 Fase de grafo estático

`build_callgraph()` analiza archivos `.py` y registra:

- Definiciones.
- Imports.
- Llamadas resueltas.
- Llamadas no resueltas.

Produce:

```text
artifacts/callgraph.json
06_grafo.md
```

El valor retornado no se entrega directamente a `build_mapping()`. No se observó lectura de `callgraph.json` dentro de `mapping.py`. En el AS-IS, el grafo funciona como artefacto informativo independiente.

### 3.6 Fase de mapping semántico

`build_mapping()` recibe:

```text
project_root
rules
candidates
llm
output_dir
```

Produce:

```text
artifacts/mapping.json
artifacts/mapping_batches/batch_*_input.json
artifacts/mapping_batches/batch_*_response.json
artifacts/mapping_batches/batch_*_error.txt
07_correspondencia.md
```

Los veredictos permitidos son:

```text
EQUIVALENTE
DIFIERE
NO_LOCALIZADO
NO_VERIFICABLE
NO_APLICA_CONTROL
SOLO_EN_CODIGO
```

Las fórmulas clasificadas como `CONTROL_VALIDACION` se convierten determinísticamente en `NO_APLICA_CONTROL`.

Cuando el LLM está deshabilitado, falla o no devuelve una correspondencia, la regla queda como `NO_VERIFICABLE`.

### 3.7 Fase de reconciliación

El punto de entrada actual es:

```python
from .reconciliation import run_reconciliation
```

`reconcile.py` no es llamado directamente por `cli.py`.

`reconciliation.py` soporta:

- Descubrimiento automático de estrategias.
- Ejecución de una estrategia seleccionada.
- Conservación de lógica específica de reconstrucción de fórmula EAD.
- Escritura de artefactos aun cuando el resultado sea `NOT_RUN` o `ERROR`.

Produce:

```text
artifacts/strategy_discovery.json
artifacts/reconciliation.json
08_reconciliacion.md
```

### 3.8 Fase de reporte final

`final_report()` recibe únicamente:

```text
mapping
reconciliation
output_dir
```

Produce:

```text
resultado_final.md
```

La función devuelve también un resumen estructurado del veredicto, conteos y estados relevantes.

---

## 4. Contratos de datos implícitos

Estos contratos se deducen del código observado. Todavía no son contratos formales aprobados.

### 4.1 Celda Excel extraída

```yaml
sheet: string
coordinate: string
row: integer
column: integer
column_letter: string
formula: string
cached_value: any
raw_value: any
data_type: string
```

### 4.2 Regla Excel

```yaml
rule_id: string
sheet: string
formula_type: string
orientation: string
header: string
columns: list[string]
row_ranges: list[string]
cell_count: integer
cells: list[string]
canonical_formula: string
structural_formula: string
contextual_variants: integer
examples: list[object]
signature: object
natural_language: string
```

### 4.3 Candidato de implementación

```yaml
path: string
score: number
channels:
  lexical: number
  structural: number
  arithmetic: number
reasons: list[string]
functions: list[string]
size: integer
```

### 4.4 Correspondencia semántica

```yaml
rule_id: string
verdict: string
files: list[string]
evidence: string
explanation: string
confidence: number
```

### 4.5 StrategyDetection

```yaml
strategy: string
confidence: number
status: string
sheet: string | null
payload: object
reason: string | null
```

### 4.6 Resultado de estrategia

El resultado base utiliza como mínimo:

```yaml
strategy: string
status: MATCH | DIVERGE | NOT_RUN | ERROR
confidence: number
reason: string | null
artifacts: list[string]
```

Cada estrategia puede agregar campos especializados.

### 4.7 Resultado final

El reporte combina:

```text
veredictos semánticos
+
estado de reconciliación
+
estado de función productiva
+
zonas no verificadas
```

La estructura funcional actual no separa formalmente en todos los niveles:

```text
aplicabilidad
estado de ejecución
veredicto de negocio
```

Esta separación debe evaluarse en la Specification objetivo, no implementarse todavía.

---

## 5. Registro de estrategias

### 5.1 Estrategias presentes

```text
parameter_table
scalar_formula
tabular_formula
temporal_curve
production_function
```

### 5.2 Adaptador explícito presente

```text
ead_curve
```

### 5.3 Archivo de paquete de estrategias

`excel_code_compare/strategies/__init__.py` existe y está vacío.

El descubrimiento no depende de exports desde ese archivo. `strategy_discovery.py` importa o instancia las estrategias directamente.

### 5.4 Causa raíz de `NOT_SELECTED`

El notebook configura:

```text
parameter_table_comparison
formula_recalculation
scalar_output_comparison
tabular_output_comparison
```

Las estrategias declaran:

```text
parameter_table
scalar_formula
tabular_formula
temporal_curve
production_function
```

El descubridor aplica una comparación exacta:

```python
if strategy.name not in allowed_strategies:
    continue
```

Como resultado, las estrategias pueden excluirse antes de ejecutar `detect()`.

Clasificación:

```text
TIPO: DEFECTO CONFIRMADO DE CONFIGURACIÓN/INTEGRACIÓN
EFECTO: candidates=[] y status=NOT_SELECTED
CONSECUENCIA: reconciliation.status=NOT_RUN
ACCIÓN ACTUAL: DOCUMENTAR, NO CORREGIR EN EL AS-IS
```

---

## 6. Representación canónica actual

### 6.1 Alcance confirmado

La implementación actual contiene dos formas de canonicalización de fórmulas Excel:

```text
canonicalize_with_context()
canonicalize_structural()
```

La primera intenta sustituir referencias por encabezados o ubicaciones conservando desplazamientos relativos o absolutos.

La segunda genera una firma estructural independiente de la posición para agrupar fórmulas copiadas horizontal o verticalmente.

### 6.2 Qué no representa todavía

No se observó un único objeto canónico compartido por:

```text
Excel
Word
PDF
Python
```

La representación actual está centrada en fórmulas Excel.

El código Python se analiza mediante AST para obtener features, archivos candidatos, funciones y llamadas, pero no se transforma al mismo contrato semántico de operaciones, entradas, condiciones y salidas que las fórmulas Excel.

### 6.3 Prueba existente

`tests/test_canonical.py` importa:

```python
from excel_code_compare.formulas import canonicalize
```

Sin embargo, `formulas.py` no define `canonicalize`.

Clasificación:

```text
TIPO: PRUEBA DESALINEADA CON IMPLEMENTACIÓN
EFECTO PROBABLE: ERROR DE IMPORTACIÓN
VALOR: CONSERVAR COMO EVIDENCIA DE INTENCIÓN Y REGRESIÓN
ACCIÓN ACTUAL: NO MODIFICAR HASTA DEFINIR CONTRATO
```

---

## 7. Componente probabilístico

### 7.1 Cliente LLM

`DatabricksChatClient` invoca un endpoint de Model Serving mediante:

```text
POST /serving-endpoints/{endpoint}/invocations
```

La autenticación intenta:

1. `DATABRICKS_HOST` y `DATABRICKS_TOKEN`.
2. `WorkspaceClient` de `databricks-sdk`.
3. Error explícito si no puede resolver credenciales.

### 7.2 Usos confirmados del LLM

- Traducción de reglas Excel a lenguaje natural.
- Comparación semántica entre reglas Excel y evidencia del repositorio.

### 7.3 Controles existentes

- Temperatura predeterminada `0.0`.
- Timeout configurado.
- Normalización de formatos de respuesta.
- Parseo de JSON.
- Lista cerrada de veredictos.
- Conversión de respuestas inválidas a estados seguros.
- Guardas determinísticas posteriores a la respuesta.
- Fallback a `NO_VERIFICABLE` ante falta de información o error.

### 7.4 Brechas observadas

- No hay reintentos automáticos.
- No hay backoff.
- `json_mode=True` no confirma un modo JSON nativo del endpoint.
- El cliente no registra automáticamente prompt, respuesta, modelo resuelto o identificador de ejecución.
- No se observó validación mediante esquema formal de la respuesta.
- La extracción del primer JSON mediante expresión regular puede ser frágil ante respuestas complejas.

Estas brechas se documentan, pero no se corrigen durante la inspección AS-IS.

---

## 8. Código generalizable que debe conservarse

### 8.1 `utils.py`

Funciones generales y reutilizables:

- `ensure_dir`
- `dump_json`
- `write_text`
- `safe_text`
- `compact`
- `contiguous_ranges`
- `stable_id`

No se observó lógica específica de EAD en este módulo.

Clasificación:

```text
GENERALIZABLE
DEBE CONSERVARSE
REFACTORIZACIÓN INMEDIATA NO NECESARIA
```

### 8.2 `excel_inventory.py`

Aspectos reutilizables:

- Apertura separada de fórmulas y valores cacheados.
- Inventario por hoja.
- Registro de nombres definidos.
- Registro de links externos.
- Extracción de celdas no vacías.
- Advertencia sobre `data_only=True`.

Aspectos que requieren evaluación posterior:

- Coste de recorrer todas las celdas.
- Clasificación heurística de hojas.
- Uso fijo del threshold interno.
- Escalabilidad con libros grandes.

### 8.3 `project_scan.py`

Aspectos reutilizables:

- Recorrido con allowlist de extensiones.
- Exclusión de directorios.
- Límite de tamaño.
- Lectura de notebooks.
- AST para Python.
- Puntaje por canales separados.

Aspectos que requieren contrato o configuración:

- Pesos 40/35/25.
- Regla `score > 0` para conservar candidatos.
- Tratamiento genérico por regex para formatos no Python.

### 8.4 `strategies/base.py`

Aspectos reutilizables:

- `StrategyContext`.
- `StrategyDetection`.
- Interfaz `ReconciliationStrategy`.
- Estados seguros de reconciliación.
- Utilidad de evidencia CSV.

Debe revisarse posteriormente si sus contratos son suficientes para Word, PDF y una representación canónica compartida.

### 8.5 `report.py`

Debe conservarse la lógica que:

- Prioriza diferencias confirmadas.
- Devuelve `NO DETERMINABLE` ante error.
- Devuelve `NO DETERMINABLE` ante `NOT_RUN`.
- Devuelve `NO DETERMINABLE` ante reglas pendientes.
- Exige correspondencias y reconciliaciones en `MATCH` antes de emitir “SÍ”.

---

## 9. Código específico del caso EAD

### 9.1 `mapping.py`

La selección de evidencia contiene rutas, funciones y términos específicos como:

```text
source/engine/utils.py
source/engine/curves_all.py
source/engine/clv_engine.py
data/params/modulo_riesgos/ead_thetat.csv
ead_transform
ead_predict
CurveEAD
ing_bci
theta
beta
flg_sur
flg_centro
```

También aplica bonificaciones explícitas a rutas concretas.

Clasificación:

```text
FUNCIONAL PARA EL CASO HEREDADO
NO GENERALIZABLE EN SU FORMA ACTUAL
DEBE AISLARSE COMO CONFIGURACIÓN, CATÁLOGO O SKILL
NO DEBE PERMANECER EN EL NÚCLEO DE MAPPING
```

### 9.2 `reconciliation.py`

Combina:

- Flujo genérico basado en estrategias.
- Reconstrucción específica de fórmula EAD.
- Descubrimiento de parámetros específico.
- Comparación de betas principales y temporales.
- Conceptos de periodos y curva EAD.

Clasificación:

```text
MÓDULO HÍBRIDO
CONTIENE NÚCLEO GENERAL Y LÓGICA ESPECÍFICA
DEBE SEPARARSE DESPUÉS DEL BASELINE
```

### 9.3 `report.py`

Incluye secciones y mensajes sobre:

```text
betas principales
betas temporales
curva
periodos
archivo de parámetros
función productiva
```

Filtra zonas no verificadas mediante marcadores específicos como:

```text
ead_thetat.csv
B38:BG38
60 periodos
arange(1, 61)
```

Clasificación:

```text
GUARDAS DE VEREDICTO GENERALIZABLES
PRESENTACIÓN Y FILTROS ESPECÍFICOS DE EAD
DEBE PARAMETRIZARSE O DIVIDIRSE
```

### 9.4 `adapters/ead_curve.py`

Es una estrategia explícita y deliberadamente específica de EAD.

Clasificación:

```text
ESPECÍFICO DEL CASO
DEBE CONSERVARSE COMO ADAPTADOR O SKILL ESPECIALIZADA
NO DEBE CONVERTIRSE EN REGLA GENERAL
```

---

## 10. Código posiblemente legado

### 10.1 `reconcile.py`

El CLI actual no lo importa. Utiliza un contrato antiguo basado en `módulo:función` y configuración explícita de hoja, filas y columnas.

Clasificación provisional:

```text
POSIBLE LEGADO
CONSERVAR SIN MODIFICAR
NO ELIMINAR HASTA BUSCAR TODOS LOS CONSUMIDORES
```

Para declararlo definitivamente sin uso se requiere una búsqueda de imports y referencias en todo el repositorio.

### 10.2 Relación con `reconciliation.py`

`reconciliation.py` es el punto de entrada actual y soporta el modo automático por estrategias.

No debe asumirse que `reconcile.py` puede eliminarse solo porque no es importado por `cli.py`.

---

## 11. Dependencias efectivas

### 11.1 Dependencias declaradas

El `pyproject.toml` y `requirements.txt` declaran:

```text
openpyxl
PyYAML
requests
databricks-sdk
```

Python requerido:

```text
>= 3.10
```

### 11.2 Dependencias usadas pero no declaradas

Se observó uso de:

```text
numpy
pandas
```

en estrategias y adaptadores.

Clasificación:

```text
DEFECTO CONFIRMADO DE MANIFIESTO DE DEPENDENCIAS
RIESGO: EL PAQUETE PUEDE FUNCIONAR EN DATABRICKS POR LIBRERÍAS PREINSTALADAS Y FALLAR EN OTRO ENTORNO
ACCIÓN ACTUAL: DOCUMENTAR
ACCIÓN POSTERIOR: RESOLVER MEDIANTE DELTA Y PRUEBA DE INSTALACIÓN LIMPIA
```

### 11.3 Credenciales y configuración

El cliente LLM acepta:

```text
DATABRICKS_HOST
DATABRICKS_TOKEN
DATABRICKS_CHAT_ENDPOINT
```

No deben copiarse valores sensibles al repositorio local ni a documentos de migración.

---

## 12. Defectos confirmados

### D-001. Identificadores de estrategia desalineados

```text
Configuración del notebook != strategy.name
```

Efecto:

```text
candidates=[]
status=NOT_SELECTED
reconciliation.status=NOT_RUN
```

### D-002. Prueba canónica desalineada

```text
test_canonical.py importa canonicalize
formulas.py no define canonicalize
```

Efecto probable:

```text
Error durante importación o colección de pytest
```

### D-003. Dependencias incompletas

```text
numpy y pandas son usadas pero no declaradas
```

Impacto:

```text
Instalación no reproducible fuera de un entorno que ya las contenga
```

### D-004. Configuración duplicada de reconciliación

`config.example.yaml` contiene dos bloques raíz llamados `reconciliation`.

Impacto:

```text
Un parser YAML convencional conservará una sola definición o tendrá un comportamiento dependiente de implementación.
```

El comportamiento exacto debe verificarse con el parser utilizado antes de corregir.

### D-005. Threshold configurado no transmitido

El notebook/configuración incluye `parameter_density_threshold`, pero la llamada observada a `inventory_excel()` no lo transmite y `_classify_sheet()` usa el valor predeterminado `0.65`.

Impacto:

```text
La configuración declarada puede no modificar la clasificación real de hojas.
```

---

## 13. Brechas arquitectónicas confirmadas

### B-001. Canonicalización limitada a Excel

Existe una firma canónica de fórmulas Excel, pero no un contrato común Excel contra Python.

### B-002. Grafo estático no conectado al mapping

El grafo se genera, pero el mapping no lo recibe ni lo lee.

### B-003. Núcleo y caso EAD mezclados

`mapping.py`, `reconciliation.py` y `report.py` contienen lógica general junto a decisiones EAD.

### B-004. Contratos no formalizados

Existen diccionarios implícitos, pero no esquemas versionados para:

- Celda Excel.
- Regla canónica.
- Candidato.
- Evidencia.
- Correspondencia.
- Resultado de estrategia.
- Resultado final.

### B-005. Evaluación insuficiente

Solo existe una prueba observada y está desalineada. No se observaron pruebas confirmadas para:

- Descubrimiento de estrategias.
- Mapping.
- Reconciliación.
- Reporte final.
- Integración end-to-end.
- Errores del LLM.
- Selección de evidencia.

### B-006. Trazabilidad parcial del LLM

`mapping.py` conserva inputs y respuestas por lote, pero `llm.py` no registra automáticamente metadatos completos de invocación.

---

## 14. Controles de seguridad y calidad ya existentes

No todo el sistema debe descartarse. El AS-IS ya incorpora controles útiles:

- Lectura estática de Python mediante AST.
- Ejecución de función productiva condicionada a configuración explícita.
- Estados `NOT_RUN` y `ERROR`.
- Veredictos permitidos en lista cerrada.
- Normalización de confidence entre 0 y 1.
- Guardas determinísticas posteriores al LLM.
- Prohibición en prompt de declarar diferencias sin evidencia concreta.
- Conversión segura a `NO_VERIFICABLE` cuando falta información.
- Evita concluir “SÍ” si la reconciliación no se completó.
- Conservación de evidencia por lote para el mapping.
- Separación parcial del adaptador EAD del núcleo mediante `EADCurveAdapter`.

Estos controles deben convertirse posteriormente en requisitos y pruebas, no eliminarse durante la migración.

---

## 15. Capacidades no confirmadas

No se observó evidencia suficiente para declarar:

- Soporte de Word como fuente de entrada.
- Soporte de PDF con texto.
- Soporte de PDF escaneado.
- OCR o visión.
- RAG.
- MCP.
- Catálogo formal de controles.
- Skills en formato Agent Skills.
- Policy Guard central.
- Human-in-the-loop persistente.
- Aprobación formal.
- Ejecución reproducible fuera de Databricks.
- Evaluación con golden dataset.
- Validación integral de proyectos Python arbitrarios.

Estas capacidades pertenecen a la arquitectura objetivo o a futuras especificaciones, no al AS-IS confirmado.

---

## 16. Clasificación de módulos

| Módulo | Clasificación actual | Acción recomendada |
|---|---|---|
| `utils.py` | Generalizable | Conservar |
| `excel_inventory.py` | Mayormente generalizable | Conservar y probar |
| `formulas.py` | Generalizable para Excel, no común Excel-Python | Conservar y formalizar contrato |
| `project_scan.py` | Generalizable con heurísticas hardcodeadas | Conservar y parametrizar después |
| `callgraph.py` | Generalizable, actualmente desacoplado | Conservar y decidir consumo |
| `llm.py` | Infraestructura común básica | Conservar y gobernar después |
| `strategies/base.py` | Contrato base reutilizable | Conservar y versionar |
| `strategy_discovery.py` | Mecanismo general con defecto de integración | Conservar y corregir mediante delta |
| `parameter_table.py` | Estrategia reutilizable | Conservar y probar |
| `scalar_formula.py` | Estrategia reutilizable | Conservar y probar |
| `tabular_formula.py` | Estrategia reutilizable | Conservar y probar |
| `temporal_curve.py` | Estrategia reutilizable | Conservar y probar |
| `production_function.py` | Estrategia sensible y controlada | Conservar con reglas de ejecución |
| `mapping.py` | Híbrido, genérico más EAD | Separar posteriormente |
| `reconciliation.py` | Híbrido, orquestación más EAD | Separar posteriormente |
| `reconcile.py` | Posible legado | Conservar hasta confirmar consumidores |
| `report.py` | Guardas generales más presentación EAD | Separar posteriormente |
| `ead_curve.py` | Específico de EAD | Conservar como extensión especializada |
| `cli.py` | Orquestador actual | Conservar como baseline, no ampliar aún |
| `test_canonical.py` | Intención válida, implementación desalineada | Conservar y reemplazar tras contrato |

---

## 17. Artefactos generados por el AS-IS

### Inventario Excel

```text
01_mapa_excel.md
artifacts/excel_inventory.json
artifacts/raw_cells.json
```

### Reglas

```text
02_celdas.csv
03_reglas_excel.md
04_parametros.json
artifacts/rules.json
```

### Candidatos

```text
05_candidatos.md
artifacts/candidates.json
```

### Grafo

```text
06_grafo.md
artifacts/callgraph.json
```

### Mapping

```text
07_correspondencia.md
artifacts/mapping.json
artifacts/mapping_batches/batch_*_input.json
artifacts/mapping_batches/batch_*_response.json
artifacts/mapping_batches/batch_*_error.txt
```

### Reconciliación

```text
08_reconciliacion.md
artifacts/strategy_discovery.json
artifacts/reconciliation.json
artifacts/reconciliation_components/*.csv
```

### Resultado final

```text
resultado_final.md
```

---

## 18. Reglas que deben preservarse durante la migración

1. No modificar archivos originales de entrada.
2. No ejecutar código productivo sin autorización explícita.
3. No convertir falta de evidencia en equivalencia.
4. No declarar diferencia sin evidencia concreta.
5. No tratar fórmulas de control como reglas productivas automáticamente.
6. Ante fallo del LLM, usar un estado no verificable.
7. Ante fallo numérico, no emitir cumplimiento.
8. Ante reconciliación no ejecutada, no emitir cumplimiento.
9. Conservar evidencia por regla y por lote.
10. Mantener separadas las comparaciones determinísticas y semánticas.
11. No eliminar `reconcile.py` hasta confirmar ausencia de consumidores.
12. No eliminar lógica EAD hasta contar con baseline y regresión.
13. No declarar Word o PDF como soportados antes de implementar y probar sus extractores.

---

## 19. Orden de migración recomendado

### Paso 1. Congelar el AS-IS

Conservar:

- Código actual.
- Configuración utilizada.
- Insumos del caso conocido.
- Artefactos generados.
- Resultado revisado manualmente.
- Versiones de dependencias y endpoint.

### Paso 2. Crear baseline ejecutable

Registrar una ejecución conocida y sus resultados esperados sin modificar el sistema.

### Paso 3. Formalizar contratos actuales

Documentar y probar primero:

- `RawCell`.
- `CanonicalExcelRule`.
- `CandidateFile`.
- `EvidenceReference`.
- `SemanticCorrespondence`.
- `StrategyDetection`.
- `ReconciliationResult`.
- `FinalAssessment`.

### Paso 4. Corregir defectos mínimos mediante delta

Separar cambios:

- Alineación de nombres de estrategias.
- Manifiesto de dependencias.
- Configuración duplicada.
- Prueba canónica.
- Threshold no transmitido.

Cada cambio debe incluir requisito, prueba y evidencia.

### Paso 5. Separar núcleo general de EAD

Mover progresivamente:

- Términos EAD.
- Rutas prioritarias.
- Funciones específicas.
- Supuestos de betas y periodos.
- Secciones del reporte.

hacia configuración, catálogo o skill especializada.

### Paso 6. Diseñar representación común Excel-Python

No reemplazar la canonicalización Excel existente sin regresión. Crear un contrato común que represente:

```text
entradas
constantes
operaciones
condiciones
salidas
evidencia
```

### Paso 7. Incorporar documentos

Después de estabilizar Excel contra Python, agregar:

- Word con texto.
- PDF con texto.
- PDF escaneado como capacidad separada.

### Paso 8. Probar una segunda casuística

La segunda casuística debe entrar sin agregar hardcoding al núcleo. Si requiere una capacidad nueva, debe clasificarse como herramienta o procedimiento nuevo, no como parche.

---

## 20. Acciones prohibidas inmediatamente después de esta inspección

Hasta congelar un baseline y aprobar el primer delta, no se debe:

- Reescribir todo el proyecto.
- Eliminar `reconcile.py`.
- Mezclar nuevas capacidades Word/PDF con la corrección de estrategias.
- Cambiar simultáneamente configuración, contratos y comportamiento.
- Mover toda la lógica EAD en un único cambio.
- Sustituir tests humanos por outputs generados por el sistema.
- Considerar el resultado actual como golden sin revisión humana.
- Introducir RAG o MCP sin un requisito concreto.
- Crear una skill por archivo o por caso aislado.
- Modificar umbrales para hacer pasar una ejecución.

---

## 21. Riesgos de la migración

### Riesgo 1. Reescritura prematura

Podría perderse lógica útil ya implementada y reglas de seguridad existentes.

### Riesgo 2. Baseline incorrecto

Si el output actual se adopta como verdad sin revisión humana, los errores existentes se convertirían en resultados esperados.

### Riesgo 3. Generalización aparente

Mover hardcoding a otro archivo sin convertirlo en configuración o contrato no elimina el acoplamiento.

### Riesgo 4. Mezcla de cambios

Corregir nombres de estrategias, dependencias, canonicalización y arquitectura en el mismo cambio impediría conocer qué modificación alteró el resultado.

### Riesgo 5. Entorno no reproducible

El código puede depender de librerías disponibles en Databricks pero no declaradas formalmente.

### Riesgo 6. Automatización semántica sin cobertura

El mapping puede evaluar únicamente la evidencia seleccionada. `NO_LOCALIZADO` no demuestra ausencia en todo el proyecto.

---

## 22. Decisión de cierre de la inspección

La inspección confirma que el comparador actual debe tratarse como un sistema brownfield con componentes reutilizables, defectos localizados y lógica específica del caso heredado.

No corresponde empezar desde cero.

La siguiente etapa metodológica debe ser **congelar un baseline reproducible del caso actualmente conocido**, antes de escribir la Constitution específica del nuevo repositorio o corregir el código.

El baseline debe incluir:

```text
configuración exacta
Excel exacto
proyecto Python exacto
versión del código
artefactos generados
resultado final
resultado esperado revisado por una persona
errores observados
```

Solo después deberá abrirse el primer delta de corrección.

---

## 23. Estado final de hallazgos

| ID | Hallazgo | Estado |
|---|---|---|
| D-001 | Identificadores de estrategias desalineados | CONFIRMADO |
| D-002 | Prueba `canonicalize` desalineada | CONFIRMADO |
| D-003 | `numpy` y `pandas` no declarados | CONFIRMADO |
| D-004 | Dos bloques raíz `reconciliation` | CONFIRMADO EN ARCHIVO, EFECTO POR VERIFICAR |
| D-005 | Threshold configurado no transmitido | CONFIRMADO |
| B-001 | Canonicalización limitada a Excel | CONFIRMADO |
| B-002 | Call graph no conectado al mapping | CONFIRMADO EN FLUJO INSPECCIONADO |
| B-003 | Núcleo y EAD mezclados | CONFIRMADO |
| B-004 | Contratos implícitos sin versión | CONFIRMADO |
| B-005 | Cobertura de pruebas insuficiente | CONFIRMADO PARA EL ÁRBOL INSPECCIONADO |
| B-006 | Trazabilidad LLM parcial | CONFIRMADO |
| L-001 | `reconcile.py` posiblemente legado | PENDIENTE DE BÚSQUEDA DE CONSUMIDORES |
| C-001 | Word soportado | NO CONFIRMADO |
| C-002 | PDF soportado | NO CONFIRMADO |
| C-003 | Representación común Excel-Python | NO CONFIRMADO |

---

## 24. Control documental

```yaml
document: AS_IS_CODE_INSPECTION.md
status: DRAFT
purpose: Inspección del sistema heredado antes de la migración
source_of_truth: Código y configuración inspeccionados
allows_code_changes: false
next_gate: Baseline reproducible revisado por una persona
```
