# Reconciliación numérica Excel vs Python

## 1. Control del documento

```yaml
case_id: CASE_002_CONTROLLED_RUN
document_type: NUMERIC_RECONCILIATION
status: COMPLETED_WITH_LIMITATIONS
method: INDEPENDENT_EXECUTION_OF_PRODUCTION_FUNCTIONS
absolute_tolerance: 1.0e-8
evidence_detail: evidence/NUMERIC_RECONCILIATION_DETAIL.csv
evidence_summary: evidence/NUMERIC_RECONCILIATION_SUMMARY.json
```

---

## 2. Por qué se usó una reconciliación independiente

El comparador AS-IS no tiene ninguna ruta que ejecute código Python:

- `temporal_curve` recalcula fórmulas del Excel contra los valores en caché del mismo Excel. No compara Excel contra Python.
- Su evaluador no soporta `IF`, por lo que las 70 celdas de `I27:BZ27` quedaron sin evaluar.
- `production_function` no se detectó por falta de un contrato explícito de entradas y salidas.

Por eso, la reconciliación numérica se realizó ejecutando directamente las funciones productivas de `clv/source/engine/utils.py` en cada copia runtime verificada.

---

## 3. Insumos

```yaml
excel:
  file: inputs/excel/calculadora_final.xlsx
  sheet: Calculadora
  score_cell: H11
  score: 274
  plazo_cell: H8
  plazo: 18
  periods: 70
  compared_rows:
    row27: "PD TEMPORAL (I27:BZ27)"
    row28: "PD TEMPORAL 36 Versión Final (I28:BZ28)"

python_input:
  ScoreApplicantVendida: 274
  CantidadPlazo: 18
  product_code_final: 1
  segmento_info_new: "valor neutro"
  prod_mto_sld_pas_prm_u12: 0.0

functions_executed:
  - pd_predict
  - pd_predict_new

variants:
  RUN_A_ACTIVE_SEP24_V2: "parámetros sep24_v2"
  RUN_B_EXCEL_MATCHING_202605: "parámetros 202605"
```

---

## 4. Resultados

| Variante | Fila Excel | Coincidencias | Diferencia máxima |
|---|---|---:|---:|
| RUN_A (`sep24_v2`) | fila 27 | 0 / 70 | 0.09959581681404239 |
| RUN_A (`sep24_v2`) | fila 28 | 0 / 70 | 0.2668112913859251 |
| RUN_B (`202605`) | fila 27 | 70 / 70 | 2.51062504119659e-10 |
| RUN_B (`202605`) | fila 28 | 10 / 70 | 0.36640710845103 |

`pd_predict` y `pd_predict_new` produjeron resultados idénticos para este insumo.

---

## 5. Hallazgos

### H-01. La versión activa de parámetros no reproduce la calculadora

```yaml
finding_id: H-01
type: DIVERGENCIA_DE_VERSION
severity: ALTA
evidence: "RUN_A 0/70 coincidencias contra la fila 27; diferencia máxima 0.0996"
```

El código inspeccionado carga activamente los archivos `sep24_v2`. Con esos parámetros, ninguno de los 70 periodos de la curva PD temporal coincide con la calculadora.

### H-02. Con la versión 202605, Python reproduce exactamente la curva PD temporal

```yaml
finding_id: H-02
type: COINCIDENCIA_NUMERICA
evidence: "RUN_B 70/70 coincidencias contra la fila 27; diferencia máxima 2.5e-10"
```

La lógica de cálculo de Python es equivalente a la de la calculadora. La diferencia de H-01 se explica por la versión de parámetros, no por la fórmula.

### H-03. La extensión lineal de la fila 28 no se aplica en Python para plazo 18

```yaml
finding_id: H-03
type: DIVERGENCIA_DE_REGLA_DE_NEGOCIO
severity: MEDIA
evidence: "RUN_B 10/70 coincidencias contra la fila 28; coinciden solo los periodos 3 a 12"
```

- **Excel:** desde el periodo 13 suma el incremento `J34` en cada periodo, sin condición.
- **Python (`pd_predict_new`):** aplica la extensión lineal solo si `product_code_final = 1` y `CantidadPlazo > 24`.
- **Python (`pd_predict`):** no aplica esa extensión. El ajuste de los periodos 25 a 36 se ejecuta, pero suma cero porque la curva es plana desde el periodo 18.

La diferencia máxima de 0.3664 en el periodo 72 coincide con la distancia entre las filas 27 y 28 del Excel. Python devuelve la fila 27 sin la extensión.

---

## 6. Reclasificación de reglas de CASE_001

Para el insumo evaluado:

| Regla | Estado en CASE_001 | Resultado numérico CASE_002 |
|---|---|---|
| XL-0004 | NO_DETERMINABLE | Lógica confirmada con 202605; diverge con sep24_v2 |
| XL-0005 | NO_DETERMINABLE | Lógica confirmada con 202605; diverge con sep24_v2 |
| XL-0007 | NO_DETERMINABLE | 70/70 con 202605; 0/70 con sep24_v2 |
| XL-0009 | NO_DETERMINABLE | Divergencia confirmada: extensión no aplicada para plazo 18 |
| XL-0012 | NO_DETERMINABLE | Divergencia confirmada por la condición de aplicación |

Estas reclasificaciones son válidas para un solo punto de entrada. No sustituyen una validación con múltiples casos.

---

## 7. Decisiones requeridas

### D-1. Versión de parámetros productiva

¿La versión vigente para producción es `sep24_v2`, activa en el código, o `202605`, usada en la calculadora?

```yaml
decision_id: D-1
owner: Responsable del modelo
status: PENDIENTE
```

### D-2. Condición de la extensión lineal

¿La extensión lineal de la fila 28 debe aplicarse con plazo 18 o solo con plazos mayores a 24?

```yaml
decision_id: D-2
owner: Responsable del modelo
status: PENDIENTE
```

---

## 8. Limitaciones

1. Se evaluó un solo punto de entrada: score 274 y plazo 18.
2. `product_code_final = 1` es un supuesto documentado, no un dato confirmado de la calculadora.
3. `segmento_info_new` se fijó en un valor neutro; solo afecta al producto 5.
4. Con score 274 no se activa el ajuste de los periodos 3 a 12, que requiere score mayor a 300.
5. Con plazo 18 no se activa la extensión lineal de `pd_predict_new`, que requiere plazo mayor a 24.
6. No se confirmó un commit Git; la reproducibilidad se basa en el manifiesto SHA-256 por archivo.
7. No se identificó cuál de las dos funciones se usa en el flujo productivo.

---

## 9. Conclusión

```yaml
case_verdict: DIVERGE
primary_cause: DIVERGENCIA_DE_VERSION_DE_PARAMETROS
secondary_cause: DIVERGENCIA_DE_REGLA_EN_EXTENSION_LINEAL
calculation_logic_equivalent: true
reproducible: true
next_action: Ampliar la reconciliación a una matriz de casos que active todas las ramas condicionales
```

La implementación Python es equivalente a la calculadora en su lógica de cálculo, pero no la reproduce con la versión de parámetros activa. Además, existe una diferencia en la condición de aplicación de la extensión lineal que debe resolver el responsable del modelo.
