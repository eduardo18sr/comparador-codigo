# CASE_002_CONTROLLED_RUN (versión sanitizada)

> Versión para repositorio. Se reemplazaron rutas personales, correos, nombres de personas,
> nombre del proyecto productivo y hashes reales por marcadores. Los resultados numéricos
> se conservan solo como conteos y diferencias, sin valores de parámetros del modelo.

## 1. Identificación

```yaml
case_id: CASE_002_CONTROLLED_RUN
case_type: CONTROLLED_REPRODUCIBLE_EXECUTION
case_status: EXECUTED_PENDING_DECISIONS
created_by: <VALIDADOR>
created_date: "2026-09-23"
source_case: CASE_001_AS_IS
model_family: "Curva PD temporal (modelo de score con calibración por plazo)"
```

## 2. Objetivo

Ejecutar el comparador desde cero con versión de código y parámetros identificados,
Excel de referencia preservado, configuración registrada, logs, reconciliación numérica
y revisión humana independiente.

## 3. Regla de aislamiento

```yaml
modify_CASE_001_AS_IS: false
reuse_CASE_001_outputs_as_CASE_002_outputs: false
execute_before_inputs_are_frozen: false
execute_before_config_is_frozen: false
```

## 4. Estructura

```text
CASE_002_CONTROLLED_RUN/
├── README.md
├── config/
├── inputs/
│   ├── excel/            # referencia metodológica (no versionar datos reales)
│   ├── python_project/   # snapshot del proyecto evaluado (no versionar)
│   └── parameters/       # snapshot de parámetros (no versionar)
├── logs/
├── outputs/
│   ├── RUN_A_ACTIVE_VERSION/
│   └── RUN_B_EXCEL_MATCHING_VERSION/
├── attempts/
├── evidence/
└── scripts/
```

Outputs, logs y attempts residen en el almacenamiento controlado del workspace:
`<CONTROLLED_STORAGE_ROOT>/CASE_002_CONTROLLED_RUN/`.

## 5. Estado

```yaml
code_version_confirmed: false
code_snapshot_captured: true
code_snapshot_integrity_confirmed: true
parameter_version_confirmed: true
controlled_execution_completed: true
numeric_reconciliation_completed: true
human_review_completed: false
case_frozen: false

python_project_snapshot:
  project: <PROYECTO_EVALUADO>
  manifest: inputs/python_project/PYTHON_PROJECT_MANIFEST.json
  commit_confirmed: false
  integrity_control: SHA-256 por archivo

parameter_snapshot:
  manifest: inputs/parameters/PARAMETERS_MANIFEST.json
  versions_captured: [VERSION_ACTIVA, VERSION_EXCEL, shared]
  execution_strategy: RUN_BOTH_VARIANTS

execution_configuration:
  base_config_source: CASE_001_AS_IS/config/execution_config.json
  run_a_config: <WORKSPACE_ROOT>/execution_config.run_a.json
  run_b_config: <WORKSPACE_ROOT>/execution_config.run_b.json
  effective_configs:
    - config/RUN_A_ACTIVE_VERSION.effective.json
    - config/RUN_B_EXCEL_MATCHING_VERSION.effective.json

controlled_deployment:
  method: IN_WORKSPACE_COPY_VERIFIED_BY_FILE_MANIFEST
  deployment_zip_used: false
  reason: Carga de archivos ZIP no disponible en el workspace
  status: DEPLOYED_AND_VERIFIED

runtime_copies:
  integrity: "N/N archivos por variante verificados por SHA-256"
  run_a_modified: false
  run_b_patch: "3 rutas de parámetros: VERSION_ACTIVA → VERSION_EXCEL en el motor de cálculo"
  run_b_patch_record: evidence/RUN_B_PATCH_RECORD.json

declared_deltas:
  D-001:
    change: "allowed_strategies con los nombres internos reales"
    effect: "NOT_SELECTED → AMBIGUOUS"
  D-002:
    change: "allowed_strategies restringido a temporal_curve"
    reason: "0.97 vs 0.95; diferencia menor al margen 0.03"
    effect: "AMBIGUOUS → SELECTED"

execution_attempts:
  ATTEMPT_01: {discovery: AMBIGUOUS, reconciliation: NOT_RUN}
  ATTEMPT_02: {discovery: SELECTED, strategy: temporal_curve, reconciliation: NOT_RUN,
               cause: "Evaluador de fórmulas sin soporte para IF"}

independent_numeric_reconciliation:
  method: INDEPENDENT_EXECUTION_OF_PRODUCTION_FUNCTIONS
  functions: [funcion_curva_v1, funcion_curva_v2]
  input: "1 punto de entrada (score y plazo de la referencia)"
  absolute_tolerance: 1.0e-8

framework_findings:
  - "Asume una sola estrategia por caso; la referencia tiene lógica escalar, tabular y temporal."
  - "temporal_curve recalcula el Excel contra sí mismo; no compara contra Python."
  - "El evaluador de fórmulas no soporta IF."
  - "No existe ruta que ejecute código Python; la reconciliación requiere prueba independiente."
```

## 6. Resultados

| Variante | Curva directa | Curva final extendida |
|---|---|---|
| RUN_A versión activa | 0 / 70 | 0 / 70 |
| RUN_B versión Excel | 70 / 70 (dif. máx. ~1e-10) | 10 / 70 |

```yaml
case_verdict: DIVERGE
calculation_logic_equivalent: true
findings:
  H-01: "La versión activa de parámetros no reproduce la referencia (0/70)."
  H-02: "Con la versión del Excel, Python reproduce exactamente la curva (70/70)."
  H-03: "La extensión lineal de la curva final no se aplica en Python para el plazo evaluado."
  H-04: "Límites de rango distintos (<=19/<=25 vs 19-24/25-36); sin confirmación numérica."
```

## 7. Decisiones pendientes

```yaml
D-1: "¿Cuál es la versión productiva de parámetros?"
D-2: "¿La extensión lineal aplica a todos los plazos o solo a plazos mayores a 24?"
owner: Responsable del modelo
```

## 8. Limitaciones

1. Un solo punto de entrada evaluado.
2. Código de producto asumido, no confirmado en la referencia.
3. Ramas condicionales no activadas (score alto, plazo > 24).
4. Sin commit Git; reproducibilidad por SHA-256.
5. No se identificó cuál función usa el flujo productivo.
