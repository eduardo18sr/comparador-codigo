# Caso de prueba: calculadora de curva PD temporal (estructura sintética)

> Reemplaza a `calculadora_final.xlsx` en el repositorio. El Excel real contiene parámetros
> del modelo y está marcado como uso interno: **no debe versionarse ni enviarse al LLM**.
> Este documento describe su estructura y propone valores sintéticos para construir fixtures.

## 1. Estructura de la hoja `Calculadora`

| Celda | Concepto | Fórmula |
|---|---|---|
| H6 | Offset | `=400-H7*LN(50)` |
| H7 | Factor | `=40/LN(2)` |
| H8 | Plazo (entrada) | valor |
| H11 | Score (entrada) | valor |
| H9 | xβ | `=-(H11-H6)/H7` |
| H10 | PD base | `=1/(1+EXP(-H9))` |
| K9:M11 | Tabla de calibración por plazo (plazo, intercepto, pendiente) | valores |
| H12 | xβ calibrado | `=IF(H8<=19, L9+M9*H9, IF(H8<=25, L10+M10*H9, L11+M11*H9))` |
| H13 | PD calibrada | `=1/(1+EXP(-H12))` |
| H14 | Score calibrado | `=ROUND(-H12*H7+H6, 0)` |
| I20:BZ20 | Periodos 3 a 72 | valores |
| I21:BZ26 | α(t), β(t) para tres rangos de plazo | valores |
| I27:BZ27 | PD temporal | `=IF(H8<=19, 1/(1+EXP(-(α1+β1*H12))), …)` |
| I28:R28 | Curva final, periodos 3-12 | `=I27` (copia) |
| S28:BZ28 | Curva final, periodos 13-72 | `=anterior + J34` |
| H34 | Factor flat | valor |
| I34 | Objetivo periodo 36 | `=H34*R27` |
| J34 | Incremento lineal | `=(I34-R27)/24` |

Notas:
- Offset y factor son constantes de escala estándar (no sensibles): ≈174.2458 y ≈57.7078.
- Las fórmulas de las filas 27 y 28 son las que el comparador debe reproducir.

## 2. Valores sintéticos para fixtures

Usar estos valores **inventados**; no reproducen el modelo real.

```yaml
inputs: {score: 300, plazo: 18}
calibracion_por_plazo:
  - {plazo_max: 18, intercepto: 0.10, pendiente: 1.00}
  - {plazo_max: 24, intercepto: 0.00, pendiente: 1.00}
  - {plazo_max: 36, intercepto: 0.00, pendiente: 1.00}
alpha_t: "rampa lineal de -3.0 (t=3) a 0.5 (t=18), constante después"
beta_t: "constante 1.0"
factor_flat: 2.0
```

## 3. Escenario de regresión que el fixture debe reproducir

Crear dos archivos de parámetros sintéticos:

| Archivo | Contenido | Uso en código |
|---|---|---|
| `theta_Tt_VERSION_EXCEL.csv` | Mismos α(t), β(t) que el fixture Excel | referenciado solo en una línea **comentada** |
| `theta_Tt_VERSION_ACTIVA.csv` | α(t) desplazado +0.5 | referenciado en la línea **activa** |

Resultado esperado del comparador:

```yaml
uso_de_parametros:
  theta_Tt_VERSION_ACTIVA.csv: SE_USA_SIN_COINCIDENCIA
  theta_Tt_VERSION_EXCEL.csv: COINCIDE_PERO_NO_SE_USA
reconciliacion:
  version_activa_vs_curva_directa: "0/70"
  version_excel_vs_curva_directa: "70/70"
  version_excel_vs_curva_final: "10/70  (solo periodos 3-12)"
veredicto: DIVERGE
causa: DIVERGENCIA_DE_VERSION_DE_PARAMETROS
```

Esto reproduce, con datos ficticios, el hallazgo real del caso controlado.
