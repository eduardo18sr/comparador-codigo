from pathlib import Path
from datetime import datetime
from copy import deepcopy
import hashlib
import json


case_root = (
    Path(__file__)
    .resolve()
    .parent
    .parent
)

config_directory = (
    case_root
    / "config"
)

base_config_path = (
    config_directory
    / "execution_config.base.json"
)

inspection_path = (
    config_directory
    / "execution_config.inspection.json"
)

variants_manifest_path = (
    config_directory
    / "execution_variants.json"
)

run_a_config_path = (
    config_directory
    / "execution_config.run_a.json"
)

run_b_config_path = (
    config_directory
    / "execution_config.run_b.json"
)

runtime_plan_path = (
    config_directory
    / "variant_runtime_plan.json"
)


def calculate_sha256(file_path: Path) -> str:
    sha256 = hashlib.sha256()

    with file_path.open("rb") as file:
        for block in iter(
            lambda: file.read(1024 * 1024),
            b"",
        ):
            sha256.update(block)

    return sha256.hexdigest()


def load_json(file_path: Path):
    with file_path.open(
        "r",
        encoding="utf-8-sig",
    ) as file:
        return json.load(file)


def write_json(
    file_path: Path,
    data,
):
    with file_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2,
        )


# --------------------------------------------------
# 1. Validaciones
# --------------------------------------------------

required_files = [
    base_config_path,
    inspection_path,
    variants_manifest_path,
]

for required_file in required_files:
    if not required_file.exists():
        raise FileNotFoundError(
            f"No se encontró: {required_file}"
        )

base_config = load_json(
    base_config_path
)

inspection = load_json(
    inspection_path
)

variants_manifest = load_json(
    variants_manifest_path
)

inspection_status = inspection.get(
    "inspection_status"
)

if inspection_status != "READY_FOR_VARIANT_DESIGN":
    raise ValueError(
        "La configuración base no está "
        "habilitada para diseñar variantes. "
        f"Estado actual: {inspection_status}"
    )

if not isinstance(base_config, dict):
    raise TypeError(
        "execution_config.base.json debe "
        "contener un objeto JSON."
    )


# --------------------------------------------------
# 2. Rutas controladas de Databricks
# --------------------------------------------------

controlled_dbfs_root = (
    "/dbfs/FileStore/comparador/"
    "controlled/"
    "CASE_002_CONTROLLED_RUN"
)

controlled_workspace_root = (
    "/Workspace/Users/"
    "eduardosaldana@bcp.com.pe/"
    "proyecto/"
    "controlled/"
    "CASE_002_CONTROLLED_RUN"
)

controlled_excel_path = (
    f"{controlled_dbfs_root}/"
    "inputs/excel/"
    "calculadora_final.xlsx"
)


# --------------------------------------------------
# 3. Crear RUN_A
# --------------------------------------------------

run_a_config = deepcopy(
    base_config
)

run_a_config["excel_path"] = (
    controlled_excel_path
)

run_a_config["project_root"] = (
    f"{controlled_workspace_root}/"
    "RUN_A_ACTIVE_SEP24_V2/"
    "python_project"
)

run_a_config["output_dir"] = (
    f"{controlled_dbfs_root}/"
    "outputs/"
    "RUN_A_ACTIVE_SEP24_V2"
)


# --------------------------------------------------
# 4. Crear RUN_B
# --------------------------------------------------

run_b_config = deepcopy(
    base_config
)

run_b_config["excel_path"] = (
    controlled_excel_path
)

run_b_config["project_root"] = (
    f"{controlled_workspace_root}/"
    "RUN_B_EXCEL_MATCHING_202605/"
    "python_project"
)

run_b_config["output_dir"] = (
    f"{controlled_dbfs_root}/"
    "outputs/"
    "RUN_B_EXCEL_MATCHING_202605"
)


# --------------------------------------------------
# 5. Guardar configuraciones
# --------------------------------------------------

write_json(
    run_a_config_path,
    run_a_config,
)

write_json(
    run_b_config_path,
    run_b_config,
)


# --------------------------------------------------
# 6. Plan de activación de parámetros
# --------------------------------------------------

runtime_plan = {
    "case_id": (
        "CASE_002_CONTROLLED_RUN"
    ),
    "plan_type": (
        "VARIANT_RUNTIME_PLAN"
    ),
    "generated_at": (
        datetime.now()
        .astimezone()
        .isoformat()
    ),
    "execution_allowed": False,
    "source_snapshot_mutation_allowed": False,
    "runtime_copy_required": True,
    "controlled_excel_path": (
        controlled_excel_path
    ),
    "variants": [
        {
            "variant_id": (
                "RUN_A_ACTIVE_SEP24_V2"
            ),
            "config_file": (
                "config/"
                "execution_config.run_a.json"
            ),
            "parameter_version": (
                "sep24_v2"
            ),
            "runtime_project_root": (
                run_a_config["project_root"]
            ),
            "output_directory": (
                run_a_config["output_dir"]
            ),
            "parameter_actions": [
                {
                    "target_file": (
                        "clv/params/"
                        "pd_thetaT_actualizado_"
                        "sep24_v2.csv"
                    ),
                    "source_file": (
                        "pd_thetaT_actualizado_"
                        "sep24_v2.csv"
                    ),
                    "action": "KEEP_ACTIVE",
                },
                {
                    "target_file": (
                        "clv/params/"
                        "pd_thetaTt_actualizado_"
                        "sep24_v2.csv"
                    ),
                    "source_file": (
                        "pd_thetaTt_actualizado_"
                        "sep24_v2.csv"
                    ),
                    "action": "KEEP_ACTIVE",
                },
                {
                    "target_file": (
                        "clv/params/"
                        "pd_rango_Tt_sep24_v2.csv"
                    ),
                    "source_file": (
                        "pd_rango_Tt_sep24_v2.csv"
                    ),
                    "action": "KEEP_ACTIVE",
                },
            ],
            "code_reference_change": (
                "NONE"
            ),
            "execution_status": "NOT_RUN",
        },
        {
            "variant_id": (
                "RUN_B_EXCEL_MATCHING_202605"
            ),
            "config_file": (
                "config/"
                "execution_config.run_b.json"
            ),
            "parameter_version": (
                "202605"
            ),
            "runtime_project_root": (
                run_b_config["project_root"]
            ),
            "output_directory": (
                run_b_config["output_dir"]
            ),
            "parameter_actions": [
                {
                    "target_role": (
                        "param_T"
                    ),
                    "source_file": (
                        "pd_thetaT_actualizado_"
                        "202605.csv"
                    ),
                    "action": (
                        "ACTIVATE_IN_RUNTIME_COPY"
                    ),
                },
                {
                    "target_role": (
                        "param_Tt"
                    ),
                    "source_file": (
                        "pd_thetaTt_actualizado_"
                        "202605.csv"
                    ),
                    "action": (
                        "ACTIVATE_IN_RUNTIME_COPY"
                    ),
                },
                {
                    "target_role": (
                        "param_rangoTt"
                    ),
                    "source_file": (
                        "pd_rango_Tt_202605.csv"
                    ),
                    "action": (
                        "ACTIVATE_IN_RUNTIME_COPY"
                    ),
                },
            ],
            "code_reference_change": (
                "PENDING_CONTROLLED_PATCH"
            ),
            "execution_status": "NOT_RUN",
        },
    ],
    "remaining_gates": [
        (
            "Subir el Excel, snapshot Python "
            "y parámetros al espacio controlado."
        ),
        (
            "Crear copias runtime independientes "
            "para RUN_A y RUN_B."
        ),
        (
            "Aplicar el cambio 202605 únicamente "
            "en la copia runtime de RUN_B."
        ),
        (
            "Registrar el parche aplicado "
            "a RUN_B."
        ),
        (
            "Configurar logs runtime."
        ),
        (
            "Validar rutas antes de ejecutar."
        ),
    ],
}


# --------------------------------------------------
# 7. Integridad de configuraciones
# --------------------------------------------------

runtime_plan["configuration_hashes"] = {
    "base_config_sha256": (
        calculate_sha256(
            base_config_path
        )
    ),
    "run_a_config_sha256": (
        calculate_sha256(
            run_a_config_path
        )
    ),
    "run_b_config_sha256": (
        calculate_sha256(
            run_b_config_path
        )
    ),
}

write_json(
    runtime_plan_path,
    runtime_plan,
)


# --------------------------------------------------
# 8. Actualizar matriz de variantes
# --------------------------------------------------

for variant in variants_manifest.get(
    "variants",
    [],
):
    variant_id = variant.get(
        "variant_id"
    )

    if variant_id == (
        "RUN_A_ACTIVE_SEP24_V2"
    ):
        variant["config_file"] = (
            "config/"
            "execution_config.run_a.json"
        )

        variant["config_sha256"] = (
            runtime_plan[
                "configuration_hashes"
            ][
                "run_a_config_sha256"
            ]
        )

    elif variant_id == (
        "RUN_B_EXCEL_MATCHING_202605"
    ):
        variant["config_file"] = (
            "config/"
            "execution_config.run_b.json"
        )

        variant["config_sha256"] = (
            runtime_plan[
                "configuration_hashes"
            ][
                "run_b_config_sha256"
            ]
        )

variants_manifest[
    "runtime_plan"
] = (
    "config/"
    "variant_runtime_plan.json"
)

variants_manifest[
    "variant_configs_created"
] = True

variants_manifest[
    "execution_allowed"
] = False

write_json(
    variants_manifest_path,
    variants_manifest,
)


# --------------------------------------------------
# 9. Resumen
# --------------------------------------------------

print("=" * 72)
print("CONFIGURACIONES DE VARIANTES GENERADAS")
print("=" * 72)

print(
    f"RUN_A: {run_a_config_path}"
)

print(
    f"RUN_B: {run_b_config_path}"
)

print(
    f"Plan runtime: {runtime_plan_path}"
)

print(
    "\nConfiguración base modificada: NO"
)

print(
    "Snapshot original modificado: NO"
)

print(
    "Ejecución permitida: NO"
)

print(
    "\nSiguiente paso:"
)

print(
    "Preparar el paquete de despliegue "
    "controlado para Databricks."
)