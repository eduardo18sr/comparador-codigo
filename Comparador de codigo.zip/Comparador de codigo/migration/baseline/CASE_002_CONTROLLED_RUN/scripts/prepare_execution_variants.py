from pathlib import Path
from datetime import datetime
import hashlib
import json
import shutil


case_002_root = (
    Path(__file__)
    .resolve()
    .parent
    .parent
)

baseline_root = (
    case_002_root
    .parent
)

case_001_root = (
    baseline_root
    / "CASE_001_AS_IS"
)

source_config_path = (
    case_001_root
    / "config"
    / "execution_config.json"
)

config_directory = (
    case_002_root
    / "config"
)

base_config_path = (
    config_directory
    / "execution_config.base.json"
)

variants_path = (
    config_directory
    / "execution_variants.json"
)


def calculate_sha256(
    file_path: Path,
) -> str:
    sha256 = hashlib.sha256()

    with file_path.open("rb") as file:
        for block in iter(
            lambda: file.read(
                1024 * 1024
            ),
            b"",
        ):
            sha256.update(block)

    return sha256.hexdigest()


# --------------------------------------------------
# 1. Validaciones
# --------------------------------------------------

if not case_001_root.exists():
    raise FileNotFoundError(
        "No se encontró CASE_001_AS_IS: "
        f"{case_001_root}"
    )

if not source_config_path.exists():
    raise FileNotFoundError(
        "No se encontró la configuración "
        "del caso AS-IS: "
        f"{source_config_path}"
    )

parameter_manifest_path = (
    case_002_root
    / "inputs"
    / "parameters"
    / "PARAMETERS_MANIFEST.json"
)

python_manifest_path = (
    case_002_root
    / "inputs"
    / "python_project"
    / "PYTHON_PROJECT_MANIFEST.json"
)

excel_manifest_path = (
    case_002_root
    / "inputs"
    / "excel"
    / "EXCEL_INPUT_MANIFEST.json"
)

required_manifests = [
    parameter_manifest_path,
    python_manifest_path,
    excel_manifest_path,
]

for manifest_path in required_manifests:
    if not manifest_path.exists():
        raise FileNotFoundError(
            f"Falta el manifiesto: "
            f"{manifest_path}"
        )


# --------------------------------------------------
# 2. Copiar configuración base
# --------------------------------------------------

config_directory.mkdir(
    parents=True,
    exist_ok=True,
)

shutil.copy2(
    source_config_path,
    base_config_path,
)

source_config_sha256 = (
    calculate_sha256(
        source_config_path
    )
)

base_config_sha256 = (
    calculate_sha256(
        base_config_path
    )
)

if (
    source_config_sha256
    != base_config_sha256
):
    raise ValueError(
        "La copia de la configuración base "
        "no conserva el mismo SHA-256."
    )


# --------------------------------------------------
# 3. Leer manifiestos
# --------------------------------------------------

with parameter_manifest_path.open(
    "r",
    encoding="utf-8",
) as file:
    parameter_manifest = json.load(file)

with python_manifest_path.open(
    "r",
    encoding="utf-8",
) as file:
    python_manifest = json.load(file)

with excel_manifest_path.open(
    "r",
    encoding="utf-8",
) as file:
    excel_manifest = json.load(file)


# --------------------------------------------------
# 4. Crear matriz de variantes
# --------------------------------------------------

variants = {
    "case_id": (
        "CASE_002_CONTROLLED_RUN"
    ),
    "manifest_type": (
        "EXECUTION_VARIANTS"
    ),
    "created_at": (
        datetime.now()
        .astimezone()
        .isoformat()
    ),
    "execution_allowed": False,
    "base_configuration": {
        "source": (
            "../CASE_001_AS_IS/"
            "config/execution_config.json"
        ),
        "controlled_copy": (
            "config/"
            "execution_config.base.json"
        ),
        "sha256": (
            base_config_sha256
        ),
        "modified": False,
    },
    "controlled_inputs": {
        "excel": {
            "file": (
                excel_manifest.get(
                    "relative_path"
                )
            ),
            "sha256": (
                excel_manifest.get(
                    "sha256"
                )
            ),
        },
        "python_project": {
            "snapshot_file": (
                python_manifest.get(
                    "snapshot_file"
                )
            ),
            "sha256": (
                python_manifest.get(
                    "snapshot_sha256"
                )
            ),
            "commit_confirmed": (
                python_manifest.get(
                    "commit_confirmed",
                    False,
                )
            ),
        },
        "parameters": {
            "snapshot_file": (
                parameter_manifest.get(
                    "snapshot_file"
                )
            ),
            "sha256": (
                parameter_manifest.get(
                    "snapshot_sha256"
                )
            ),
        },
    },
    "variants": [
        {
            "variant_id": (
                "RUN_A_ACTIVE_SEP24_V2"
            ),
            "description": (
                "Ejecutar con la versión "
                "activa observada en el código."
            ),
            "parameter_version": (
                "sep24_v2"
            ),
            "parameter_role": (
                "ACTIVE_CODE_VERSION"
            ),
            "output_directory": (
                "outputs/"
                "RUN_A_ACTIVE_SEP24_V2"
            ),
            "log_file": (
                "logs/"
                "RUN_A_ACTIVE_SEP24_V2.log"
            ),
            "execution_status": (
                "NOT_RUN"
            ),
            "execution_allowed": False,
        },
        {
            "variant_id": (
                "RUN_B_EXCEL_MATCHING_202605"
            ),
            "description": (
                "Ejecutar con la versión "
                "que coincide con el Excel."
            ),
            "parameter_version": (
                "202605"
            ),
            "parameter_role": (
                "EXCEL_MATCHING_VERSION"
            ),
            "output_directory": (
                "outputs/"
                "RUN_B_EXCEL_MATCHING_202605"
            ),
            "log_file": (
                "logs/"
                "RUN_B_EXCEL_MATCHING_202605.log"
            ),
            "execution_status": (
                "NOT_RUN"
            ),
            "execution_allowed": False,
        },
    ],
    "comparison_policy": {
        "run_both_variants": True,
        "overwrite_source_snapshot": False,
        "overwrite_parameter_snapshot": False,
        "reuse_case_001_outputs": False,
        "compare_variant_outputs": True,
        "compare_each_variant_to_excel": True,
    },
    "remaining_gates": [
        (
            "Revisar la estructura real de "
            "execution_config.base.json."
        ),
        (
            "Crear una configuración ejecutable "
            "para cada variante."
        ),
        (
            "Configurar captura de logs runtime."
        ),
        (
            "Configurar directorios de salida "
            "aislados."
        ),
        (
            "Validar que ningún secreto quede "
            "almacenado en la configuración."
        ),
    ],
}

with variants_path.open(
    "w",
    encoding="utf-8",
) as file:
    json.dump(
        variants,
        file,
        ensure_ascii=False,
        indent=2,
    )


# --------------------------------------------------
# 5. Crear carpetas aisladas
# --------------------------------------------------

directories_to_create = [
    (
        case_002_root
        / "outputs"
        / "RUN_A_ACTIVE_SEP24_V2"
    ),
    (
        case_002_root
        / "outputs"
        / "RUN_B_EXCEL_MATCHING_202605"
    ),
]

for directory in directories_to_create:
    directory.mkdir(
        parents=True,
        exist_ok=True,
    )


# --------------------------------------------------
# 6. Mostrar resumen
# --------------------------------------------------

print("=" * 72)
print("PREPARACIÓN DE VARIANTES CONTROLADAS")
print("=" * 72)

print(
    "Configuración base:"
)

print(
    base_config_path
)

print(
    "\nSHA-256 configuración base:"
)

print(
    base_config_sha256
)

print(
    "\nMatriz de variantes:"
)

print(
    variants_path
)

print(
    "\nVariantes preparadas:"
)

for variant in variants["variants"]:
    print(
        f"  - {variant['variant_id']}"
        f" | {variant['parameter_version']}"
        f" | {variant['execution_status']}"
    )

print(
    "\nEjecución permitida: NO"
)