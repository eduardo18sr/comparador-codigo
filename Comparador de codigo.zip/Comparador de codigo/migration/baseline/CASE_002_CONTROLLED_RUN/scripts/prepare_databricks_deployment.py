from pathlib import Path
from datetime import datetime
import hashlib
import json
import shutil
import zipfile


case_root = Path(__file__).resolve().parent.parent

deployment_root = case_root / "deployment"
payload_root = deployment_root / "payload"
manifest_path = deployment_root / "DEPLOYMENT_MANIFEST.json"
zip_path = deployment_root / "CASE_002_CONTROLLED_RUN_databricks_deployment.zip"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def copy_required(source: Path, destination: Path) -> dict:
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"No se encontró el archivo requerido: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    return {
        "relative_path": destination.relative_to(payload_root).as_posix(),
        "size_bytes": destination.stat().st_size,
        "sha256": sha256(destination),
    }


required_files = [
    (
        case_root / "inputs" / "excel" / "calculadora_final.xlsx",
        Path("inputs/excel/calculadora_final.xlsx"),
    ),
    (
        case_root / "inputs" / "excel" / "EXCEL_INPUT_MANIFEST.json",
        Path("inputs/excel/EXCEL_INPUT_MANIFEST.json"),
    ),
    (
        case_root
        / "inputs"
        / "python_project"
        / "prdl-app-clv-pyme-ct-af-modelos-feature-inicial_snapshot.zip",
        Path(
            "inputs/python_project/"
            "prdl-app-clv-pyme-ct-af-modelos-feature-inicial_snapshot.zip"
        ),
    ),
    (
        case_root / "inputs" / "python_project" / "PYTHON_PROJECT_MANIFEST.json",
        Path("inputs/python_project/PYTHON_PROJECT_MANIFEST.json"),
    ),
    (
        case_root
        / "inputs"
        / "parameters"
        / "CASE_002_CONTROLLED_RUN_parameters.zip",
        Path("inputs/parameters/CASE_002_CONTROLLED_RUN_parameters.zip"),
    ),
    (
        case_root / "inputs" / "parameters" / "PARAMETERS_MANIFEST.json",
        Path("inputs/parameters/PARAMETERS_MANIFEST.json"),
    ),
    (
        case_root / "config" / "execution_config.run_a.json",
        Path("config/execution_config.run_a.json"),
    ),
    (
        case_root / "config" / "execution_config.run_b.json",
        Path("config/execution_config.run_b.json"),
    ),
    (
        case_root / "config" / "execution_variants.json",
        Path("config/execution_variants.json"),
    ),
    (
        case_root / "config" / "variant_runtime_plan.json",
        Path("config/variant_runtime_plan.json"),
    ),
]

if payload_root.exists():
    shutil.rmtree(payload_root)
payload_root.mkdir(parents=True, exist_ok=True)

deployment_root.mkdir(parents=True, exist_ok=True)
if zip_path.exists():
    zip_path.unlink()

captured_files = []
for source, relative_destination in required_files:
    captured_files.append(
        copy_required(source, payload_root / relative_destination)
    )

runtime_readme = payload_root / "RUNTIME_README.txt"
runtime_readme.write_text(
    "CASE_002_CONTROLLED_RUN\n"
    "\n"
    "Este paquete contiene dos variantes controladas.\n"
    "No ejecutar directamente después de subirlo.\n"
    "Primero deben prepararse dos copias runtime independientes del proyecto.\n"
    "RUN_A conserva sep24_v2.\n"
    "RUN_B activa 202605 únicamente en su copia runtime.\n"
    "La ejecución permanece bloqueada hasta configurar logs y validar rutas.\n",
    encoding="utf-8",
)
captured_files.append(
    {
        "relative_path": "RUNTIME_README.txt",
        "size_bytes": runtime_readme.stat().st_size,
        "sha256": sha256(runtime_readme),
    }
)

manifest = {
    "case_id": "CASE_002_CONTROLLED_RUN",
    "manifest_type": "DATABRICKS_DEPLOYMENT_MANIFEST",
    "generated_at": datetime.now().astimezone().isoformat(),
    "execution_allowed": False,
    "deployment_status": "PACKAGED_NOT_DEPLOYED",
    "variant_ids": [
        "RUN_A_ACTIVE_SEP24_V2",
        "RUN_B_EXCEL_MATCHING_202605",
    ],
    "file_count": len(captured_files),
    "files": captured_files,
    "required_runtime_gates": [
        "Upload deployment ZIP to controlled FileStore path.",
        "Verify deployment ZIP SHA-256 after upload.",
        "Create isolated runtime project copies for RUN_A and RUN_B.",
        "Apply 202605 patch only to RUN_B runtime copy.",
        "Configure runtime logs for both variants.",
        "Validate all configured paths before execution.",
    ],
}

manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for file_path in sorted(payload_root.rglob("*")):
        if file_path.is_file():
            archive.write(
                file_path,
                arcname=(Path("CASE_002_CONTROLLED_RUN") / file_path.relative_to(payload_root)).as_posix(),
            )
    archive.write(
        manifest_path,
        arcname="CASE_002_CONTROLLED_RUN/DEPLOYMENT_MANIFEST.json",
    )

manifest["deployment_zip"] = zip_path.name
manifest["deployment_zip_size_bytes"] = zip_path.stat().st_size
manifest["deployment_zip_sha256"] = sha256(zip_path)
manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

print("=" * 72)
print("PAQUETE DE DESPLIEGUE CONTROLADO")
print("=" * 72)
print(f"Archivos incorporados: {len(captured_files)}")
print(f"ZIP: {zip_path}")
print(f"SHA-256: {manifest['deployment_zip_sha256']}")
print(f"Manifiesto: {manifest_path}")
print("Estado: PACKAGED_NOT_DEPLOYED")
print("Ejecución permitida: NO")
