from pathlib import Path
from datetime import datetime
import hashlib
import json
import sys


case_root = Path(__file__).resolve().parent.parent

excel_directory = (
    case_root
    / "inputs"
    / "excel"
)

manifest_path = (
    excel_directory
    / "EXCEL_INPUT_MANIFEST.json"
)

excel_files = sorted(
    file_path
    for file_path in excel_directory.iterdir()
    if (
        file_path.is_file()
        and file_path.suffix.lower()
        in {".xlsx", ".xlsm", ".xls"}
        and file_path.name
        != "EXCEL_INPUT_MANIFEST.json"
    )
)

if len(excel_files) == 0:
    raise FileNotFoundError(
        "No se encontró ningún Excel dentro de "
        f"{excel_directory}"
    )

if len(excel_files) > 1:
    raise ValueError(
        "Se esperaba exactamente un Excel, "
        f"pero se encontraron {len(excel_files)}: "
        + ", ".join(
            file_path.name
            for file_path in excel_files
        )
    )

excel_path = excel_files[0]

sha256 = hashlib.sha256()

with excel_path.open("rb") as file:
    for block in iter(
        lambda: file.read(1024 * 1024),
        b"",
    ):
        sha256.update(block)

manifest = {
    "case_id": "CASE_002_CONTROLLED_RUN",
    "manifest_type": "EXCEL_INPUT_MANIFEST",
    "captured_at": (
        datetime.now()
        .astimezone()
        .isoformat()
    ),
    "relative_path": (
        excel_path
        .relative_to(case_root)
        .as_posix()
    ),
    "file_name": excel_path.name,
    "extension": excel_path.suffix.lower(),
    "size_bytes": excel_path.stat().st_size,
    "sha256": sha256.hexdigest(),
    "source_case": "CASE_001_AS_IS",
    "source_file": (
        "Excel utilizado en la ejecución "
        "capturada del caso AS-IS"
    ),
    "modified_after_capture": False,
    "validation_status": "CAPTURED",
}

with manifest_path.open(
    "w",
    encoding="utf-8",
) as file:
    json.dump(
        manifest,
        file,
        ensure_ascii=False,
        indent=2,
    )

print("=" * 72)
print("CAPTURA DEL EXCEL CONTROLADO")
print("=" * 72)
print(f"Archivo: {excel_path.name}")
print(f"Tamaño: {excel_path.stat().st_size} bytes")
print(f"SHA-256: {manifest['sha256']}")
print(f"Estado: {manifest['validation_status']}")
print(f"Manifiesto: {manifest_path}")

if manifest["validation_status"] != "CAPTURED":
    sys.exit(1)