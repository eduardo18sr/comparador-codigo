from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import sys


case_root = Path(__file__).resolve().parent.parent

config_path = (
    case_root
    / "config"
    / "execution_config.base.json"
)

report_path = (
    case_root
    / "config"
    / "execution_config.inspection.json"
)


# --------------------------------------------------
# Patrones sensibles
# --------------------------------------------------

sensitive_key_patterns = [
    r"^token$",
    r"^access[_-]?token$",
    r"^refresh[_-]?token$",
    r"^id[_-]?token$",
    r"^auth[_-]?token$",
    r"^bearer[_-]?token$",
    r"^sas[_-]?token$",
    r"secret",
    r"password",
    r"passwd",
    r"api[_-]?key",
    r"access[_-]?key",
    r"private[_-]?key",
    r"client[_-]?secret",
    r"authorization",
    r"credential",
    r"bearer",
]

safe_key_patterns = [
    r"^max[_-]?tokens$",
    r"^min[_-]?tokens$",
    r"^token[_-]?limit$",
    r"^token[_-]?count$",
    r"^input[_-]?tokens$",
    r"^output[_-]?tokens$",
]


placeholder_values = {
    "",
    "<REDACTED>",
    "REDACTED",
    "***",
    "PENDIENTE",
    "NO_CONFIGURADO",
    "NONE",
    "NULL",
}


def calculate_sha256(file_path: Path) -> str:
    sha256 = hashlib.sha256()

    with file_path.open("rb") as file:
        for block in iter(
            lambda: file.read(1024 * 1024),
            b"",
        ):
            sha256.update(block)

    return sha256.hexdigest()


def is_sensitive_key(key) -> bool:
    key_text = str(key).strip().lower()

    is_explicitly_safe = any(
        re.search(
            pattern,
            key_text,
            flags=re.IGNORECASE,
        )
        for pattern in safe_key_patterns
    )

    if is_explicitly_safe:
        return False

    return any(
        re.search(
            pattern,
            key_text,
            flags=re.IGNORECASE,
        )
        for pattern in sensitive_key_patterns
    )


def classify_value(value):
    if value is None:
        return {
            "value_type": "null",
            "is_empty": True,
        }

    if isinstance(value, bool):
        return {
            "value_type": "boolean",
            "is_empty": False,
        }

    if isinstance(value, int):
        return {
            "value_type": "integer",
            "is_empty": False,
        }

    if isinstance(value, float):
        return {
            "value_type": "number",
            "is_empty": False,
        }

    if isinstance(value, str):
        normalized = value.strip().upper()

        return {
            "value_type": "string",
            "is_empty": normalized in placeholder_values,
        }

    if isinstance(value, list):
        return {
            "value_type": "array",
            "is_empty": len(value) == 0,
        }

    if isinstance(value, dict):
        return {
            "value_type": "object",
            "is_empty": len(value) == 0,
        }

    return {
        "value_type": type(value).__name__,
        "is_empty": False,
    }


def inspect_node(value, path="$"):
    entries = []
    sensitive_findings = []

    if isinstance(value, dict):
        for key, child_value in value.items():
            child_path = f"{path}.{key}"
            classification = classify_value(child_value)
            key_is_sensitive = is_sensitive_key(key)

            entries.append(
                {
                    "path": child_path,
                    "key": str(key),
                    "value_type": classification["value_type"],
                    "is_empty_or_placeholder": classification["is_empty"],
                    "sensitive_key": key_is_sensitive,
                }
            )

            if key_is_sensitive:
                value_is_protected = (
                    child_value is None
                    or (
                        isinstance(child_value, str)
                        and child_value.strip().upper() in placeholder_values
                    )
                )

                sensitive_findings.append(
                    {
                        "path": child_path,
                        "status": (
                            "PROTECTED_OR_EMPTY"
                            if value_is_protected
                            else "POTENTIAL_SECRET"
                        ),
                        "value_type": classification["value_type"],
                    }
                )

            nested_entries, nested_sensitive = inspect_node(
                child_value,
                child_path,
            )

            entries.extend(nested_entries)
            sensitive_findings.extend(nested_sensitive)

    elif isinstance(value, list):
        for index, child_value in enumerate(value):
            child_path = f"{path}[{index}]"
            classification = classify_value(child_value)

            entries.append(
                {
                    "path": child_path,
                    "key": None,
                    "value_type": classification["value_type"],
                    "is_empty_or_placeholder": classification["is_empty"],
                    "sensitive_key": False,
                }
            )

            nested_entries, nested_sensitive = inspect_node(
                child_value,
                child_path,
            )

            entries.extend(nested_entries)
            sensitive_findings.extend(nested_sensitive)

    return entries, sensitive_findings


# --------------------------------------------------
# Validar y leer configuración
# --------------------------------------------------

if not config_path.exists():
    raise FileNotFoundError(
        "No se encontró la configuración base: "
        f"{config_path}"
    )

try:
    with config_path.open(
        "r",
        encoding="utf-8-sig",
    ) as file:
        config = json.load(file)

except json.JSONDecodeError as error:
    print("La configuración no contiene JSON válido.")
    print(f"Línea: {error.lineno}")
    print(f"Columna: {error.colno}")
    print(f"Detalle: {error.msg}")
    sys.exit(1)

if not isinstance(config, dict):
    raise TypeError(
        "La raíz de execution_config.base.json "
        "debe ser un objeto JSON."
    )


# --------------------------------------------------
# Inspeccionar
# --------------------------------------------------

entries, sensitive_findings = inspect_node(config)

potential_secrets = [
    item
    for item in sensitive_findings
    if item["status"] == "POTENTIAL_SECRET"
]

protected_sensitive_values = [
    item
    for item in sensitive_findings
    if item["status"] == "PROTECTED_OR_EMPTY"
]

top_level_keys = list(config.keys())

inspection_status = (
    "BLOCKED_POTENTIAL_SECRETS"
    if potential_secrets
    else "READY_FOR_VARIANT_DESIGN"
)


# --------------------------------------------------
# Crear reporte sin exponer valores
# --------------------------------------------------

report = {
    "case_id": "CASE_002_CONTROLLED_RUN",
    "report_type": "EXECUTION_CONFIG_INSPECTION",
    "generated_at": datetime.now().astimezone().isoformat(),
    "config_file": "config/execution_config.base.json",
    "config_sha256": calculate_sha256(config_path),
    "json_valid": True,
    "root_type": "object",
    "top_level_keys": top_level_keys,
    "top_level_key_count": len(top_level_keys),
    "inspected_entry_count": len(entries),
    "potential_secret_count": len(potential_secrets),
    "protected_sensitive_count": len(protected_sensitive_values),
    "inspection_status": inspection_status,
    "potential_secrets": potential_secrets,
    "protected_sensitive_values": protected_sensitive_values,
    "structure": entries,
    "next_action": (
        "Redactar secretos antes de continuar."
        if potential_secrets
        else "Generar configuraciones ejecutables para RUN_A y RUN_B."
    ),
}

report_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with report_path.open(
    "w",
    encoding="utf-8",
) as file:
    json.dump(
        report,
        file,
        ensure_ascii=False,
        indent=2,
    )


# --------------------------------------------------
# Mostrar resumen seguro
# --------------------------------------------------

print("=" * 72)
print("INSPECCIÓN DE CONFIGURACIÓN BASE")
print("=" * 72)
print(f"Archivo: {config_path}")
print("JSON válido: Sí")
print("Claves principales:")

for key in top_level_keys:
    print(f"  - {key}")

print(f"\nEntradas inspeccionadas: {len(entries)}")
print(f"Posibles secretos con valor: {len(potential_secrets)}")
print(
    "Campos sensibles protegidos o vacíos: "
    f"{len(protected_sensitive_values)}"
)
print(f"Estado: {inspection_status}")

if potential_secrets:
    print(
        "\nATENCIÓN: se detectaron posibles secretos "
        "en estas rutas:"
    )

    for item in potential_secrets:
        print(f"  - {item['path']}")

    print(
        "\nNo ejecutes el comparador ni compartas el archivo "
        "hasta redactar esos valores."
    )
else:
    print(
        "\nNo se detectaron valores sensibles visibles "
        "mediante los patrones revisados."
    )

print("\nReporte generado:")
print(report_path)

if potential_secrets:
    sys.exit(2)
