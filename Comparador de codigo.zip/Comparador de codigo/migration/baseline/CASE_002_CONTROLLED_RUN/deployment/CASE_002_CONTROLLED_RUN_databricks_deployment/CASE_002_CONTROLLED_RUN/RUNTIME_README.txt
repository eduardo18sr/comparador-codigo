CASE_002_CONTROLLED_RUN

Este paquete contiene dos variantes controladas.
No ejecutar directamente después de subirlo.
Primero deben prepararse dos copias runtime independientes del proyecto.
RUN_A conserva sep24_v2.
RUN_B activa 202605 únicamente en su copia runtime.
La ejecución permanece bloqueada hasta configurar logs y validar rutas.
