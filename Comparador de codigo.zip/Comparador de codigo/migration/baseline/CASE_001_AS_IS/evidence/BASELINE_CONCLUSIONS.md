# Conclusiones del baseline AS-IS

## 1. Control del documento

```yaml
case_id: CASE_001_AS_IS
document_type: BASELINE_CONCLUSIONS
status: COMPLETED_WITH_LIMITATIONS
reviewer_name: Eduardo Saldaña
review_date: "2026-09-23"
baseline_status: REVIEWED_NOT_FROZEN
baseline_can_be_frozen: false
```

---

## 2. Objetivo

Este documento consolida los resultados del baseline AS-IS del comparador entre:

```text
Calculadora Excel
versus
Proyecto Python
```

El objetivo no es demostrar que la implementación Python cumple o incumple integralmente con el Excel.

El objetivo es registrar de forma reproducible:

- el resultado producido por el comparador;
- la evidencia técnica capturada;
- las correcciones realizadas mediante revisión humana;
- las limitaciones de la ejecución;
- las divergencias de versión identificadas;
- las reglas auxiliares que no requieren implementación independiente;
- los elementos que todavía no pueden determinarse.

---

## 3. Fuentes de evidencia

```yaml
primary_inputs:
  - inputs/python_project_manifest.json
  - config/execution_config.json

captured_outputs:
  - outputs/07_correspondencia.md
  - outputs/08_reconciliacion.md
  - outputs/resultado_final.md
  - outputs/AS_IS_OUTPUTS_MANIFEST.json

human_review_documents:
  - evidence/HUMAN_REVIEW.md
  - evidence/EQUIVALENCE_REVIEW.md
  - evidence/PENDING_RULES_REVIEW.md

supporting_evidence:
  - evidence/PENDING_RULES_EVIDENCE.json
  - evidence/XL_0001_offset_validation.json
  - evidence/XL_0005_calibrated_xbeta.json
  - evidence/XL_0006_calibrated_score.json
  - evidence/XL_0008_final_pd36.json
  - evidence/XL_0009_curve_adjustments.json
  - evidence/XL_0010_0011_0012_combined.json
```

---

## 4. Resultado original producido por el comparador

El comparador reportó:

```yaml
final_verdict: NO_DETERMINABLE
semantic_equivalent_rules: 3
confirmed_differences: 0
pending_rules: 9
excel_controls_not_applicable: 0
code_only_elements: 11
numeric_reconciliation_status: NOT_RUN
```

Las reglas reportadas automáticamente como equivalentes fueron:

```text
XL-0002
XL-0004
XL-0007
```

Las reglas pendientes fueron:

```text
XL-0001
XL-0003
XL-0005
XL-0006
XL-0008
XL-0009
XL-0010
XL-0011
XL-0012
```

---

## 5. Estado de la reconciliación numérica

```yaml
mode: AUTO
strategy_selected: null
strategy_confidence: 0.0
comparisons_performed: 0
matches: 0
differences: 0
discovery_status: NOT_SELECTED
reconciliation_status: NOT_RUN
```

No se ejecutó una reconciliación numérica integral entre las salidas del Excel y las salidas del proyecto Python.

Por tanto:

```text
confirmed_differences = 0
```

no debe interpretarse como:

```text
la implementación cumple
```

Solo indica que no se realizaron comparaciones suficientes para confirmar diferencias.

---

## 6. Resultado consolidado de las equivalencias automáticas

```yaml
XL-0002: NO_DETERMINABLE
XL-0004: NO_DETERMINABLE
XL-0007: NO_DETERMINABLE

confirmed_count: 0
rejected_count: 0
inconclusive_count: 3
pending_count: 0
```

### XL-0002

```yaml
concept: Factor
excel_cell: Calculadora!H7
excel_formula: "=40/LN(2)"
numeric_validation: CONFIRMADA
semantic_identity_validation: CONFIRMADA
static_code_trace: CONFIRMADA
runtime_usage_validation: PENDIENTE
human_verdict: NO_DETERMINABLE
```

El valor del Excel y el parámetro `factor` de `pd_scalars.csv` coinciden dentro de la tolerancia definida.

También se confirmó que Python:

```text
lee pd_scalars.csv
→ extrae factor
→ utiliza factor en XB_pd
```

No se confirmó mediante runtime que ese flujo fuera ejecutado en la corrida capturada.

### XL-0004

```yaml
concept: PD WKC / PD Calibrada
mathematical_structure_validation: CONFIRMADA
active_parameter_value_validation: NO_COINCIDE
alternative_parameter_value_validation: COINCIDE
human_verdict: NO_DETERMINABLE
```

La estructura logística del Excel y Python es compatible.

Sin embargo:

```text
Excel
→ coincide con pd_thetaT_actualizado_202605.csv

Código activo
→ carga pd_thetaT_actualizado_sep24_v2.csv
```

Los parámetros del archivo activo no coinciden con los valores de la calculadora.

### XL-0007

```yaml
concept: PD TEMPORAL
excel_period_count: 70
active_parameter_matches: 0
active_parameter_mismatches: 70
alternative_202605_matches: 70
alternative_202605_mismatches: 0
human_verdict: NO_DETERMINABLE
```

Los 70 pares de parámetros temporales del Excel:

```text
no coinciden con sep24_v2
```

y:

```text
coinciden completamente con 202605
```

---

## 7. Resultado consolidado de las reglas inicialmente pendientes

```yaml
XL-0001: NO_DETERMINABLE
XL-0003: NO_DETERMINABLE
XL-0005: NO_DETERMINABLE
XL-0006: NO_DETERMINABLE
XL-0008: NO_APLICA
XL-0009: NO_DETERMINABLE
XL-0010: NO_APLICA
XL-0011: NO_DETERMINABLE
XL-0012: NO_DETERMINABLE

confirmed_count: 0
rejected_count: 0
inconclusive_count: 7
not_applicable_count: 2
pending_count: 0
```

---

## 8. Reglas auxiliares clasificadas como NO_APLICA

### XL-0008

```yaml
excel_range: I28:R28
behavior: COPIA_DE_FILA_ANTERIOR
business_logic_introduced: false
human_verdict: NO_APLICA
```

Las diez celdas revisadas copian directamente la fila anterior:

```text
I28:R28 = I27:R27
```

No requieren una operación Python independiente porque Python mantiene la curva en un arreglo.

### XL-0010

```yaml
excel_cell: AP30
formula: "=AP28-AP29"
AP29_status: VACIO
AP30_equals_AP28: true
business_logic_introduced: false
human_verdict: NO_APLICA
```

En el libro inspeccionado, `AP29` está vacío y `AP30` conserva el valor de `AP28`.

---

## 9. Hallazgos de lógica no reconocida por el comparador

### 9.1 Condiciones implementadas mediante datos

Para `XL-0005`, el comparador señaló que Python no contenía una condición equivalente a los `IF` del Excel.

La revisión humana encontró que Python implementa la selección mediante:

```text
merge
+ columnas min y max
+ filtro b_rango_plazo
```

Por tanto:

```text
ausencia de IF explícito
```

no significa:

```text
ausencia de lógica condicional
```

### 9.2 Transformaciones algebraicamente equivalentes

Para `XL-0006`, el comparador trató como diferentes:

```text
Excel:
ROUND((-H12 * H7) + H6, 0)
```

y:

```text
Python:
round(
    -factor * log(PD / (1 - PD))
    + offset,
    0
)
```

La revisión humana confirmó la relación:

```text
PD = logistic(H12)
logit(PD) = H12
```

Las expresiones son algebraicamente compatibles, aunque la equivalencia funcional completa continúa sin determinarse.

### 9.3 Recurrencia Excel frente a vectorización Python

Para `XL-0009` y `XL-0012`, el Excel implementa:

```text
valor actual = valor anterior + incremento
```

Python implementa:

```text
valor base + incremento * secuencia de periodos
```

La revisión confirmó que:

```text
J34
↔ factor_plazo_12_to_36
```

y que los 60 incrementos de `S28:BZ28` coinciden con `J34` dentro de `1e-12`.

---

## 10. Divergencias de versión identificadas

```yaml
excel_matching_parameter_version: "202605"
active_python_parameter_version: "sep24_v2"
version_alignment_status: DIVERGENTE
```

La divergencia afecta, como mínimo, a:

```text
XL-0004
XL-0005
XL-0007
```

Y se propaga hacia cálculos dependientes como:

```text
XL-0006
XL-0009
XL-0011
XL-0012
```

No se confirmó:

- si `202605` era una versión pendiente de despliegue;
- si `sep24_v2` era la versión aplicable formalmente;
- cuál versión se utilizó en la ejecución capturada;
- el commit exacto del proyecto;
- la ruta efectiva de parámetros en runtime.

---

## 11. Diferencias de alcance temporal

```yaml
excel_curve_range:
  start_period: 13
  end_period: 72

python_observed_extension_range:
  start_period: 13
  end_period: 36
```

El Excel extiende la progresión hasta el periodo 72.

El bloque Python observado extiende la curva hasta el periodo 36 y aplica condiciones relacionadas con producto y plazo.

Esta diferencia impide declarar equivalencia funcional completa para:

```text
XL-0009
XL-0012
```

---

## 12. Falsos negativos o resultados incompletos del comparador

Se identificaron casos donde el comparador reportó `NO_LOCALIZADO` o `NO_VERIFICABLE`, pero la revisión humana encontró evidencia relevante:

```yaml
XL-0001:
  system_verdict: NO_VERIFICABLE
  human_finding: OFFSET_LOCALIZADO_Y_VALIDADO

XL-0003:
  system_verdict: NO_LOCALIZADO
  human_finding: XBETA_LOCALIZADO_ESTRUCTURALMENTE

XL-0005:
  system_verdict: NO_VERIFICABLE
  human_finding: SELECCION_CONDICIONAL_TABULAR_LOCALIZADA

XL-0006:
  system_verdict: NO_VERIFICABLE
  human_finding: TRANSFORMACION_INVERSA_ALGEBRAICAMENTE_COMPATIBLE

XL-0009:
  system_verdict: NO_LOCALIZADO
  human_finding: EXTENSION_LINEAL_VECTORIZADA_LOCALIZADA

XL-0011:
  system_verdict: NO_VERIFICABLE
  human_finding: FACTOR_FLAT_Y_VALOR_OBJETIVO_LOCALIZADOS

XL-0012:
  system_verdict: NO_LOCALIZADO
  human_finding: INCREMENTO_LINEAL_LOCALIZADO
```

Estos casos muestran que la búsqueda basada únicamente en nombres, fórmulas literales o estructuras superficiales puede omitir correspondencias implementadas mediante:

- vectorización;
- joins;
- tablas de parámetros;
- transformaciones algebraicamente equivalentes;
- posiciones de arreglos;
- condiciones expresadas como filtros booleanos.

---

## 13. Limitaciones generales del baseline

```yaml
runtime_trace_available: false
formal_commit_confirmed: false
formal_version_confirmed: false
numeric_reconciliation_executed: false
product_code_confirmed: false
bucket_pasivos_confirmed: false
full_python_snapshot_available: false
unreadable_workspace_object_count: 23
```

Limitaciones:

1. No existe una traza runtime de la ejecución capturada.
2. No se confirmó el commit exacto del proyecto.
3. No se confirmó la versión formal de parámetros aplicable.
4. No se ejecutó reconciliación numérica integral.
5. No se confirmó `product_code_final` para el caso Excel.
6. No se confirmó `bucket_pasivos`.
7. No se confirmó qué variante de las funciones Python fue ejecutada.
8. El snapshot del proyecto contiene 23 objetos no legibles como archivos regulares.
9. Los outputs capturados no demuestran que todos provengan de una única ejecución reproducible.
10. La versión activa de parámetros no coincide con la calculadora.
11. El alcance temporal observado difiere entre Excel y Python.

---

## 14. Conclusión humana del caso

```yaml
human_case_verdict: NO_DETERMINABLE
system_final_verdict_supported: true
system_equivalence_labels_accepted_as_golden: false
zero_confirmed_differences_interpreted_as_compliance: false
baseline_approved: false
baseline_can_be_frozen: false
```

El veredicto general `NO_DETERMINABLE` permanece válido.

Sin embargo, las razones finales son más precisas que las reportadas originalmente por el comparador:

- no se ejecutó reconciliación numérica;
- existe divergencia de versión de parámetros;
- no existe evidencia runtime;
- no existe commit formal confirmado;
- algunas equivalencias automáticas solo reflejaban similitud matemática;
- varias reglas no localizadas sí tenían una correspondencia estática;
- dos reglas son auxiliares y no requieren una implementación Python independiente;
- existe una diferencia de alcance temporal entre Excel y Python.

---

## 15. Uso permitido de este baseline

Este baseline puede utilizarse para:

- preservar el comportamiento observado del comparador AS-IS;
- diseñar pruebas de regresión del comparador;
- documentar falsos negativos del mapping;
- diseñar mejoras en detección semántica;
- identificar dependencias de versión;
- definir requisitos para una ejecución reproducible;
- diseñar el siguiente caso de prueba controlado.

Este baseline no debe utilizarse todavía como:

- golden dataset aprobado;
- evidencia de cumplimiento;
- evidencia de incumplimiento;
- confirmación de equivalencia funcional;
- prueba de que no existen diferencias;
- referencia productiva certificada.

---

## 16. Condiciones necesarias para congelar el baseline

Antes de establecer:

```yaml
baseline_can_be_frozen: true
```

se requiere:

1. Confirmar el commit o versión exacta del proyecto.
2. Confirmar la versión formal de parámetros aplicable.
3. Ejecutar el caso desde cero en un entorno controlado.
4. Capturar logs de runtime.
5. Registrar las rutas efectivas de archivos cargados.
6. Capturar entradas y salidas de las funciones relevantes.
7. Ejecutar reconciliación numérica Excel contra Python.
8. Confirmar producto, segmento, plazo y `bucket_pasivos`.
9. Definir el rango temporal esperado de la curva.
10. Registrar un resultado esperado independiente del comparador.
11. Obtener aprobación humana formal del resultado.

---

## 17. Próximo paso recomendado

```yaml
next_action: CREATE_REPRODUCIBLE_EXECUTION_CASE
recommended_case_id: CASE_002_CONTROLLED_RUN
objective: >
  Ejecutar el comparador desde cero con versión de código, parámetros,
  entradas, logs y outputs controlados, permitiendo una reconciliación
  numérica completa y reproducible.
```

---

## 18. Estado documental final

```yaml
document: evidence/BASELINE_CONCLUSIONS.md
status: COMPLETED_WITH_LIMITATIONS
equivalence_review_completed: true
pending_rules_review_completed: true
human_review_completed: true
baseline_status: REVIEWED_NOT_FROZEN
baseline_frozen: false
```