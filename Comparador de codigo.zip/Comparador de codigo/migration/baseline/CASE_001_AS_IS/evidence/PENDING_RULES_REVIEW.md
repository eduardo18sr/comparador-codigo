# Revisión humana de reglas pendientes

## Control del documento

```yaml
case_id: CASE_001_AS_IS
review_type: PENDING_RULES_REVIEW
review_status: COMPLETED
reviewer_name: Eduardo Saldaña
review_date: "2026-09-23"
source_evidence: evidence/PENDING_RULES_EVIDENCE.json
review_scope:
  - XL-0001
  - XL-0003
  - XL-0005
  - XL-0006
  - XL-0008
  - XL-0009
  - XL-0010
  - XL-0011
  - XL-0012
```

---

## Reglas de revisión

Los resultados automáticos permitidos son:

```text
NO_VERIFICABLE
NO_LOCALIZADO
```

Estos resultados no deben interpretarse automáticamente como:

```text
NO EXISTE
DIFIERE
NO CUMPLE
```

Estados humanos permitidos:

```text
CONFIRMADA
RECHAZADA
NO_DETERMINABLE
NO_APLICA
PENDIENTE
```

Una regla solo podrá marcarse como `CONFIRMADA` cuando exista evidencia suficiente sobre:

- fórmula o regla del Excel;
- parámetro o lógica Python correspondiente;
- significado funcional;
- valores utilizados;
- versión aplicable;
- ejecución o evidencia suficiente del flujo evaluado.

---

# XL-0001

## Resultado reportado por el comparador

```yaml
rule_id: XL-0001
system_verdict: NO_VERIFICABLE
system_confidence: 0.35
excel_sheet: Calculadora
excel_cell: H6
excel_header: Offset
excel_formula: "=400-H7*LN(50)"
reported_files:
  - clv/source/engine/utils.py
  - clv/params/pd_scalars.csv
```

## Evidencia numérica revisada

```yaml
excel_cached_value: 174.245752409011
independently_recalculated_value: 174.245752409011
python_parameter_file: clv/params/pd_scalars.csv
python_parameter_name: offset
python_parameter_value: 174.245752409011
absolute_difference: 0.0
absolute_tolerance: 1.0e-8
excel_vs_csv_match: true
recalculated_vs_csv_match: true
parameter_file_sha256: 8eee428528e421b05dfd579913a06856a4e88f23624a93801b1b8f40270e0d27
```

## Trazabilidad estática observada

```text
Calculadora!H6
Fórmula: 400 - H7 * LN(50)
        ↓
Valor: 174.245752409011
        ↓
clv/params/pd_scalars.csv
offset = 174.245752409011
        ↓
CLV_Engine.set_path_pd()
        ↓
param_scalar = read_csv(pd_scalars.csv)
        ↓
utils.py
offset = param_scalar[
    param_scalar["param"] == "offset"
]["value"].values[0]
        ↓
XB_pd = -(score - offset) / factor
```

## Preguntas de validación

- [x] ¿El valor de `offset` coincide con el resultado almacenado en `Calculadora!H6`?
- [x] ¿La fórmula de `Calculadora!H6` fue recalculada independientemente?
- [x] ¿El recálculo independiente coincide con el valor de `pd_scalars.csv`?
- [x] ¿El proyecto contiene una lectura de `pd_scalars.csv`?
- [x] ¿El código extrae el parámetro `offset` desde `param_scalar`?
- [x] ¿El parámetro `offset` participa en la transformación `XB_pd`?
- [ ] ¿Se confirmó mediante runtime que `set_path_pd()` fue ejecutado en la corrida del baseline?
- [ ] ¿Se confirmó la versión o commit formal del proyecto ejecutado?
- [ ] ¿Se confirmó formalmente que el archivo inspeccionado fue el utilizado en la ejecución capturada?

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
numeric_validation: CONFIRMADA
independent_recalculation: CONFIRMADA
semantic_identity_validation: CONFIRMADA
static_code_trace: CONFIRMADA
runtime_usage_validation: PENDIENTE
version_validation: PENDIENTE
review_completed: true

reason: >
  El valor de Offset de la celda H6 coincide exactamente con el valor
  almacenado en pd_scalars.csv. La fórmula del Excel también fue
  recalculada independientemente y produjo el mismo resultado. El código
  carga pd_scalars.csv como param_scalar, extrae el parámetro offset y lo
  utiliza en la transformación XB_pd. La regla no puede declararse
  confirmada integralmente porque no existe evidencia runtime de la
  ejecución capturada ni una versión o commit formal que demuestre que el
  archivo inspeccionado fue exactamente el utilizado.

limitations:
  - No existe traza runtime de set_path_pd para la ejecución capturada.
  - No se confirmó el commit o versión formal del proyecto.
  - No se confirmó mediante log la ruta efectiva de pd_scalars.csv.
```

## Comentarios

El sistema reporta `NO_VERIFICABLE`, pero la inspección humana encontró evidencia numérica y estática sólida.

```text
Valor Excel:              174.245752409011
Recálculo independiente:  174.245752409011
Valor CSV:                174.245752409011
Diferencia absoluta:      0.0
```

La regla se mantiene como `NO_DETERMINABLE` únicamente por ausencia de evidencia runtime y control formal de versión.

---

# XL-0003

## Resultado reportado por el comparador

```yaml
rule_id: XL-0003
system_verdict: NO_LOCALIZADO
system_confidence: 0.72
excel_sheet: Calculadora
excel_cell: H9
excel_header: xβ
excel_formula: "=-(H11-$H$6)/$H$7"
reported_files:
  - clv/source/engine/utils.py
  - clv/source/engine/CLV_Engine.py
  - clv/source/engine/utils_clv.py
  - wtp_capital_de_trabajo_inf/source/engine/utils_wtp.py
  - wtp_capital_de_trabajo_new/source/engine/utils_wtp.py
  - wtp_capital_de_trabajo_new_reactivo/source/engine/utils_wtp.py
  - wtp_af/source/engine/WTP_AF.py
  - wtp_afi_reactivo/source/engine/WTP_AF.py
```

## Evidencia revisada

### Excel

```yaml
score_cell: H11
score_value: 274
offset_cell: H6
offset_value: 174.245752409011
factor_cell: H7
factor_value: 57.70780163555854
xbeta_cell: H9
xbeta_formula: "=-(H11-$H$6)/$H$7"
xbeta_cached_value: -1.7286093866643184
```

### Python

```yaml
source: clv/source/engine/utils.py
offset_expression: >
  offset = param_scalar[
    param_scalar["param"] == "offset"
  ]["value"].values[0]
factor_expression: >
  factor = param_scalar[
    param_scalar["param"] == "factor"
  ]["value"].values[0]
xbeta_expression: "xBeta = -(score - offset) / factor"
```

## Comparación estructural

```text
Excel:
H9 = -(H11 - H6) / H7
```

```text
Python:
xBeta = -(score - offset) / factor
```

Correspondencias observadas:

```text
H11 ↔ score
H6  ↔ offset
H7  ↔ factor
H9  ↔ xBeta
```

## Preguntas de validación

- [x] ¿La estructura algebraica de Excel coincide con la expresión Python?
- [x] ¿El `offset` del Excel coincide con el parámetro Python?
- [x] ¿El `factor` del Excel coincide con el parámetro Python?
- [x] ¿El código utiliza `offset` y `factor` en el cálculo de `xBeta`?
- [ ] ¿Se confirmó formalmente que `H11` representa la misma variable que `score`?
- [ ] ¿Se confirmó mediante runtime que esta función fue ejecutada en la corrida del baseline?
- [ ] ¿Se confirmó el commit o versión formal del proyecto ejecutado?

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
algebraic_structure_validation: CONFIRMADA
offset_validation: CONFIRMADA
factor_validation: CONFIRMADA
static_code_trace: CONFIRMADA
score_identity_validation: PENDIENTE
runtime_usage_validation: PENDIENTE
version_validation: PENDIENTE
review_completed: true

evidence_reviewed:
  - Calculadora!H6
  - Calculadora!H7
  - Calculadora!H9
  - Calculadora!H11
  - evidence/XL_0001_offset_validation.json
  - evidence/EQUIVALENCE_REVIEW.md:XL-0002
  - clv/params/pd_scalars.csv
  - clv/source/engine/CLV_Engine.py:78-98
  - clv/source/engine/utils.py:267-269
  - clv/source/engine/utils.py:306-310

confirmed_evidence:
  - La expresión algebraica de Excel coincide con la expresión Python.
  - H6 coincide numéricamente con offset.
  - H7 coincide numéricamente con factor.
  - Python extrae offset y factor desde param_scalar.
  - Python utiliza ambos parámetros para calcular xBeta.

reason: >
  La estructura algebraica de XL-0003 coincide con la implementación
  Python. Los parámetros offset y factor fueron validados numéricamente
  y su trazabilidad estática fue confirmada. Sin embargo, no existe una
  evidencia formal que demuestre que H11 representa exactamente la misma
  entrada que score durante la ejecución capturada. Tampoco existe una
  traza runtime o un commit formal del proyecto. Por ello, la regla queda
  como NO_DETERMINABLE, aunque la evidencia estática respalda fuertemente
  la correspondencia.

limitations:
  - No se confirmó formalmente la correspondencia entre H11 y score.
  - No existe traza runtime de la función ejecutada.
  - No se confirmó el commit o versión formal del proyecto.
```

## Comentarios

El resultado automático `NO_LOCALIZADO` no refleja completamente la evidencia disponible.

La expresión Python fue localizada:

```python
xBeta = -(score - offset) / factor
```

y presenta la misma estructura que:

```excel
=-(H11-H6)/H7
```

La regla no se marca como `CONFIRMADA` porque la correspondencia entre `H11` y `score` se infiere por posición funcional, pero todavía no está respaldada mediante una traza de datos o un contrato formal.

---

# XL-0005

## Resultado reportado por el comparador

```yaml
rule_id: XL-0005
system_verdict: NO_VERIFICABLE
system_confidence: 0.45
excel_sheet: Calculadora
excel_cell: H12
excel_header: xβ Calibrado
excel_formula: >
  =IF($H$8<=19,L9+M9*$H$9,
  IF($H$8<=25,L10+M10*$H$9,L11+M11*H9))
reported_files:
  - clv/source/engine/utils.py
  - clv/source/engine/utils_clv.py
  - wtp_capital_de_trabajo/data/params/dem_betas_simulados.csv
  - clv/params/lgd_thetaT_set23.csv
```

## Evidencia revisada

### Excel

```yaml
plazo_cell: H8
plazo_value: 18
base_xbeta_cell: H9
base_xbeta_value: -1.7286093866643184
calibrated_xbeta_cell: H12
calibrated_xbeta_value: -1.5547254318034134

calibration_ranges:
  plazo_0_19:
    intercept: 0.2151438827
    slope: 1.0238688556
  plazo_20_25:
    intercept: -1.32304e-09
    slope: 0.9999999993
  plazo_mayor_25:
    intercept: -9.0105e-10
    slope: 0.9999999996
```

### Python

```yaml
source: clv/source/engine/utils.py

range_selection:
  merge_expression: >
    X = merge(
      X[
        [
          "product_code_final",
          "CantidadPlazo",
          "bucket_pasivos",
          "segmento_info_new"
        ]
      ],
      param_T,
      on=[
        "product_code_final",
        "bucket_pasivos"
      ],
      how="left"
    )

  range_condition: >
    X["b_rango_plazo"] =
    (X["CantidadPlazo"] >= X["min"])
    & (X["CantidadPlazo"] <= X["max"])

  selected_parameters:
    - alpha
    - beta

calibration_expression: >
  xBetaCalibrado =
  alpha + beta * xBeta.reshape(-1, 1)
```

## Comparación estructural

```text
Excel:
seleccionar intercepto y pendiente según H8
        ↓
H12 = intercepto + pendiente * H9
```

```text
Python:
seleccionar alpha y beta según CantidadPlazo,
product_code_final y bucket_pasivos
        ↓
xBetaCalibrado = alpha + beta * xBeta
```

Correspondencias estructurales observadas:

```text
H8      ↔ CantidadPlazo
H9      ↔ xBeta
INTER.  ↔ alpha
PEND.   ↔ beta
H12     ↔ xBetaCalibrado
```

## Preguntas de validación

- [x] ¿La estructura algebraica del Excel coincide con la expresión Python?
- [x] ¿Python selecciona parámetros según un rango de plazo?
- [x] ¿La selección por rango existe aunque no esté implementada con `if` explícitos?
- [x] ¿El intercepto del Excel corresponde estructuralmente a `alpha`?
- [x] ¿La pendiente del Excel corresponde estructuralmente a `beta`?
- [x] ¿`H9` corresponde estructuralmente a `xBeta`?
- [ ] ¿Los parámetros del archivo activo coinciden numéricamente con los del Excel?
- [ ] ¿Se confirmó formalmente el `product_code_final` del caso evaluado?
- [ ] ¿Se confirmó el `bucket_pasivos` aplicable?
- [ ] ¿Se confirmó mediante runtime qué fila de parámetros fue seleccionada?
- [ ] ¿Se confirmó la versión formal del archivo de parámetros utilizado?

## Hallazgo sobre el mapping automático

El mapping indicó:

```text
El código Python calcula xBetaCalibrado de forma única
sin ramificación condicional por rangos.
```

La inspección humana encontró que esa conclusión es incompleta.

Python sí implementa selección condicional de parámetros, pero lo hace de forma tabular:

```python
X = merge(
    X[
        [
            "product_code_final",
            "CantidadPlazo",
            "bucket_pasivos",
            "segmento_info_new",
        ]
    ],
    param_T,
    on=[
        "product_code_final",
        "bucket_pasivos",
    ],
    how="left",
)

X["b_rango_plazo"] = (
    (X["CantidadPlazo"] >= X["min"])
    & (X["CantidadPlazo"] <= X["max"])
)

X = X[
    X["b_rango_plazo"] == True
]

alpha = X["alpha"]
beta = X["beta"]
```

Por tanto, la ausencia de sentencias `if` no implica ausencia de lógica condicional por rango.

## Divergencia de versión

```yaml
excel_parameters_match:
  file: clv/params/pd_thetaT_actualizado_202605.csv
  status: COINCIDE_CON_EXCEL

active_code_parameter_file:
  file: clv/params/pd_thetaT_actualizado_sep24_v2.csv
  status: NO_COINCIDE_CON_EXCEL

active_code_reference:
  line: CLV_Engine.py:80
  status: ACTIVA

alternative_code_reference:
  line: CLV_Engine.py:81
  status: COMENTADA
```

Para el primer rango observado:

```text
Excel:
alpha = 0.2151438827
beta  = 1.0238688556

Archivo 202605:
alpha = 0.215143883
beta  = 1.023868856

Archivo activo sep24_v2:
alpha = -0.630186337
beta  = 0.723944645
```

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
algebraic_structure_validation: CONFIRMADA
range_selection_validation: CONFIRMADA
base_xbeta_correspondence: CONFIRMADA_ESTRUCTURALMENTE
parameter_identity_validation: CONFIRMADA_ESTRUCTURALMENTE
active_parameter_value_validation: NO_COINCIDE
alternative_parameter_value_validation: COINCIDE
product_code_validation: PENDIENTE
bucket_pasivos_validation: PENDIENTE
runtime_usage_validation: PENDIENTE
version_validation: PENDIENTE
review_completed: true

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0005
  - outputs/artifacts/mapping.json:XL-0005
  - Calculadora!H8:H12
  - Calculadora!K8:M11
  - clv/source/engine/utils.py:282-311
  - clv/source/engine/CLV_Engine.py:78-98
  - clv/params/pd_thetaT_actualizado_sep24_v2.csv
  - clv/params/pd_thetaT_actualizado_202605.csv
  - evidence/PENDING_RULES_REVIEW.md:XL-0003
  - evidence/XL_0005_calibrated_xbeta.json

confirmed_evidence:
  - El Excel selecciona intercepto y pendiente según el plazo.
  - Python selecciona alpha y beta mediante rangos min y max.
  - Python implementa la condición mediante datos y filtros, no mediante if explícitos.
  - La estructura alpha más beta por xBeta coincide con la estructura del Excel.
  - Los parámetros del Excel coinciden con el archivo alternativo 202605.
  - Los parámetros del archivo activo sep24_v2 no coinciden con el Excel.

reason: >
  La inspección confirma que Excel y Python implementan la misma estructura
  general de calibración: selección de intercepto y pendiente según un rango
  de plazo, seguida del cálculo intercepto más pendiente por xBeta. El mapping
  automático no reconoció la selección condicional porque Python la implementa
  mediante merge, columnas min y max y un filtro booleano, en lugar de IF
  explícitos. Sin embargo, los parámetros del Excel corresponden al archivo
  202605, mientras el código inspeccionado carga activamente sep24_v2. Por ello,
  no puede confirmarse que la implementación activa produzca el mismo xBeta
  calibrado que la calculadora.

limitations:
  - No se confirmó formalmente el product_code_final de la calculadora.
  - No se confirmó el bucket_pasivos aplicable.
  - No existe evidencia runtime de la fila de parámetros seleccionada.
  - No se confirmó la versión formal utilizada en la ejecución capturada.
  - La versión activa de parámetros no coincide con los valores del Excel.
```

## Comentarios

La estructura de selección por plazo sí existe en Python.

```text
Excel:
IF H8 <= 19
ELSE IF H8 <= 25
ELSE
```

```text
Python:
CantidadPlazo >= min
AND
CantidadPlazo <= max
```

Ambos mecanismos seleccionan una pareja de parámetros y aplican:

```text
intercepto + pendiente * xBeta
```

La diferencia relevante no está en la estructura del algoritmo, sino en la versión de parámetros utilizada.

La regla queda como `NO_DETERMINABLE` porque la versión activa del código no contiene los mismos parámetros que el Excel del baseline.

---

# XL-0006

## Resultado reportado por el comparador

```yaml
rule_id: XL-0006
system_verdict: NO_VERIFICABLE
system_confidence: 0.35
excel_sheet: Calculadora
excel_cell: H14
excel_header: Score Calibrado por plazo
excel_formula: "=ROUND((-H12*H7)+H6,0)"
excel_cached_value: 264
reported_files:
  - clv/source/engine/utils.py
  - clv/source/engine/CLV_Engine.py
```

## Evidencia revisada

### Excel

```yaml
offset_cell: H6
offset_value: 174.245752409011
factor_cell: H7
factor_value: 57.70780163555854
calibrated_xbeta_cell: H12
calibrated_xbeta_value: -1.5547254318034134
calibrated_pd_cell: H13
calibrated_pd_value: 0.17440481654730294
calibrated_score_cell: H14
calibrated_score_formula: "=ROUND((-H12*H7)+H6,0)"
calibrated_score_value: 264
```

### Python

```yaml
source: clv/source/engine/utils.py

parameterized_transform:
  offset_expression: >
    offset = param_scalar[
      param_scalar["param"] == "offset"
    ]["value"].values[0]
  factor_expression: >
    factor = param_scalar[
      param_scalar["param"] == "factor"
    ]["value"].values[0]
  inverse_score_expression_commented: >
    score_pdtasa = round(
      XB_pdtasa * -factor + offset,
      0
    )

hardcoded_transform:
  expression: >
    score_pdtasa = round(
      -57.707801636
      * log(pd_xtasa / (1 - pd_xtasa))
      + 174.24575241,
      0
    )
  factor_value: 57.707801636
  offset_value: 174.24575241
```

## Relación algebraica

En Excel:

```text
H13 = 1 / (1 + EXP(-H12))
```

Por definición del logit:

```text
LOGIT(H13) = LN(H13 / (1 - H13)) = H12
```

Por tanto:

```text
H14 = ROUND((-H12 * H7) + H6, 0)
```

es equivalente a:

```text
H14 = ROUND(
    -H7 * LN(H13 / (1 - H13)) + H6,
    0
)
```

La expresión Python observada es:

```python
score_pdtasa = round(
    -57.707801636
    * log(pd_xtasa / (1 - pd_xtasa))
    + 174.24575241,
    0,
)
```

Correspondencias estructurales:

```text
H13           ↔ pd_xtasa o PD_NUEVA
H12           ↔ logit de la PD calibrada
H7            ↔ factor
H6            ↔ offset
H14           ↔ score_pdtasa
ROUND(..., 0) ↔ round(..., 0)
```

## Preguntas de validación

- [x] ¿La transformación inversa de PD a score existe en Python?
- [x] ¿La estructura algebraica coincide con la fórmula de H14?
- [x] ¿El factor hardcodeado de Python coincide con H7 dentro del redondeo observado?
- [x] ¿El offset hardcodeado de Python coincide con H6 dentro del redondeo observado?
- [x] ¿Python aplica redondeo a cero decimales?
- [x] ¿Existe una versión parametrizada de la expresión usando `factor` y `offset`?
- [ ] ¿La versión parametrizada está activa en lugar de comentada?
- [ ] ¿Se confirmó que `pd_xtasa` o `PD_NUEVA` corresponde exactamente a H13?
- [ ] ¿Se confirmó que H12 fue calculada con la misma versión activa de parámetros?
- [ ] ¿Se confirmó mediante runtime la función utilizada en la corrida del baseline?
- [ ] ¿Se confirmó el commit o versión formal del proyecto ejecutado?

## Hallazgo sobre el mapping automático

El mapping indicó que las expresiones Python diferían estructuralmente de la fórmula simple del Excel.

La inspección humana encontró que ambas expresiones son algebraicamente compatibles. Excel utiliza directamente el predictor calibrado `H12`, mientras Python aplica `logit()` sobre una PD calibrada. Como `H13` es la función logística de `H12`, se cumple:

```text
logit(H13) = H12
```

Por tanto, usar `-H12 * factor + offset` o usar `-factor * logit(H13) + offset` representa la misma transformación, siempre que la PD Python corresponda realmente a H13.

## Valores comparados

```yaml
excel_factor:
  value: 57.70780163555854
python_hardcoded_factor:
  value: 57.707801636
  absolute_difference: 4.414601111557337e-10
  within_absolute_tolerance_1e_8: true

excel_offset:
  value: 174.245752409011
python_hardcoded_offset:
  value: 174.24575241
  absolute_difference: 9.890754881780595e-10
  within_absolute_tolerance_1e_8: true
```

## Dependencia de XL-0005

```yaml
upstream_rule: XL-0005
upstream_human_verdict: NO_DETERMINABLE
upstream_reason: DIVERGENCIA_DE_VERSION_DE_PARAMETROS
impact_on_XL_0006: >
  Aunque la transformación inversa de PD a score es algebraicamente
  compatible, el predictor H12 y la PD H13 dependen de parámetros que no
  coinciden con el archivo activo sep24_v2. Por ello, no puede confirmarse
  que la implementación activa produzca el mismo score calibrado.
```

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
algebraic_structure_validation: CONFIRMADA
inverse_logit_relationship_validation: CONFIRMADA
factor_value_validation: CONFIRMADA_DENTRO_DE_TOLERANCIA
offset_value_validation: CONFIRMADA_DENTRO_DE_TOLERANCIA
rounding_validation: CONFIRMADA
parameterized_expression_status: COMENTADA
pd_input_identity_validation: PENDIENTE
upstream_parameter_version_validation: NO_COINCIDE
runtime_usage_validation: PENDIENTE
version_validation: PENDIENTE
review_completed: true

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0006
  - outputs/artifacts/mapping.json:XL-0006
  - Calculadora!H6:H14
  - clv/source/engine/utils.py:2947-2958
  - clv/source/engine/utils.py:2966-2978
  - clv/source/engine/utils.py:2990-3000
  - evidence/XL_0001_offset_validation.json
  - evidence/EQUIVALENCE_REVIEW.md:XL-0002
  - evidence/PENDING_RULES_REVIEW.md:XL-0005
  - evidence/XL_0006_calibrated_score.json

confirmed_evidence:
  - Excel transforma el predictor calibrado a score mediante factor y offset.
  - Python transforma una PD calibrada a score mediante logit, factor y offset.
  - H13 es la función logística de H12, por lo que logit de H13 equivale a H12.
  - Los valores hardcodeados de factor y offset coinciden con el Excel dentro de 1e-8.
  - Python aplica redondeo a cero decimales.
  - Existe una expresión parametrizada equivalente, pero aparece comentada.
  - La entrada calibrada depende de parámetros cuya versión activa no coincide con el Excel.

reason: >
  Se confirmó que la fórmula de H14 y la transformación Python de PD a score
  son algebraicamente compatibles. La función Python utiliza el logit de una
  PD calibrada, mientras Excel utiliza directamente H12, y H13 demuestra que
  H12 es precisamente el logit de la PD calibrada. Los valores de factor y
  offset utilizados en Python coinciden con los valores del Excel dentro de
  la tolerancia. Sin embargo, no se confirmó que la PD Python corresponda
  exactamente a H13 ni que la ejecución capturada utilizara este flujo. Además,
  H12 depende de parámetros del archivo 202605, mientras el código inspeccionado
  carga activamente sep24_v2. Por ello, la equivalencia funcional completa no
  puede confirmarse.

limitations:
  - No se confirmó la identidad exacta entre H13 y pd_xtasa o PD_NUEVA.
  - La expresión parametrizada usando factor y offset está comentada.
  - No se confirmó cuál variante de cal_score_rate fue ejecutada.
  - XL-0005 presenta una divergencia de versión en los parámetros de calibración.
  - No existe traza runtime de la ejecución capturada.
  - No se confirmó el commit o versión formal del proyecto.
```

## Comentarios

El mapping automático trató las dos expresiones como estructuralmente diferentes:

```text
Excel:
ROUND((-H12 * H7) + H6, 0)
```

```text
Python:
round(
    -factor * log(PD / (1 - PD))
    + offset,
    0
)
```

La revisión humana confirma que son equivalentes bajo la relación:

```text
PD = logistic(H12)
logit(PD) = H12
```

La regla se mantiene como `NO_DETERMINABLE` porque la equivalencia de la transformación no resuelve la divergencia previa en los parámetros que producen H12 y H13, ni demuestra cuál función fue ejecutada en runtime.

---


# XL-0008

## Resultado reportado por el comparador

```yaml
rule_id: XL-0008
system_verdict: NO_LOCALIZADO
system_confidence: 0.45
excel_sheet: Calculadora
excel_range: I28:R28
excel_header: PD TEMPORAL 36 Versión Final
formula_type: FORMULA_AUXILIAR
cell_count: 10
reported_files:
  - clv/source/engine/utils.py
  - clv/source/engine/CLV_Engine.py
  - wtp_capital_de_trabajo_inf/source/engine/utils_wtp.py
  - "[ALPHA] 2.get_profitability_alpha.py"
  - "[ALPHA_PILOTO] 2.get_profitability_alpha_piloto.py"
  - wtp_activo_fijo_inmueble/source/engine/utils_wtp.py
  - wtp_af/source/engine/WTP_AF.py
  - wtp_afi_reactivo/source/engine/WTP_AF.py
  - wtp_alpha_inf/source/engine/WTP_ALPHA.py
```

## Evidencia revisada

### Fórmula Excel

Las diez celdas de `I28:R28` copian directamente el valor de la fila anterior en la misma columna:

```text
I28 = I27
J28 = J27
K28 = K27
L28 = L27
M28 = M27
N28 = N27
O28 = O27
P28 = P27
Q28 = Q27
R28 = R27
```

La firma estructural observada es:

```text
=+R[-1]C[+0]
```

### Comparación de valores

```yaml
periods_reviewed:
  - 3
  - 4
  - 5
  - 6
  - 7
  - 8
  - 9
  - 10
  - 11
  - 12
matched_value_count: 10
mismatch_value_count: 0
all_absolute_differences: 0.0
```

Para las diez celdas revisadas, el valor de la fila 28 es idéntico al valor de la fila 27.

### Implementación Python relacionada

```yaml
source: clv/source/engine/utils.py
curve_creation_lines:
  - 306-318
subsequent_adjustment_lines:
  - 320-365
second_implementation_lines:
  - 426-465
```

Python construye la curva directamente en memoria:

```python
pdTemporal = 1 / (1 + exp(valueT))
pdTemporal = pdTemporal * factor_pd
zeros_array = zeros((pdTemporal.shape[0], 2))
curve = concatenate((zeros_array, pdTemporal), axis=1)
```

Posteriormente, Python puede aplicar ajustes específicos sobre la curva para determinados productos, plazos y periodos.

## Análisis funcional

`XL-0008` no introduce una nueva fórmula de negocio ni una transformación adicional. La fila 28 solamente replica en `I28:R28` los primeros valores ya calculados en la fila 27.

La ausencia de una instrucción Python equivalente a una copia de fila no constituye por sí misma una diferencia funcional, porque Python mantiene la curva en un único arreglo y no necesita reproducir la organización visual o auxiliar del Excel.

Los ajustes posteriores observados en Python pertenecen a otros periodos o condiciones y deben revisarse mediante las reglas que cubren el resto de la fila 28. No deben atribuirse automáticamente a `XL-0008`.

## Preguntas de validación

- [x] ¿Las celdas `I28:R28` copian directamente `I27:R27`?
- [x] ¿Los diez valores copiados coinciden exactamente con la fila anterior?
- [x] ¿La regla está clasificada como `FORMULA_AUXILIAR`?
- [x] ¿La fila 28 evita recalcular la PD para esos diez periodos?
- [x] ¿Python conserva esos valores dentro de la curva sin requerir una fila auxiliar?
- [ ] ¿Se confirmó mediante runtime el arreglo final producido por Python para el caso del baseline?
- [ ] ¿Se reconciliaron numéricamente los diez valores Excel contra una salida Python de la ejecución capturada?

## Decisión humana

```yaml
human_verdict: NO_APLICA
review_completed: true
formula_classification: FORMULA_AUXILIAR
business_logic_introduced: false
excel_copy_validation: CONFIRMADA
excel_value_identity_validation: CONFIRMADA
python_row_copy_required: false
runtime_output_validation: PENDIENTE
numeric_excel_python_reconciliation: NO_EJECUTADA

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0008
  - outputs/artifacts/mapping.json:XL-0008
  - Calculadora!I27:R28
  - clv/source/engine/utils.py:306-365
  - clv/source/engine/utils.py:426-465
  - evidence/XL_0008_final_pd36.json

confirmed_evidence:
  - I28:R28 copia directamente I27:R27.
  - Los diez valores de la fila 28 coinciden exactamente con la fila 27.
  - La regla no agrega parámetros, condiciones ni operaciones de negocio.
  - Python representa la curva en un arreglo y no requiere replicar una fila auxiliar del Excel.

reason: >
  XL-0008 es una regla auxiliar de presentación o propagación dentro del
  Excel. Las diez celdas revisadas copian sin cambios los valores de la fila
  anterior y no introducen una fórmula de negocio independiente. No es
  necesario localizar en Python una operación explícita de copia entre filas,
  porque la implementación conserva la curva en un único arreglo. Por ello,
  la regla se clasifica como NO_APLICA para la comparación funcional directa
  Excel contra Python.

limitations:
  - No se ejecutó una reconciliación numérica contra una salida Python capturada.
  - La decisión NO_APLICA se limita a I28:R28 y no cubre S28:BZ28.
  - Los ajustes posteriores de curva deben evaluarse en las reglas siguientes.
```

## Comentarios

El resultado automático `NO_LOCALIZADO` es esperable porque el comparador buscó una copia explícita entre filas, por ejemplo:

```text
fila 28 = fila 27
```

La implementación Python no necesita esa estructura tabular auxiliar. Python calcula y conserva la curva directamente en memoria.

La decisión `NO_APLICA` no afirma que toda la curva sea equivalente. Solo establece que la copia auxiliar `I28:R28 = I27:R27` no representa una regla funcional independiente que deba tener una implementación Python separada.

---


# XL-0009

## Resultado reportado por el comparador

```yaml
rule_id: XL-0009
system_verdict: NO_LOCALIZADO
system_confidence: 0.35
excel_sheet: Calculadora
excel_range: S28:BZ28
excel_header: Calculadora!S:BZ fila 28
formula_type: FORMULA_AUXILIAR
cell_count: 60
```

## Evidencia revisada

### Fórmula Excel

La regla aplica una recurrencia horizontal desde el periodo 13 hasta el periodo 72:

```text
valor_periodo_actual = valor_periodo_anterior + J34
```

Ejemplos:

```text
S28  = R28  + J34
T28  = S28  + J34
U28  = T28  + J34
...
BZ28 = BY28 + J34
```

La firma estructural observada es:

```text
=R[0]C[-1] + J34
```

### Cobertura temporal

```yaml
first_cell: S28
last_cell: BZ28
first_period: 13
last_period: 72
period_count: 60
increment_cell: J34
```

### Comportamiento de los valores

```yaml
row_27_behavior_from_period_19: CONSTANTE
row_27_constant_value: 0.26930341782777056
row_28_behavior: CRECIMIENTO_LINEAL_POR_INCREMENTO_CONSTANTE
first_reviewed_value_period_13: 0.18216078701556077
last_reviewed_value_period_72: 0.635710526027738
```

Los valores de la fila 28 difieren de la fila 27 desde el periodo 13. La diferencia no es una copia auxiliar como en XL-0008, sino una modificación progresiva de la curva.

## Implementación Python relacionada

Se observaron al menos dos ajustes vectorizados de curva que utilizan incrementos lineales.

### Implementación 1: ajuste WKC de periodos 25 a 36

```python
marginal_24 = (
    curve[:, 23] - curve[:, 22]
).reshape(-1, 1)

ajuste_36_wkc = (
    marginal_24 * arange(1, 13)
)

mask_prod = (
    X["product_code_final"]
    .isin([1, 6])
    .values
    .reshape(-1, 1)
)

curve[:, 24:36] = where(
    mask_prod,
    curve[:, 23].reshape(-1, 1)
    + ajuste_36_wkc,
    curve[:, 24:36],
)
```

### Implementación 2: extensión lineal de periodos 13 a 36

```python
factor_flat = 2.05743740795287
factor_plazo_12 = factor_flat * curve[:, 11]
factor_plazo_12_to_36 = (
    factor_plazo_12 - curve[:, 11]
) / 24

mask_prod = (
    X["product_code_final"].isin([1]).values
    & (X["CantidadPlazo"].values > 24)
).reshape(-1, 1)

curve[:, 12:36] = where(
    mask_prod,
    curve[:, [11]]
    + factor_plazo_12_to_36.reshape(-1, 1)
    * arange(1, 25),
    curve[:, 12:36],
)
```

## Comparación estructural

```text
Excel:
curva[t] = curva[t - 1] + J34
para t = 13 ... 72
```

```text
Python, implementación 2:
curva[t] = curva[12] + incremento * número_de_periodo
para t = 13 ... 36
si product_code_final = 1
y CantidadPlazo > 24
```

Las dos expresiones representan una progresión aritmética y son estructuralmente relacionadas. Sin embargo, no pueden declararse funcionalmente equivalentes con la evidencia actual porque difieren en alcance y condiciones.

## Diferencias pendientes

```yaml
excel_period_range:
  start: 13
  end: 72
python_period_range:
  start: 13
  end: 36

excel_condition: NO_VISIBLE_EN_LA_FORMULA_XL_0009
python_conditions:
  product_code_final: 1
  CantidadPlazo: MAYOR_QUE_24

excel_increment_source: Calculadora!J34
python_increment_source: >
  (factor_flat * curve[:, 11] - curve[:, 11]) / 24

increment_identity_validation: CONFIRMADA
```

## Dependencia de otras reglas

```yaml
depends_on:
  - XL-0010
  - XL-0011
  - XL-0012
primary_dependency: XL-0012
primary_dependency_reason: >
  J34 contiene el incremento constante utilizado en las 60 fórmulas de
  XL-0009. La equivalencia no puede resolverse hasta revisar la fórmula,
  el valor y el significado funcional de J34.
```

## Preguntas de validación

- [x] ¿XL-0009 implementa una progresión aritmética horizontal?
- [x] ¿La progresión utiliza un incremento constante almacenado en J34?
- [x] ¿Python contiene una extensión lineal vectorizada de la curva?
- [x] ¿La implementación vectorizada de Python evita la necesidad de una fórmula iterativa por celda?
- [x] ¿J34 coincide con el incremento calculado por Python?
- [ ] ¿El rango Excel 13 a 72 corresponde al alcance Python 13 a 36?
- [ ] ¿Las condiciones de producto y plazo de Python están representadas en el Excel?
- [ ] ¿Se confirmó que la implementación Python aplicable es la versión de líneas 439 a 465?
- [ ] ¿Se confirmó mediante runtime el arreglo final producido por Python?
- [ ] ¿Se reconciliaron numéricamente los valores ajustados Excel contra Python?

## Hallazgo sobre el mapping automático

El mapping buscó una implementación literal de:

```text
valor actual = valor anterior + constante
```

La inspección humana localizó una implementación vectorizada conceptualmente relacionada:

```text
valor base + incremento * secuencia de periodos
```

La falta de una asignación iterativa celda por celda no implica ausencia de la lógica de progresión. No obstante, la evidencia actual tampoco demuestra equivalencia completa debido a las diferencias de alcance temporal, condiciones y fuente del incremento.

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
review_completed: true
excel_progression_validation: CONFIRMADA
python_linear_extension_validation: CONFIRMADA
structural_relationship_validation: CONFIRMADA_PARCIALMENTE
increment_identity_validation: PENDIENTE
period_range_validation: NO_COINCIDE
condition_scope_validation: PENDIENTE
runtime_usage_validation: PENDIENTE
numeric_excel_python_reconciliation: NO_EJECUTADA

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0009
  - outputs/artifacts/mapping.json:XL-0009
  - Calculadora!S28:BZ28
  - Calculadora!J34
  - clv/source/engine/utils.py:328-340
  - clv/source/engine/utils.py:439-465
  - evidence/XL_0009_curve_adjustments.json

confirmed_evidence:
  - Excel aplica un incremento constante desde el periodo 13 hasta el 72.
  - Python contiene ajustes lineales vectorizados de la curva.
  - La segunda implementación Python extiende linealmente la curva del periodo 13 al 36.
  - Python condiciona el ajuste por producto y plazo.
  - Excel y Python no tienen el mismo alcance temporal observado.
  - J34 coincide estructuralmente con factor_plazo_12_to_36. 
  - Los 60 incrementos de S28:BZ28 coinciden con J34 dentro de 1e-12.
  - La diferencia máxima observada es aproximadamente 3.56e-17.

reason: >
  XL-0009 implementa una progresión aritmética de la curva usando J34 como
  incremento constante. Python contiene una extensión lineal vectorizada
  estructuralmente equivalente y evita la recurrencia celda por celda.
  XL-0012 confirmó que J34 corresponde al incremento calculado por Python.
  Sin embargo, Excel extiende la fórmula desde el periodo 13 hasta el 72,
  mientras la implementación Python observada cubre del periodo 13 al 36
  y solo se aplica bajo condiciones de producto y plazo. No existe evidencia
  runtime ni reconciliación de los outputs finales. Por ello, la regla queda
  como NO_DETERMINABLE.

limitations:
  - Excel extiende la progresión hasta el periodo 72.
  - Python extiende la progresión observada hasta el periodo 36.
  - No se confirmó product_code_final igual a 1 para el caso Excel.
  - No se confirmó CantidadPlazo mayor que 24 para la rama Python.
  - No se confirmó cuál de las implementaciones Python fue ejecutada.
  - No existe reconciliación numérica Excel contra Python.
  - No existe traza runtime ni commit formal de la ejecución capturada.
```

## Comentarios

`XL-0009` sí contiene lógica funcional y no debe clasificarse como una simple regla auxiliar de presentación.

El hallazgo principal es:

```text
Excel:
repetición iterativa con incremento J34
```

```text
Python:
extensión vectorizada con incremento calculado
```

La equivalencia final depende de revisar `J34`, que corresponde a `XL-0012`, y de confirmar el alcance temporal y las condiciones aplicables.

---


# XL-0010

## Resultado reportado por el comparador

```yaml
rule_id: XL-0010
system_verdict: NO_LOCALIZADO
system_confidence: 0.75
excel_sheet: Calculadora
excel_cell: AP30
formula_type: FORMULA_AUXILIAR
excel_formula: "=AP28-AP29"
excel_cached_value: 0.35896831239318894
```

## Evidencia revisada

```yaml
AP28:
  formula: "=AO28+$J$34"
  value: 0.35896831239318894
AP29:
  formula: null
  value: null
AP30:
  formula: "=AP28-AP29"
  value: 0.35896831239318894
```

En esta fórmula, `AP29` está vacío. En el cálculo almacenado del libro, `AP30` conserva exactamente el valor de `AP28`.

## Preguntas de validación

- [x] ¿AP30 resta AP29 de AP28?
- [x] ¿AP29 está vacío en el libro inspeccionado?
- [x] ¿AP30 y AP28 tienen el mismo valor almacenado?
- [x] ¿La regla está clasificada como fórmula auxiliar?
- [x] ¿La regla evita agregar una transformación de negocio independiente?
- [ ] ¿Se confirmó mediante runtime el tratamiento del valor vacío en la ejecución original del Excel?

## Decisión humana

```yaml
human_verdict: NO_APLICA
review_completed: true
formula_classification: FORMULA_AUXILIAR
business_logic_introduced: false
empty_reference_validation: CONFIRMADA
value_identity_validation: CONFIRMADA
python_equivalent_required: false
runtime_validation: PENDIENTE

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0010
  - outputs/artifacts/mapping.json:XL-0010
  - Calculadora!AP28:AP30
  - evidence/XL_0010_0011_0012_combined.json

confirmed_evidence:
  - AP29 no contiene fórmula ni valor almacenado.
  - AP30 y AP28 tienen el mismo valor almacenado.
  - XL-0010 no introduce un parámetro, condición o transformación adicional.

reason: >
  XL-0010 es una fórmula auxiliar del Excel. En el libro inspeccionado,
  AP29 está vacío y AP30 conserva el mismo valor de AP28. La regla no
  constituye una transformación funcional independiente que deba tener
  una implementación Python separada. Por ello se clasifica como NO_APLICA
  para la comparación funcional directa.

limitations:
  - La clasificación se basa en el libro del baseline inspeccionado.
  - No se verificó una traza de cálculo del motor Excel original.
```

---

# XL-0011

## Resultado reportado por el comparador

```yaml
rule_id: XL-0011
system_verdict: NO_VERIFICABLE
system_confidence: 0.25
excel_sheet: Calculadora
excel_cell: I34
excel_header: Para el plazo 36
formula_type: FORMULA_AUXILIAR
excel_formula: "=H34*R27"
excel_cached_value: 0.35896831239318916
```

## Evidencia revisada

### Excel

```yaml
factor_cell: H34
factor_value: 2.0574374079528717
base_curve_cell: R27
base_curve_period: 12
base_curve_value: 0.17447350330348996
target_cell: I34
target_formula: "=H34*R27"
target_value: 0.35896831239318916
```

### Python

```python
factor_flat = 2.05743740795287
factor_plazo_12 = factor_flat * curve[:, 11]
```

## Correspondencias observadas

```text
H34        ↔ factor_flat
R27        ↔ curve[:, 11]
I34        ↔ factor_plazo_12
periodo 12 ↔ índice 11 del arreglo Python
```

## Comparación numérica

```yaml
excel_factor: 2.0574374079528717
python_factor: 2.05743740795287
factor_absolute_difference: 1.7763568394002505e-15
factor_within_absolute_tolerance_1e_12: true
excel_target_value: 0.35896831239318916
python_expression_structure: "factor_flat * curve[:, 11]"
```

## Preguntas de validación

- [x] ¿H34 coincide numéricamente con `factor_flat`?
- [x] ¿R27 representa el periodo 12 de la curva Excel?
- [x] ¿`curve[:, 11]` representa el periodo 12 en Python?
- [x] ¿La estructura `H34 * R27` coincide con `factor_flat * curve[:, 11]`?
- [x] ¿I34 representa el valor objetivo utilizado para construir la extensión lineal?
- [ ] ¿Se confirmó que esta variante de la función Python fue ejecutada en la corrida del baseline?
- [ ] ¿Se confirmó que el producto y el plazo del caso activan este ajuste?
- [ ] ¿Se confirmó el commit o versión formal del proyecto ejecutado?

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
review_completed: true
factor_identity_validation: CONFIRMADA
base_period_identity_validation: CONFIRMADA_ESTRUCTURALMENTE
target_expression_validation: CONFIRMADA
static_code_trace: CONFIRMADA
runtime_usage_validation: PENDIENTE
condition_scope_validation: PENDIENTE
version_validation: PENDIENTE

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0011
  - outputs/artifacts/mapping.json:XL-0011
  - Calculadora!H34
  - Calculadora!I34
  - Calculadora!R27
  - clv/source/engine/utils.py:439-457
  - evidence/XL_0010_0011_0012_combined.json

confirmed_evidence:
  - H34 coincide con factor_flat dentro de 1e-12.
  - R27 corresponde al periodo 12 de la curva Excel.
  - Python usa el índice 11 para el periodo 12.
  - Excel y Python multiplican el mismo tipo de valor base por el mismo factor.
  - I34 corresponde estructuralmente a factor_plazo_12.

reason: >
  La fórmula de I34 coincide estructural y numéricamente con el cálculo
  factor_plazo_12 de Python. El factor del Excel y factor_flat presentan
  una diferencia de aproximadamente 1.78e-15. Sin embargo, no existe
  evidencia runtime que confirme que la variante inspeccionada fue la
  ejecutada durante la corrida del baseline ni que sus condiciones de
  producto y plazo se cumplieron. Por ello, la regla queda como
  NO_DETERMINABLE pese a la fuerte evidencia estática.

limitations:
  - No se confirmó mediante runtime la función ejecutada.
  - No se confirmó product_code_final igual a 1 para el caso Excel.
  - No se confirmó CantidadPlazo mayor que 24 para la rama Python.
  - No se confirmó el commit o versión formal del proyecto.
```

---

# XL-0012

## Resultado reportado por el comparador

```yaml
rule_id: XL-0012
system_verdict: NO_LOCALIZADO
system_confidence: 0.45
excel_sheet: Calculadora
excel_cell: J34
formula_type: FORMULA_AUXILIAR
excel_formula: "=(I34-R27)/24"
excel_cached_value: 0.0076872837120708
```

## Evidencia revisada

### Excel

```yaml
target_period_36_cell: I34
target_period_36_value: 0.35896831239318916
base_period_12_cell: R27
base_period_12_value: 0.17447350330348996
period_distance: 24
increment_cell: J34
increment_formula: "=(I34-R27)/24"
increment_value: 0.0076872837120708
```

### Python

```python
factor_plazo_12 = factor_flat * curve[:, 11]

factor_plazo_12_to_36 = (
    factor_plazo_12 - curve[:, 11]
) / 24
```

## Correspondencias observadas

```text
I34        ↔ factor_plazo_12
R27        ↔ curve[:, 11]
24         ↔ distancia de periodos 12 a 36
J34        ↔ factor_plazo_12_to_36
```

## Validación de la progresión

```yaml
progression_range: S28:BZ28
checked_increment_count: 60
matching_increment_count: 60
j34_value: 0.0076872837120708
maximum_absolute_difference_vs_j34: 3.5561831257524545e-17
all_increments_match_within_1e_12: true
```

## Preguntas de validación

- [x] ¿La estructura `(I34-R27)/24` existe en Python con variables equivalentes?
- [x] ¿I34 corresponde estructuralmente a `factor_plazo_12`?
- [x] ¿R27 corresponde estructuralmente a `curve[:, 11]`?
- [x] ¿Python divide la diferencia entre el objetivo y el periodo 12 entre 24?
- [x] ¿J34 coincide con los 60 incrementos observados en `S28:BZ28`?
- [x] ¿La diferencia máxima observada está dentro de 1e-12?
- [ ] ¿El alcance Python de periodos 13 a 36 coincide con el alcance Excel de periodos 13 a 72?
- [ ] ¿Se confirmó que las condiciones de producto y plazo aplican al caso Excel?
- [ ] ¿Se confirmó mediante runtime la variante Python ejecutada?
- [ ] ¿Se reconciliaron los valores finales de la curva Excel contra una salida Python capturada?

## Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
review_completed: true
increment_formula_validation: CONFIRMADA
increment_numeric_consistency: CONFIRMADA
progression_internal_consistency: CONFIRMADA
python_static_code_trace: CONFIRMADA
period_range_validation: NO_COINCIDE
condition_scope_validation: PENDIENTE
runtime_usage_validation: PENDIENTE
numeric_excel_python_reconciliation: NO_EJECUTADA

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0012
  - outputs/artifacts/mapping.json:XL-0012
  - Calculadora!R27
  - Calculadora!H34:J34
  - Calculadora!S28:BZ28
  - clv/source/engine/utils.py:439-457
  - evidence/XL_0010_0011_0012_combined.json
  - evidence/PENDING_RULES_REVIEW.md:XL-0009

confirmed_evidence:
  - La fórmula de J34 coincide estructuralmente con factor_plazo_12_to_36.
  - Los 60 incrementos de S28:BZ28 coinciden con J34 dentro de 1e-12.
  - La diferencia máxima observada es aproximadamente 3.56e-17.
  - Python utiliza el mismo divisor 24.
  - Python aplica el incremento de forma vectorizada.
  - El alcance temporal observado difiere entre Excel y Python.

reason: >
  J34 corresponde estructuralmente al incremento calculado por Python para
  extender linealmente la curva desde el periodo 12 hasta el periodo 36.
  La consistencia interna del Excel quedó confirmada en las 60 celdas de
  S28:BZ28. Sin embargo, Excel prolonga el incremento hasta el periodo 72,
  mientras el bloque Python observado lo aplica hasta el periodo 36 y bajo
  condiciones de producto y plazo. Tampoco existe evidencia runtime ni una
  reconciliación de outputs. Por ello, la regla queda como NO_DETERMINABLE.

limitations:
  - Excel extiende la progresión hasta el periodo 72.
  - Python extiende la progresión observada hasta el periodo 36.
  - No se confirmó product_code_final igual a 1 para el caso Excel.
  - No se confirmó CantidadPlazo mayor que 24 para la rama Python.
  - No se confirmó cuál variante de la función fue ejecutada.
  - No existe reconciliación numérica Excel contra una salida Python.
```

## Impacto en XL-0009

La revisión de `XL-0012` resuelve una incertidumbre de `XL-0009`:

```yaml
XL_0009_increment_identity_validation: CONFIRMADA
XL_0009_excel_progression_internal_consistency: CONFIRMADA
XL_0009_final_verdict: NO_DETERMINABLE
XL_0009_remaining_blockers:
  - El alcance Excel llega al periodo 72 y Python al periodo 36.
  - Las condiciones de producto y plazo no fueron confirmadas.
  - No existe evidencia runtime.
  - No existe reconciliación numérica de outputs.
```

---


## Resultado consolidado

```yaml
XL-0001: NO_DETERMINABLE
XL-0003: NO_DETERMINABLE
XL-0005: NO_DETERMINABLE
XL-0006: NO_DETERMINABLE
XL-0008: NO_APLICA
XL-0009: NO_DETERMINABLE
XL-0010: NO_APLICA
XL-0011: NO_DETERMINABLE
XL-0012: NO_DETERMINABLE

confirmed_count: 0
rejected_count: 0
inconclusive_count: 7
not_applicable_count: 2
pending_count: 0
```

---

## Estado del baseline

```yaml
pending_rules_review_completed: true
human_validation_completed: true
baseline_can_be_frozen: false
```

---

## Control documental

```yaml
document: evidence/PENDING_RULES_REVIEW.md
status: COMPLETED

completed_rules:
  - XL-0001
  - XL-0003
  - XL-0005
  - XL-0006
  - XL-0008
  - XL-0009
  - XL-0010
  - XL-0011
  - XL-0012

pending_rules: []

allows_baseline_freeze: false

next_action: >
  Consolidar los resultados esperados, divergencias de versión,
  falsos positivos, falsos negativos, reglas no aplicables y
  limitaciones generales del baseline.
  
Reglas revisadas:      9
NO_DETERMINABLE:       7
NO_APLICA:             2
PENDIENTES:            0
Baseline congelado:    No
```
