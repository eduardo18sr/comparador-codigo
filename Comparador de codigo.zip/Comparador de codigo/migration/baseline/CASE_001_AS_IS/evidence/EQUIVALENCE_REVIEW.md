# Revisión humana de equivalencias

## Control del documento

```yaml
case_id: CASE_001_AS_IS
review_type: EQUIVALENCE_REVIEW
review_status: IN_PROGRESS
reviewer_name: Eduardo Saldaña
review_date: PENDIENTE
review_scope:
  - XL-0002
  - XL-0004
  - XL-0007
```

---

## Instrucciones

Para cada regla se debe revisar:

- La fórmula original del Excel.
- El valor calculado o almacenado en el Excel.
- La ubicación reportada en el proyecto Python.
- Las entradas utilizadas.
- Los parámetros utilizados.
- Las condiciones o segmentos aplicables.
- La salida esperada.
- Si la evidencia corresponde al mismo cálculo de negocio.

No se debe aprobar una equivalencia únicamente porque:

- utiliza la misma operación matemática;
- contiene números similares;
- utiliza una función logística;
- menciona variables con nombres parecidos;
- el comparador reportó confianza alta.

Estados permitidos:

```text
CONFIRMADA
RECHAZADA
NO_DETERMINABLE
PENDIENTE
```

---

## XL-0002

### Resultado reportado por el comparador

```yaml
system_verdict: EQUIVALENTE
system_confidence: 0.98
excel_formula: "=40/LN(2)"
reported_python_parameter: factor
reported_python_value: 57.7078016355585
reported_source: clv/params/pd_scalars.csv
```

### Preguntas de validación

- [x] ¿El valor de `factor` coincide numéricamente con `40/LN(2)`?
- [ ] ¿El archivo `pd_scalars.csv` corresponde al modelo y versión evaluados?
- [ ] ¿El código utiliza ese mismo archivo durante la ejecución productiva?
- [x] ¿El parámetro `factor` tiene el mismo significado funcional que la fórmula del Excel?
- [x] ¿La precisión o el redondeo son aceptables?
- [ ] ¿Existe evidencia suficiente para vincular la fórmula con el parámetro?

### Decisión humana

```yaml
human_verdict: NO DETERMINABLE
numeric_validation: CONFIRMADA
semantic_identity_validation: CONFIRMADA
static_code_trace: CONFIRMADA
runtime_usage_validation: PENDIENTE
version_validation: PENDIENTE

excel_sheet: Calculadora
excel_cell: H7
excel_header: Factor
excel_formula: "=40/LN(2)"
excel_cached_value: 57.70780163555854

python_parameter: factor
python_parameter_file: clv/params/pd_scalars.csv
python_observed_value: 57.7078016355585
python_usage: "XB_pd = -(score - offset) / factor"

absolute_difference: 3.552713678800501e-14
absolute_tolerance: 1.0e-8
within_tolerance: true

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0002
  - clv/params/pd_scalars.csv
  - clv/source/engine/CLV_Engine.py:78-98
  - clv/source/engine/utils.py:267-269
  - clv/source/engine/utils.py:2946-2956
  - clv/source/engine/utils.py:2966-2976

confirmed_evidence:
  - La regla XL-0002 corresponde a la celda H7 de la hoja Calculadora.
  - El encabezado de H7 es Factor.
  - La fórmula de H7 es 40/LN(2).
  - El valor calculado en Excel es 57.70780163555854.
  - pd_scalars.csv contiene el parámetro factor con valor 57.7078016355585.
  - CLV_Engine.set_path_pd carga pd_scalars.csv.
  - El contenido se almacena como param_scalar.
  - utils.py extrae factor desde param_scalar.
  - factor se utiliza en XB_pd = -(score - offset) / factor.
  - La diferencia numérica se encuentra dentro de la tolerancia.

reason: >
  Se confirmó que XL-0002 representa el factor de escala del score en la
  celda H7 de la hoja Calculadora. El proyecto Python carga un archivo
  pd_scalars.csv, extrae un parámetro denominado factor y utiliza ese
  parámetro como divisor en la transformación XB_pd. El valor del Excel
  y el valor del CSV coinciden dentro de la tolerancia definida. La
  decisión permanece pendiente únicamente porque no se ha confirmado
  mediante runtime que este flujo se ejecutó en la corrida capturada ni
  que el archivo inspeccionado sea la versión formal aplicable.

limitations:
  - No se confirmó mediante traza runtime que set_path_pd fue ejecutado.
  - No se confirmó la versión o commit formal del proyecto.
  - No se confirmó que el pd_scalars.csv inspeccionado sea la versión formal aplicable a la corrida.

validation_scope_completed: true
closure_reason: >
  La coincidencia numérica, la identidad semántica del parámetro y la
  trazabilidad estática desde pd_scalars.csv hasta el cálculo XB_pd fueron
  confirmadas. No existe evidencia runtime suficiente para demostrar que
  esta ruta fue ejecutada durante la corrida capturada del baseline.
  Por ello, la equivalencia no puede declararse confirmada integralmente.

remaining_uncertainty:
  - Ejecución efectiva de set_path_pd durante la corrida de referencia.
  - Función concreta de utils.py invocada durante la corrida.
  - Versión formal o commit del proyecto utilizado.
  - Confirmación formal de que pd_scalars.csv era el archivo aplicable.

closure_type: STATICALLY_SUPPORTED_RUNTIME_UNCONFIRMED
```

### Comentarios

Se confirmó la trazabilidad estática:

```text
Calculadora!H7
Encabezado: Factor
Fórmula: 40/LN(2)
Valor: 57.70780163555854
        ↓
clv/params/pd_scalars.csv
factor = 57.7078016355585
        ↓
CLV_Engine.set_path_pd()
        ↓
param_scalar
        ↓
factor
        ↓
XB_pd = -(score - offset) / factor
```

## XL-0004
### Preguntas de validación

- [x] ¿La expresión matemática en Python es equivalente a la fórmula del Excel?
- [x] ¿La variable de entrada en Python representa el mismo concepto que `valor` en el Excel?
- [x] ¿La ubicación relevante pertenece al componente evaluado?
- [x] ¿El signo del exponente es equivalente?
- [ ] ¿Las transformaciones previas a la función logística son equivalentes?
- [ ] ¿Las transformaciones posteriores son equivalentes?
- [ ] ¿La coincidencia corresponde al mismo cálculo de negocio y no solo a una forma matemática común?

### Decisión humana

```yaml
human_verdict: NO_DETERMINABLE
mathematical_structure_validation: CONFIRMADA
exponent_sign_validation: CONFIRMADA
base_input_validation: CONFIRMADA
temporal_parameter_validation: DIVERGENCIA_DE_VERSION
pre_transformation_validation: NO_CONFIRMADA
post_transformation_validation: PENDIENTE
runtime_usage_validation: PENDIENTE

excel_sheet: Calculadora
excel_cells:
  - H9
  - H10
  - H12
  - H13

excel_temporal_parameters:
  plazo_0_18:
    alpha: 0.2151438827
    beta: 1.0238688556
  plazo_19_24:
    alpha: -1.32304e-09
    beta: 0.9999999993
  plazo_25_36:
    alpha: -9.0105e-10
    beta: 0.9999999996

matching_parameter_file:
  path: clv/params/pd_thetaT_actualizado_202605.csv
  status: COINCIDE_CON_EXCEL
  code_usage_status: COMENTADO_EN_CLV_ENGINE

active_parameter_file:
  path: clv/params/pd_thetaT_actualizado_sep24_v2.csv
  status: NO_COINCIDE_CON_EXCEL
  code_usage_status: ACTIVO_EN_CLV_ENGINE

active_code_evidence:
  - "CLV_Engine.py:80 carga pd_thetaT_actualizado_sep24_v2.csv"
  - "CLV_Engine.py:81 contiene comentado pd_thetaT_actualizado_202605.csv"

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0004
  - outputs/artifacts/mapping.json:XL-0004
  - Calculadora!H8:M11
  - clv/source/engine/CLV_Engine.py:78-98
  - clv/source/engine/utils.py:282-311
  - clv/params/pd_thetaT_actualizado_202605.csv
  - clv/params/pd_thetaT_actualizado_sep24_v2.csv
  - clv/params/pd_rango_Tt_202605.csv
  - clv/params/pd_rango_Tt_sep24_v2.csv

confirmed_evidence:
  - La estructura logística de Excel y Python es matemáticamente compatible.
  - Excel H9 y Python xBeta aplican la misma transformación base del score.
  - Los parámetros temporales del Excel coinciden con pd_thetaT_actualizado_202605.csv dentro del redondeo observado.
  - CLV_Engine.py no carga activamente pd_thetaT_actualizado_202605.csv.
  - CLV_Engine.py carga activamente pd_thetaT_actualizado_sep24_v2.csv.
  - Los primeros parámetros de product_code_final 1 en sep24_v2 difieren de los valores del Excel.
  - Python aplica adicionalmente factor_pd después de la función logística.

reason: >
  La estructura matemática de la función logística y la transformación
  base del score son equivalentes. Sin embargo, los parámetros temporales
  del Excel corresponden al archivo pd_thetaT_actualizado_202605.csv,
  mientras que el código inspeccionado carga activamente
  pd_thetaT_actualizado_sep24_v2.csv. Los valores del archivo activo
  difieren de los valores del Excel. No se puede confirmar equivalencia
  funcional completa hasta determinar cuál versión de parámetros es la
  aplicable a la ejecución evaluada y cuál product_code_final corresponde
  al caso de la calculadora.

limitations:
  - No se confirmó formalmente el product_code_final de la calculadora.
  - No se confirmó mediante runtime qué archivo fue leído en la ejecución capturada.
  - No se confirmó si la línea 202605 comentada representa una versión posterior pendiente de despliegue.
  - No se determinó si factor_pd forma parte del alcance de la calculadora.
```

### Comentarios

La forma logística es equivalente, pero se identificó una divergencia
de versión en los parámetros temporales.

```text
Parámetros del Excel
        ↓ coinciden con
pd_thetaT_actualizado_202605.csv
```

Sin embargo, el código activo contiene:

```python
p1 = (
    Path(".").resolve()
    / "clv"
    / self.path
    / "pd_thetaT_actualizado_sep24_v2.csv"
)
```

Y la referencia a `202605` está comentada.

Para el primer rango observado:

```text
Excel:
alpha = 0.2151438827
beta  = 1.0238688556

202605:
alpha = 0.215143883
beta  = 1.023868856

sep24_v2 activo:
alpha = -0.630186337
beta  = 0.723944645
```

Por tanto, la alta confianza reportada por el comparador solo demuestra
coincidencia de la forma logística. No demuestra que la implementación
utilice los mismos parámetros que la calculadora.

El veredicto humano de XL-0004 se mantiene como `NO_DETERMINABLE` hasta
confirmar la versión aplicable, el producto evaluado y la ejecución real.
```

El ajuste `factor_pd` podría representar una transformación productiva
adicional no visible directamente en `H13`.

Las demás funciones logísticas recuperadas por el mapping no se consideran
evidencia suficiente para esta regla, porque pertenecen a contextos
funcionales diferentes.
```
---

## XL-0007

### Resultado reportado por el comparador

```yaml
system_verdict: EQUIVALENTE
system_confidence: 0.92
excel_sheet: Calculadora
excel_range: I27:BZ27
excel_header: PD TEMPORAL
excel_period_count: 70
reported_python_source: clv/source/engine/utils.py
reported_behavior:
  - cálculo logístico
  - selección de alpha_t
  - selección de beta_t
  - condición por rango de plazo
```

### Preguntas de validación

- [x] ¿La variable `H8` representa el mismo concepto que el rango utilizado en Python?
- [x] ¿Los límites `19` y `25` tienen equivalencia en el código?
- [x] ¿Los parámetros `alpha_t` y `beta_t` corresponden estructuralmente a los parámetros del Excel?
- [x] ¿Los valores numéricos de los parámetros coinciden con alguna versión encontrada?
- [ ] ¿Los segmentos y códigos de producto aplicables son los mismos?
- [ ] ¿El factor adicional `factor_pd` forma parte del alcance?
- [ ] ¿La salida del código activo representa exactamente la misma PD temporal?
- [ ] ¿Existe evidencia suficiente para declarar equivalencia funcional completa?

### Decisión humana

```yaml
human_verdict: NO_DETERMINABLE

mathematical_structure_validation: CONFIRMADA
period_range_structure_validation: CONFIRMADA
temporal_parameter_structure_validation: CONFIRMADA
active_parameter_value_validation: NO_COINCIDE
alternative_parameter_value_validation: COINCIDE
product_code_validation: PENDIENTE
factor_pd_validation: PENDIENTE
runtime_usage_validation: PENDIENTE

excel_evidence:
  sheet: Calculadora
  output_range: I27:BZ27
  alpha_range: I21:BZ21
  beta_range: I22:BZ22
  period_count: 70
  plazo_cell: H8
  plazo_value: 18

comparison_with_active_file:
  path: clv/params/pd_thetaTt_actualizado_sep24_v2.csv
  matched_period_count: 0
  mismatch_count: 70
  period_not_found_count: 0
  ambiguous_match_count: 0
  full_coverage_match: false
  status: NO_COINCIDE_CON_EXCEL

comparison_with_alternative_file:
  path: clv/params/pd_thetaTt_actualizado_202605.csv
  matched_period_count: 70
  mismatch_count: 0
  period_not_found_count: 0
  ambiguous_match_count: 0
  full_coverage_match: true
  status: COINCIDE_COMPLETAMENTE_CON_EXCEL

active_code_configuration:
  active_file: clv/params/pd_thetaTt_actualizado_sep24_v2.csv
  alternative_file: clv/params/pd_thetaTt_actualizado_202605.csv
  alternative_file_reference_status: COMENTADA_EN_CLV_ENGINE

filter_assumption:
  product_code_final: 1
  rango_plazo: 1
  status: PENDIENTE_DE_CONFIRMAR

evidence_reviewed:
  - outputs/artifacts/rules.json:XL-0007
  - outputs/artifacts/mapping.json:XL-0007
  - Calculadora!H8
  - Calculadora!I21:BZ22
  - Calculadora!I27:BZ27
  - clv/source/engine/CLV_Engine.py:78-98
  - clv/source/engine/utils.py:282-311
  - clv/params/pd_thetaTt_actualizado_sep24_v2.csv
  - clv/params/pd_thetaTt_actualizado_202605.csv
  - XL_0007_full_parameter_comparison.json

confirmed_evidence:
  - Excel genera 70 valores de PD temporal entre I27 y BZ27.
  - Excel utiliza 70 pares de parámetros alpha_t y beta_t.
  - Python utiliza alpha_t y beta_t para calcular la curva temporal.
  - La estructura logística condicional del Excel está representada en Python.
  - Los 70 pares de parámetros del Excel difieren de los 70 pares del archivo activo sep24_v2.
  - Los 70 pares de parámetros del Excel coinciden con los 70 pares del archivo alternativo 202605.
  - No faltaron periodos en ninguna de las dos comparaciones.
  - No se identificaron coincidencias ambiguas por periodo.

reason: >
  La estructura matemática y el procedimiento general para construir la
  PD temporal son compatibles entre Excel y Python. Sin embargo, los 70
  pares de parámetros temporales utilizados por el Excel no coinciden con
  el archivo sep24_v2 configurado activamente en CLV_Engine.py. Los 70
  pares del Excel sí coinciden completamente con el archivo alternativo
  202605, cuya referencia está comentada en el código inspeccionado.
  Por ello, no existe evidencia suficiente para confirmar que la versión
  activa de la implementación produzca la misma curva temporal que el
  Excel del baseline.

limitations:
  - No se confirmó formalmente que product_code_final 1 corresponda al caso evaluado.
  - No se confirmó mediante runtime qué archivo de parámetros fue leído en la ejecución capturada.
  - No se confirmó por qué la referencia 202605 está comentada.
  - No se confirmó si factor_pd está representado en la calculadora.
  - No se realizó una reconciliación numérica de los 70 outputs de PD temporal.
```

### Comentarios

La estructura del cálculo es comparable:

```text
Excel:
IF por rango de plazo
    ↓
alpha_t + beta_t * H12
    ↓
función logística
    ↓
PD temporal
```

```text
Python:
selección por product_code_final y rango_plazo
    ↓
alpha_t + beta_t * xBetaCalibrado
    ↓
función logística
    ↓
pdTemporal
    ↓
ajuste adicional factor_pd
```

La comparación completa de parámetros produjo:

```text
Archivo activo sep24_v2:
0 coincidencias de 70
70 diferencias de 70

Archivo alternativo 202605:
70 coincidencias de 70
0 diferencias de 70
```

Por tanto, la clasificación automática `EQUIVALENTE` con confianza `0.92`
no debe aceptarse como resultado esperado. La forma matemática coincide,
pero los parámetros de la versión activa no coinciden con el Excel.

La regla queda como `NO_DETERMINABLE`, no como `RECHAZADA`, porque todavía
no se ha confirmado qué versión de parámetros fue utilizada en la ejecución
de referencia ni cuál era la versión formalmente aplicable.

---


---

## Resultado consolidado

```yaml
XL-0002: NO DETERMINABLE
XL-0004: NO DETERMINABLE
XL-0007: NO DETERMINABLE
confirmed_count: 0
rejected_count: 0
inconclusive_count: 3
pending_count: 0
```

---

## Regla para el baseline

Mientras alguna regla permanezca como `PENDIENTE`:

```yaml
human_validation_completed: true
equivalence_review_completed: true
baseline_can_be_frozen: false
```

Estas decisiones no deberán copiar automáticamente los veredictos producidos por el comparador.

---

## Control documental

```yaml
document: evidence/EQUIVALENCE_REVIEW.md
status: COMPLETED
human_approval: COMPLETED_WITH_LIMITATIONS
allows_baseline_freeze: false
next_action: Consolidar resultados esperados y limitaciones del baseline
```
