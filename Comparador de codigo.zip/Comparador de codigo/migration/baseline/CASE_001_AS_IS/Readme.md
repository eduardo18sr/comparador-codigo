# CASE_001_AS_IS

## 1. Propósito

Este baseline preserva el comportamiento actual del comparador antes de:

- corregir defectos;
- modificar configuraciones;
- refactorizar componentes;
- separar lógica general de lógica específica de EAD;
- incorporar Word o PDF;
- aplicar la arquitectura objetivo.

Este baseline no representa necesariamente el comportamiento correcto
del sistema.

Los resultados actuales deberán diferenciarse de los resultados esperados
revisados por una persona.

---

## 2. Identificación del caso

```yaml
case_id: CASE_001_AS_IS
case_name: Caso heredado actual
baseline_status: REVIEWED_NOT_FROZEN
baseline_type: brownfield
comparison_type: Excel_vs_Python
business_case: PENDIENTE_DE_CONFIRMAR
model_type: PENDIENTE_DE_CONFIRMAR
execution_environment: Databricks
```

---

## 3. Fuentes del baseline

### 3.1 Archivo Excel

```yaml
file_name: calculadora_final.xlsx
original_path: /dbfs/FileStore/comparador/input/calculadora_final.xlsx
local_copy_available: false
version_or_date: "2026-08-24T16:47:15"
size_bytes: 37293
sha256: 86b8c171b92bf9cd3a6f580bdd37716e0e8d045950bde7943b4853000420756e
```

### 3.2 Proyecto Python

```yaml
project_name: prdl-app-clv-pyme-ct-af-modelos-feature-inicial
original_path: /Workspace/Users/eduardosaldana@bcp.com.pe/proyecto/prdl-app-clv-pyme-ct-af-modelos-feature-inicial
local_copy_available: false
version_or_commit: NO_CONFIRMADO
sha256_or_snapshot_id: 62c6a54b26d5386ceb30b3decbd670bf918fd5898226caa0cac23416006dae04
manifest_file: inputs/python_project_manifest.json
file_count: 540
unreadable_count: 23
manifest_completeness: PARTIAL
captured_at: "2026-09-14T14:50:30.610631"
```

### 3.3 Documentos adicionales

```yaml
word_available: false
pdf_available: false
csv_available: PENDIENTE
other_sources: []
```

Word y PDF no forman parte del baseline hasta que su uso real esté
confirmado y sus archivos se incorporen expresamente.

---

## 4. Configuración utilizada

```yaml
config_file: config/execution_config.json
config_source: Databricks
config_snapshot_available: true
llm_enabled: PENDIENTE
llm_endpoint: PENDIENTE
reconciliation_mode: PENDIENTE
allowed_strategies: PENDIENTE
absolute_tolerance: PENDIENTE
relative_tolerance: PENDIENTE
```

La configuración almacenada corresponde a la variable utilizada por el
notebook de Databricks.

No se deberán registrar tokens, contraseñas, claves de API ni otros secretos.

Los valores sensibles deberán mantenerse como:

```text
<REDACTED>
```

---

## 5. Versión del comparador

```yaml
package_name: excel-code-compare
declared_version: 0.1.0
python_required: ">=3.10"
code_snapshot_available: false
repository_commit: NO_CONFIRMADO
execution_notebook: notebooks/00_ejecutar_en_databricks
entry_point: excel_code_compare.cli:main
```

---

## 6. Ejecución de referencia

```yaml
execution_status: CAPTURED_FROM_EXISTING_OUTPUTS
execution_date: PENDIENTE
execution_id: NO_CONFIRMADO
executed_by: Eduardo Saldaña
completed_end_to_end: PENDIENTE_DE_VERIFICAR
technical_errors:
  - strategy_discovery_status: NOT_SELECTED
  - reconciliation_status: NOT_RUN
```

La ejecución de referencia deberá realizarse sin modificar:

- el código;
- la configuración;
- los nombres de estrategias;
- las tolerancias;
- los archivos originales;
- las dependencias del entorno.

---

## 7. Resultados observados antes de la migración

De acuerdo con la inspección del sistema AS-IS, se observaron previamente
los siguientes resultados:

```yaml
strategy_discovery_status: NOT_SELECTED
strategy_candidates: []
reconciliation_status: NOT_RUN
final_verdict: PENDIENTE_DE_COPIAR
```

Estos valores representan resultados observados del sistema actual.

No constituyen:

- resultados esperados;
- evidencia de funcionamiento correcto;
- un golden dataset;
- una validación humana;
- una aprobación del comparador.

---

## 8. Defectos conocidos relevantes

### D-001. Identificadores de estrategias desalineados

Los identificadores configurados en el notebook no coinciden con los
nombres internos declarados por las estrategias.

Configuración observada:

```text
parameter_table_comparison
formula_recalculation
scalar_output_comparison
tabular_output_comparison
```

Nombres internos observados:

```text
parameter_table
scalar_formula
tabular_formula
temporal_curve
production_function
```

Efecto observado:

```text
candidates = []
strategy_discovery_status = NOT_SELECTED
reconciliation_status = NOT_RUN
```

Este defecto no deberá corregirse antes de capturar el baseline.

### D-002. Prueba canónica desalineada

La prueba:

```text
tests/test_canonical.py
```

importa una función llamada:

```python
canonicalize
```

pero la implementación inspeccionada expone:

```python
canonicalize_with_context
canonicalize_structural
```

Este defecto deberá conservarse durante la captura del baseline.

### D-003. Dependencias incompletas

El código utiliza:

```text
numpy
pandas
```

pero estas dependencias no aparecen en los manifiestos inspeccionados.

El entorno de Databricks podría tenerlas disponibles, pero esto no
demuestra que la instalación sea reproducible en otro entorno.

### D-004. Configuración duplicada de reconciliación

El archivo de ejemplo inspeccionado contiene dos bloques raíz llamados:

```yaml
reconciliation:
```

El archivo `config/execution_config.json` deberá preservar únicamente la
configuración real recibida por la ejecución, sin corregirla manualmente.

### D-005. Threshold configurado no transmitido

La configuración declara:

```text
parameter_density_threshold
```

pero el flujo inspeccionado no transmite explícitamente ese valor a
`inventory_excel()`.

El comportamiento actual utiliza el valor predeterminado observado en la
implementación.

---

## 9. Artefactos que deben capturarse

Después de ejecutar el caso sin modificaciones, deberán copiarse a la
carpeta `outputs/` todos los artefactos que realmente hayan sido generados.

### 9.1 Inventario Excel

```text
01_mapa_excel.md
artifacts/excel_inventory.json
artifacts/raw_cells.json
```

### 9.2 Reglas Excel

```text
02_celdas.csv
03_reglas_excel.md
04_parametros.json
artifacts/rules.json
```

### 9.3 Candidatos de implementación

```text
05_candidatos.md
artifacts/candidates.json
```

### 9.4 Grafo estático

```text
06_grafo.md
artifacts/callgraph.json
```

### 9.5 Correspondencias semánticas

```text
07_correspondencia.md
artifacts/mapping.json
artifacts/mapping_batches/
```

### 9.6 Reconciliación

```text
08_reconciliacion.md
artifacts/strategy_discovery.json
artifacts/reconciliation.json
artifacts/reconciliation_components/
```

### 9.7 Resultado final

```text
resultado_final.md
```

No es obligatorio que todos los artefactos existan.

Si un artefacto no fue generado, deberá registrarse como:

```text
NOT_GENERATED
```

No se deberá crear un archivo vacío para simular su existencia.

---

## 10. Evidencia humana pendiente

La carpeta `evidence/` deberá contener posteriormente:

```text
EXPECTED_RESULTS.md
HUMAN_REVIEW.md
KNOWN_FALSE_POSITIVES.md
KNOWN_FALSE_NEGATIVES.md
```

### 10.1 `EXPECTED_RESULTS.md`

Deberá documentar los resultados que una persona espera para el caso,
independientemente de la respuesta actual del comparador.

### 10.2 `HUMAN_REVIEW.md`

Deberá registrar qué resultados fueron revisados, cuáles son correctos,
cuáles son incorrectos y cuáles no se pueden determinar.

### 10.3 `KNOWN_FALSE_POSITIVES.md`

Deberá registrar hallazgos reportados por el comparador que una persona
determinó que no corresponden a diferencias reales.

### 10.4 `KNOWN_FALSE_NEGATIVES.md`

Deberá registrar diferencias reales que el comparador no logró detectar.

Estos archivos no deberán completarse copiando automáticamente la
conclusión generada por el comparador.

---

## 11. Criterio para congelar el baseline

El baseline podrá cambiar de:

```yaml
baseline_status: PREPARING
```

a:

```yaml
baseline_status: FROZEN
```

únicamente cuando estén disponibles:

- la identificación exacta del archivo Excel;
- la ruta original del archivo Excel;
- una copia o referencia controlada del archivo Excel;
- la identificación exacta del proyecto Python;
- la ruta original del proyecto Python;
- una copia, commit o snapshot del proyecto Python;
- la configuración real de la ejecución;
- la versión o snapshot del código del comparador;
- todos los outputs generados;
- los errores técnicos observados;
- el resultado final generado;
- una revisión humana inicial;
- hashes o identificadores de las fuentes, cuando sea posible.

Actualmente el baseline debe permanecer en:

```yaml
baseline_status: PREPARING
```

---

## 12. Restricciones

Mientras el baseline esté en estado `PREPARING`, no se deberá:

- corregir los nombres de las estrategias;
- modificar tolerancias;
- agregar dependencias;
- corregir la prueba canónica;
- eliminar `reconcile.py`;
- eliminar lógica específica de EAD;
- modificar `mapping.py`;
- modificar `reconciliation.py`;
- modificar `report.py`;
- agregar soporte Word;
- agregar soporte PDF;
- introducir RAG;
- introducir MCP;
- modificar archivos originales;
- convertir los outputs actuales en golden dataset;
- corregir manualmente los artefactos generados;
- mezclar la captura del baseline con una refactorización.

---

## 13. Estructura del baseline

La estructura esperada es:

```text
CASE_001_AS_IS/
├── README.md
├── inputs/
├── config/
│   └── execution_config.json
├── outputs/
└── evidence/
```

### Estado actual

```yaml
readme_created: true
config_snapshot_created: true
inputs_captured: partial
outputs_captured: true
human_evidence_created: true
equivalence_review_completed: true
pending_rules_review_completed: true
baseline_conclusions_created: true
baseline_frozen: false

outputs_manifest: outputs/AS_IS_OUTPUTS_MANIFEST.json
outputs_source: /dbfs/FileStore/comparador/output
outputs_capture_type: existing_outputs_snapshot
```

---

## 14. Próxima acción

La siguiente acción será identificar y registrar el archivo Excel exacto
utilizado en la ejecución de referencia.

Todavía no se deberá copiar ni ejecutar el comparador hasta registrar:

- nombre del Excel;
- ruta original;
- disponibilidad de copia local;
- fecha o versión conocida;
- hash, cuando sea posible.

---

## 15. Control documental

```yaml
document: CASE_001_AS_IS/README.md
status: PREPARING
allows_code_changes: false
config_snapshot: config/execution_config.json
next_action: Capturar identificación exacta del archivo Excel
next_gate: Baseline reproducible revisado por una persona
```
