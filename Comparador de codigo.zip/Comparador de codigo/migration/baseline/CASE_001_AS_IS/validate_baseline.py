from pathlib import Path
from datetime import datetime
import hashlib
import json
import sys


# Ejecutar este script desde cualquier ubicación.
case_root = Path(__file__).resolve().parent


required_files = [
    # Documentación principal
    "README.md",

    # Configuración
    "config/execution_config.json",

    # Inputs
    "inputs/python_project_manifest.json",

    # Outputs mínimos
    "outputs/AS_IS_OUTPUTS_MANIFEST.json",
    "outputs/07_correspondencia.md",
    "outputs/08_reconciliacion.md",
    "outputs/resultado_final.md",

    # Revisiones humanas
    "evidence/HUMAN_REVIEW.md",
    "evidence/EQUIVALENCE_REVIEW.md",
    "evidence/PENDING_RULES_REVIEW.md",
    "evidence/BASELINE_CONCLUSIONS.md",

    # Evidencia estructurada
    "evidence/PENDING_RULES_EVIDENCE.json",
    "evidence/XL_0001_offset_validation.json",
    "evidence/XL_0005_calibrated_xbeta.json",
    "evidence/XL_0006_calibrated_score.json",
    "evidence/XL_0008_final_pd36.json",
    "evidence/XL_0009_curve_adjustments.json",
    "evidence/XL_0010_0011_0012_combined.json",
]


def calculate_sha256(file_path: Path) -> str:
    sha256 = hashlib.sha256()

    with file_path.open("rb") as file:
        for block in iter(
            lambda: file.read(1024 * 1024),
            b"",
        ):
            sha256.update(block)

    return sha256.hexdigest()


validation_items = []
missing_files = []
valid_files = []


for relative_path in required_files:
    file_path = case_root / relative_path

    if not file_path.exists():
        status = "MISSING"

        missing_files.append(
            relative_path
        )

        validation_items.append(
            {
                "relative_path": relative_path,
                "status": status,
                "size_bytes": None,
                "sha256": None,
            }
        )

        continue

    if not file_path.is_file():
        status = "NOT_A_FILE"

        missing_files.append(
            relative_path
        )

        validation_items.append(
            {
                "relative_path": relative_path,
                "status": status,
                "size_bytes": None,
                "sha256": None,
            }
        )

        continue

    file_hash = calculate_sha256(
        file_path
    )

    valid_files.append(
        relative_path
    )

    validation_items.append(
        {
            "relative_path": relative_path,
            "status": "OK",
            "size_bytes": (
                file_path.stat().st_size
            ),
            "sha256": file_hash,
        }
    )


# Inventario adicional de todos los archivos del caso.
all_case_files = []

excluded_names = {
    "validate_baseline.py",
    "BASELINE_INTEGRITY_MANIFEST.json",
}


for file_path in sorted(
    case_root.rglob("*")
):
    if not file_path.is_file():
        continue

    if file_path.name in excluded_names:
        continue

    relative_path = (
        file_path
        .relative_to(case_root)
        .as_posix()
    )

    all_case_files.append(
        {
            "relative_path": relative_path,
            "size_bytes": (
                file_path.stat().st_size
            ),
            "sha256": calculate_sha256(
                file_path
            ),
        }
    )


validation_status = (
    "VALID_WITH_LIMITATIONS"
    if not missing_files
    else "INCOMPLETE"
)


manifest = {
    "case_id": "CASE_001_AS_IS",
    "manifest_type": (
        "BASELINE_INTEGRITY_MANIFEST"
    ),
    "generated_at": (
        datetime.now().astimezone().isoformat()
    ),
    "case_root": str(case_root),
    "baseline_status": (
        "REVIEWED_NOT_FROZEN"
    ),
    "validation_status": (
        validation_status
    ),
    "baseline_frozen": False,
    "required_file_count": len(
        required_files
    ),
    "valid_required_file_count": len(
        valid_files
    ),
    "missing_required_file_count": len(
        missing_files
    ),
    "missing_required_files": (
        missing_files
    ),
    "required_files": validation_items,
    "all_case_file_count": len(
        all_case_files
    ),
    "all_case_files": all_case_files,
    "known_limitations": [
        (
            "Los inputs fueron capturados "
            "parcialmente."
        ),
        (
            "El manifiesto del proyecto "
            "registró 23 objetos no legibles."
        ),
        (
            "No existe commit formal "
            "confirmado."
        ),
        (
            "No existe evidencia runtime "
            "de la ejecución capturada."
        ),
        (
            "No se ejecutó reconciliación "
            "numérica integral."
        ),
        (
            "El baseline fue revisado, "
            "pero no está congelado."
        ),
    ],
}


manifest_path = (
    case_root
    / "BASELINE_INTEGRITY_MANIFEST.json"
)


with manifest_path.open(
    "w",
    encoding="utf-8",
) as file:
    json.dump(
        manifest,
        file,
        ensure_ascii=False,
        indent=2,
    )


print("=" * 72)
print("VALIDACIÓN DE INTEGRIDAD DEL BASELINE")
print("=" * 72)

print(
    f"Caso: CASE_001_AS_IS"
)

print(
    f"Estado: {validation_status}"
)

print(
    "Archivos requeridos encontrados: "
    f"{len(valid_files)}/"
    f"{len(required_files)}"
)

print(
    "Archivos requeridos faltantes: "
    f"{len(missing_files)}"
)

if missing_files:
    print("\nArchivos faltantes:")

    for relative_path in missing_files:
        print(
            f"  - {relative_path}"
        )

else:
    print(
        "\nTodos los archivos mínimos "
        "del baseline fueron encontrados."
    )

print(
    "\nManifiesto generado:"
)

print(
    manifest_path
)


if missing_files:
    sys.exit(1)