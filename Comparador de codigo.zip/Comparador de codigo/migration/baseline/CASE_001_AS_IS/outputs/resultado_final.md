# Veredicto final

**NO DETERMINABLE: existen 9 reglas semánticas no verificables.**

## Resumen de correspondencias

- Reglas equivalentes: **3**
- Diferencias confirmadas: **0**
- Reglas pendientes de verificación: **9**
- Controles del Excel que no aplican al código: **0**
- Elementos encontrados solo en código: **11**
- Estado de reconciliación numérica: **NOT_RUN**

## Hallazgos críticos
- No se registraron diferencias confirmadas con evidencia.

## Reconciliación numérica

- Estado: **NOT_RUN**
- Modo: **AUTO**
- Periodos comparados: **0**
- Periodos coincidentes: **0**
- Periodos no coincidentes: **0**
- Curva coincidente: **False**
- Betas principales mapeadas: **False**
- Betas principales coincidentes: **False**
- Betas temporales coincidentes: **False**
- Rango de periodos completo: **False**
- Diferencia absoluta máxima: **None**
- Diferencia relativa máxima: **None**

Alcance: None.

### Descubrimiento del archivo de parámetros

- Estado: **NOT_RUN**
- Archivo identificado automáticamente: **No disponible**
- Confianza estructural: **No disponible**
- Cobertura de nombres: **No disponible**
- Cobertura de valores: **No disponible**
- Cobertura de nombres temporales: **No disponible**
- Cobertura de valores temporales: **No disponible**
- Variables no encontradas: **0**

### Reconstrucción de la fórmula

- Estado: **NOT_RUN**
- Periodos comparados: **0**
- Periodos coincidentes: **0**
- Periodos no coincidentes: **0**
- Curva coincidente: **False**
- Diferencia absoluta máxima: **No disponible**
- Diferencia relativa máxima: **No disponible**

### Función productiva

- Función: **No disponible**
- Ejecutada: **False**
- Estado: **NOT_RUN**
- Periodos comparados: **0**
- Periodos coincidentes: **0**
- Periodos no coincidentes: **0**
- Curva productiva coincidente: **False**
- Diferencia absoluta máxima: **No disponible**
- Diferencia relativa máxima: **No disponible**

Alcance productivo: No disponible

## Reglas equivalentes
- `XL-0002` · clv/params/pd_scalars.csv · La fórmula Excel =40/LN(2) calcula 40 dividido entre el logaritmo natural de 2, resultando en 57.70780163555854. Este valor se encuentra almacenado como parámetro 'factor' en el archivo de configuración pd_scalars.csv con valor 57.7078016355585 (diferencia de precisión decimal insignificante). El código Python en clv/source/engine/utils.py línea 269 recupera este parámetro: 'factor = param_scalar[param_scalar["param"] == "factor"]["value"].values[0]', y lo utiliza en cálculos de PD (línea 307: 'xBeta = - (score - offset) / factor'). La constante se materializa como parámetro configurado, no como cálculo inline, pero la equivalencia funcional es directa.
- `XL-0004` · clv/source/engine/utils.py, wtp_alpha_inf/source/engine/utils_wtp.py, wtp_capital_de_trabajo/source/engine/utils_wtp.py, wtp_af/source/engine/WTP_AF.py · La fórmula logística del Excel '=1/(1+EXP(-valor))' se implementa de forma equivalente en múltiples ubicaciones del código Python. Todas las instancias aplican la función logística: 1 dividido entre (1 más la exponencial negativa del valor de entrada). La estructura matemática es idéntica, aunque los nombres de variables y contextos de aplicación difieren (PD temporal, tasa de captación, efectividad). La función numpy.exp() es equivalente a EXP() de Excel.
- `XL-0007` · clv/source/engine/utils.py · La fórmula Excel aplica una función logística 1/(1+EXP(-(...))) con parámetros condicionales según H8 (<=19, <=25, >25). En Python, la función logística se calcula como pdTemporal = 1 / (1 + exp(valueT)) donde valueT = -1 * (alpha_t + beta_t * xBetaCalibrado). Los parámetros alpha_t y beta_t se seleccionan dinámicamente según el rango de plazo del producto (líneas 412-421), proporcionando la equivalencia funcional a los tres casos condicionales del Excel. Ambas implementaciones producen una curva de PD temporal mediante la función logística con parámetros dependientes del segmento.

## Reglas pendientes de verificación
- `XL-0001` · **NO_VERIFICABLE** · La regla Excel calcula: 400 - (valor_H7 * LN(50)). El código Python extrae un parámetro 'offset' precalculado (174.245752409011) y lo usa en una fórmula diferente (xBeta = -(score - offset) / factor). El valor 174.245752409011 podría ser el resultado cacheado de la fórmula Excel, pero no existe evidencia de que la operación 400-H7*LN(50) se ejecute en el código. El mapeo entre H7 y las variables de entrada no está documentado en la evidencia proporcionada.
- `XL-0003` · **NO_LOCALIZADO** · La fórmula XL-0003 calcula xβ = -(H11 - H6) / H7, una operación auxiliar específica que requiere tres referencias de celda con una estructura de resta y división negada. Aunque los números 6 y 7 aparecen en el código, no están asociados a esta lógica particular. Los archivos de utilidades y motores de cálculo no contienen una implementación que mapee explícitamente a esta fórmula auxiliar de la Calculadora.
- `XL-0005` · **NO_VERIFICABLE** · La regla Excel describe una transformación condicional con tres ramas según el valor en H8. El código Python muestra un cálculo lineal único de xBetaCalibrado sin condicionales por rangos. Aunque ambos involucran alpha, beta e interceptos, la estructura de decisión es fundamentalmente diferente. No se localizó en la evidencia una implementación que replique la lógica de IF anidados con los umbrales 19 y 25 aplicados a un valor de entrada equivalente a H8.
- `XL-0006` · **NO_VERIFICABLE** · La fórmula de Excel en H14 es una transformación lineal simple: negativo de H12 multiplicado por H7, más H6, redondeado. Las funciones Python encontradas (cal_score_rate, cal_score_rate_old) implementan cálculos de score calibrado por tasa, pero mediante modelos logísticos con constantes específicas (57.707801636, 174.24575241) y transformaciones exponenciales/logarítmicas. No existe mapeo documentado entre las variables de entrada (H6, H7, H12) y los parámetros utilizados en Python. Falta contexto sobre qué representan H6, H7, H12 en el modelo Python y si existe una transformación previa que conecte ambas representaciones.
- `XL-0008` · **NO_LOCALIZADO** · La fórmula =+R[-1]C[+0] es una operación auxiliar de copia de valores entre filas en Excel. En Python, esto típicamente se implementaría como df.loc[row, col] = df.loc[row-1, col] o mediante shift(). Los archivos revisados contienen lógica de negocio compleja (modelos de riesgo, optimización, transformaciones de características) pero no contienen una implementación explícita de esta copia horizontal de fila anterior. La ausencia de coincidencia no demuestra que la lógica no exista en todo el proyecto, solo que no fue localizada en la evidencia proporcionada.
- `XL-0009` · **NO_LOCALIZADO** · La regla XL-0009 describe una fórmula auxiliar que itera horizontalmente sumando valores previos más una constante. Aunque los archivos contienen operaciones de suma y manipulación de arrays (ej: curve[:,18:24], arange, concatenate), no se localizó una estructura que replique exactamente: (valor_columna_anterior + constante_J34) aplicada iterativamente en 60 celdas consecutivas. Los números 34 y 8 aparecen en contextos diferentes (índices de arrays, parámetros de modelos) sin asociación explícita a esta fórmula auxiliar.
- `XL-0010` · **NO_LOCALIZADO** · La fórmula XL-0010 es una operación auxiliar simple (=AP28-AP29) que calcula una diferencia entre dos celdas. Aunque los archivos Python contienen múltiples operaciones aritméticas (resta, multiplicación, división), ninguna corresponde específicamente a esta regla. La ausencia de coincidencia en los términos de búsqueda (ap28, ap29, ap30, calculadora) y la falta de una estructura que implemente esta lógica específica sugieren que esta fórmula no fue localizada en el código proporcionado.
- `XL-0011` · **NO_VERIFICABLE** · La regla XL-0011 es una fórmula auxiliar que multiplica dos celdas específicas (H34 * R27) en la hoja 'Calculadora'. Aunque el código contiene lógica relacionada con plazos (36 meses para product_code_final==1) y transformaciones de datos, no existe una correspondencia directa identificable entre la estructura de celdas de Excel y las operaciones en Python. Los números 36 y 7 aparecen en contextos diferentes (límites de plazo, índices de arrays) sin una conexión documentada a la multiplicación H34*R27.
- `XL-0012` · **NO_LOCALIZADO** · La fórmula XL-0012 es una fórmula auxiliar que calcula (I34-R27)/24. Aunque los archivos Python contienen operaciones matemáticas generales (división, resta), no existe una implementación que combine específicamente estas variables en este orden y contexto. La búsqueda por términos como 'calculadora', 'j34', 'i34', 'r27' no produjo coincidencias. Sin acceso al mapeo de celdas Excel a variables Python o al contexto completo del módulo de cálculo, no es posible localizar esta lógica.

## Controles del Excel
- No se registraron controles separados de la lógica productiva.

## Elementos solo en código
- Función pd_predict extrae parámetros 'offset' y 'factor' de un DataFrame de escalares y los utiliza en cálculos de probabilidad de default (xBeta = -(score - offset) / factor). Esta lógica no tiene una regla equivalente explícita en el Excel proporcionado.
- Archivo de configuración que almacena offset=174.245752409011 y factor=57.7078016355585. Estos valores se cargan dinámicamente en tiempo de ejecución, pero no se documenta cómo se derivan de la fórmula Excel original.
- Lectura del parámetro 'factor' desde DataFrame param_scalar. El valor se utiliza en múltiples funciones de cálculo de PD (pd_predict, pd_predict_new) para normalizar scores.
- Uso del factor en la fórmula: xBeta = - (score - offset) / factor. Aparece en dos funciones: pd_predict y pd_predict_new.
- Cálculo de xBetaCalibrado = alpha + beta * xBeta sin condicionales por rangos
- Ajustes particulares para Alpha y WKC Reactivo con condicionales por producto y rango de plazo
- Implementa cálculo de score calibrado por tasa mediante modelo logístico con parámetros fijos (57.707801636, 174.24575241, 0.0007784574353564032) y ajuste por TEA. No tiene equivalente directo en el Excel proporcionado.
- Línea 76: Calcula ScoreApplicantVendida usando round(-57.707801636 * log(X['MontoPD'] / (1 - X['MontoPD'])) + 174.24575241, 0). Estructura similar a cal_score_rate pero aplicada a datos de entrada.
- Ajustes particulares post-cálculo de PD temporal para productos específicos (Alpha, WKC Reactivo, FWL). Incluyen extrapolación de márgenes y ajustes condicionales por producto y score. No existe equivalente en el Excel XL-0007.
- Lógica de clipping y asignación de CantidadPlazo con límites específicos por product_code_final (36 para código 1, 144 para código 2, 60 para código 3, 72 para código 4, 24 para código 5). Esta lógica de validación de plazo no tiene equivalente explícito en la evidencia del Excel proporcionada.
- Función get_tt_dscto_parameters_transform que extrae desembolsos, calcula tasa mensual a partir de tasa anual (power(1 + X[MontoTasaEspecial], 1/12) - 1) y plazo. Aunque utiliza operaciones de potencia y división por 12, no corresponde a la multiplicación simple de H34*R27.

## Zonas no verificadas
- `Mapeo de variables Excel a Python` · No se proporciona documentación que conecte la celda H7 del Excel con las variables de entrada del código Python (score, offset, factor). Sin este mapeo, no es posible verificar si la lógica es funcionalmente equivalente.
- `Cálculo del parámetro offset` · El valor 174.245752409011 en pd_scalars.csv coincide con el valor cacheado en el Excel (174.245752409011), pero no se encontró código que ejecute la fórmula =400-H7*LN(50) para generar este valor. Es posible que sea un parámetro precalculado offline.
- `Contexto de H7 en la hoja Calculadora` · La fórmula Excel referencia H7, pero no se proporciona información sobre qué valor contiene H7 o cómo se relaciona con las variables del modelo Python.
- `Módulos de curvas (curves.py)` · No fue incluido en la evidencia. La fórmula auxiliar xβ podría estar implementada en módulos de curvas o transformaciones que no fueron proporcionados.
- `Archivos de parámetros y configuración` · No se proporcionaron archivos CSV o de configuración que pudieran contener constantes o mapeos relacionados con H6, H7 o H11.
- `Mapeo entre H8 (valor de entrada en Excel) y variables de entrada en Python` · No se proporcionó documentación que conecte el valor en H8 con variables del DataFrame X en Python. Sin este mapeo no se puede verificar si la condición <=19 o <=25 se implementa en algún lugar.
- `Ubicación de interceptos y pendientes (L9:M11 en Excel)` · Los archivos CSV contienen parámetros pero no se identifica explícitamente dónde se almacenan o cargan los valores de INTER. y PEND. para las tres calibraciones.
- `Equivalencia funcional de alpha/beta vs INTER./PEND.` · Aunque ambos son parámetros de calibración, no se confirma que alpha/beta en Python correspondan a INTER./PEND. en Excel o si representan transformaciones diferentes.
- `Mapeo de variables H6, H7, H12` · No se encontró documentación que vincule las celdas del Excel (H6, H7, H12) con variables o parámetros específicos en el código Python. Sin este mapeo, no es posible verificar si la lógica es equivalente.
- `Contexto de 'plazo' en la fórmula` · El header menciona 'Score Calibrado por plazo', pero la fórmula simple no contiene referencias explícitas a plazo. En Python, se encontraron ajustes por TEA y tasa, pero no está claro si 'plazo' es un parámetro implícito o si la fórmula de Excel es un caso especial.
- `Constantes y parámetros en Python` · Las funciones Python utilizan constantes hardcodeadas (57.707801636, 174.24575241, 0.0007784574353564032) sin documentación de origen. No se encontró archivo de parámetros que explique estos valores.
- `Mapeo de códigos de producto` · El Excel utiliza H8 como variable de decisión (<=19, <=25, >25) sin especificar su significado. En Python, se utilizan product_code_final y rango_plazo. No se proporcionó documentación que mapee explícitamente H8 a estas variables.
- `Parámetros alpha_t y beta_t` · Las líneas 418-421 en utils.py cargan alpha_t y beta_t desde param_Tt agrupados por product_code_final y rango_plazo. El archivo param_Tt no fue incluido en la evidencia. No se puede verificar que los valores numéricos coincidan con I21-I26 del Excel.
- `Factor de ajuste factor_pd` · Línea 416 aplica un factor_pd = 1.1358 bajo condiciones específicas (CantidadPlazo <= 13, segmento == 1, product == 5). El Excel no muestra este ajuste multiplicativo en XL-0007. No se puede determinar si es un post-procesamiento o si debe estar incluido en la comparación.
- `Operaciones de copia de filas en DataFrames` · No se proporcionaron archivos que contengan lógica de propagación de valores entre filas o transformaciones de datos tabulares simples. La búsqueda se enfocó en módulos de cálculo de riesgo y optimización, pero no en utilidades de manipulación de DataFrames básicas.
- `Módulos de utilidades de datos` · Aunque se revisaron archivos utils.py, no se incluyó el contenido completo de todas las funciones auxiliares. Funciones de copia o propagación de valores podrían estar en secciones no mostradas.
- `Archivos de configuración o preprocesamiento` · No se proporcionaron archivos de preprocesamiento de datos o configuración que típicamente contendrían operaciones de copia de filas o propagación de valores.
- `Lógica de iteración horizontal con suma acumulativa` · No se proporcionó el archivo que contiene la lógica de generación de la calculadora o la transformación de datos que implemente la fórmula S28:BZ28. Los archivos revisados son módulos de utilidad para cálculo de curvas de riesgo (PD, LGD, etc.) y validación estadística, pero no contienen la orquestación de la calculadora horizontal.
- `Referencia a celda J34 como constante` · No se identificó dónde se define o carga el valor de J34 en el código Python. Podría estar en un archivo de configuración, parámetros o constantes no incluido en la evidencia.
- `Estructura de datos de entrada` · No se especifica cómo se mapean las celdas S28:BZ28 del Excel a estructuras de datos en Python (arrays, DataFrames, etc.). Sin este mapeo, no es posible verificar equivalencia funcional.
- `Ubicación no indicada` · CONTENIDO_INCOMPLETO
- `Ubicación no indicada` · ALCANCE_LIMITADO
- `Mapeo entre celdas Excel (H34, R27) y variables Python` · No se proporcionó documentación que vincule las celdas específicas de Excel con columnas o variables del DataFrame de Python. H34 y R27 podrían corresponder a cualquier variable en el dataset, pero sin un catálogo de mapeo explícito, no es posible verificar la equivalencia.
- `Contexto de la hoja 'Calculadora'` · La hoja 'Calculadora' no fue incluida en la evidencia. Solo se proporcionó la fórmula canónica y un ejemplo con valores numéricos (0.358...). Sin acceso al archivo Excel completo o a un documento de especificación, no se puede validar el propósito y el contexto de esta fórmula auxiliar.
- `Parámetro R27 (Calculadora!R27)` · La referencia R27 sugiere una celda en la misma hoja. Sin acceso al contenido de R27, no se puede identificar qué valor o parámetro representa. Podría ser una constante, un parámetro de configuración o un resultado intermedio.
- `Mapeo de celdas Excel a variables Python` · No se proporcionó documentación que vincule las celdas I34, J34 y R27 del Excel con variables o columnas específicas en el código Python. Sin este mapeo, no es posible verificar si la lógica existe bajo nombres diferentes.
- `Módulo de cálculo principal` · Los archivos proporcionados son utilidades (utils.py, utils_wtp.py). El módulo principal que orquesta los cálculos de la 'Calculadora' no fue incluido en la evidencia. La fórmula podría estar en un archivo de orquestación o en un notebook no proporcionado.
- `Contexto de la hoja 'Calculadora'` · Se desconoce el propósito y el flujo de datos de la hoja 'Calculadora' en el Excel. Sin entender qué representa I34, R27 y J34 en el negocio, no es posible buscar equivalentes funcionales en el código.
- No se completó una reconciliación numérica coincidente.