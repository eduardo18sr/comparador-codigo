# Reglas canónicas del Excel

Las fórmulas se agrupan por firma estructural, normalizando desplazamientos verticales y horizontales.

## XL-0001 · Calculadora · Offset
- Tipo: **CALCULO_MODELO**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `H`
- Filas cubiertas: `6`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=400-{Calculadora!H7}R[+1]C[+0]*LN(50)`
- Firma estructural: `=400-R[+1]C[+0]*LN(50)`
- Traducción: En la celda H6 (Offset), se calcula restando de 400 el producto del valor en H7 multiplicado por el logaritmo natural de 50.
- Variantes contextuales: **1**

Ejemplos:
- `H6`: `=400-H7*LN(50)`

## XL-0002 · Calculadora · Factor
- Tipo: **CALCULO_MODELO**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `H`
- Filas cubiertas: `7`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=40/LN(2)`
- Firma estructural: `=40/LN(2)`
- Traducción: En la celda H7 (Factor), se calcula dividiendo 40 entre el logaritmo natural de 2.
- Variantes contextuales: **1**

Ejemplos:
- `H7`: `=40/LN(2)`

## XL-0003 · Calculadora · xβ
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `H`
- Filas cubiertas: `9`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=-({Calculadora!H11}R[+2]C[+0]-{Calculadora!H6}R_ABS[6]C_ABS[H])/{Calculadora!H7}R_ABS[7]C_ABS[H]`
- Firma estructural: `=-(R[+2]C[+0]-R_ABS[6]C_ABS[H])/R_ABS[7]C_ABS[H]`
- Traducción: En la celda H9 (xβ), se calcula como el negativo de la diferencia entre el valor en H11 y el valor absoluto en H6, dividido entre el valor absoluto en H7.
- Variantes contextuales: **1**

Ejemplos:
- `H9`: `=-(H11-$H$6)/$H$7`

## XL-0004 · Calculadora · PD WKC / PD Calibrada
- Tipo: **CALCULO_MODELO**
- Orientación: **VERTICAL**
- Columnas cubiertas: `H`
- Filas cubiertas: `10, 13`
- Celdas cubiertas: **2**
- Fórmula canónica contextual: `=1/(1+EXP(-{Calculadora!H9}R[-1]C[+0]))`
- Firma estructural: `=1/(1+EXP(-R[-1]C[+0]))`
- Traducción: En las celdas H10 a H13 (PD WKC / PD Calibrada), se aplica una función logística: 1 dividido entre (1 más la exponencial negativa del valor en la fila anterior de la misma columna).
- Variantes contextuales: **2**

Ejemplos:
- `H10`: `=1/(1+EXP(-H9))`
- `H13`: `=1/(1+EXP(-H12))`

## XL-0005 · Calculadora · xβ Calibrado
- Tipo: **TRANSFORMACION**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `H`
- Filas cubiertas: `12`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=IF({Calculadora!H8}R_ABS[8]C_ABS[H]<=19,{INTER.}R[-3]C[+4]+{PEND.}R[-3]C[+5]*{Calculadora!H9}R_ABS[9]C_ABS[H],
IF({Calculadora!H8}R_ABS[8]C_ABS[H]<=25, {INTER.}R[-2]C[+4]+{PEND.}R[-2]C[+5]*{Calculadora!H9}R_ABS[9]C_ABS[H],{INTER.}R[-1]C[+4]+{PEND.}R[-1]C[+5]*{Calculadora!H9}R[-3]C[+0]))`
- Firma estructural: `=IF(R_ABS[8]C_ABS[H]<=19,R[-3]C[+4]+R[-3]C[+5]*R_ABS[9]C_ABS[H],
IF(R_ABS[8]C_ABS[H]<=25,R[-2]C[+4]+R[-2]C[+5]*R_ABS[9]C_ABS[H],R[-1]C[+4]+R[-1]C[+5]*R[-3]C[+0]))`
- Traducción: En la celda H12 (xβ Calibrado), se aplica una transformación condicional según el valor en H8: si es menor o igual a 19, se usa la primera calibración; si es menor o igual a 25, se usa la segunda; en caso contrario, se usa la tercera. Cada calibración suma un intercepto más la pendiente multiplicada por el valor en H9.
- Variantes contextuales: **1**

Ejemplos:
- `H12`: `=IF($H$8<=19,L9+M9*$H$9,
IF($H$8<=25, L10+M10*$H$9,L11+M11*H9))`

## XL-0006 · Calculadora · Score Calibrado por plazo
- Tipo: **TRANSFORMACION**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `H`
- Filas cubiertas: `14`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=ROUND((-{Calculadora!H12}R[-2]C[+0]*{Calculadora!H7}R[-7]C[+0])+{Calculadora!H6}R[-8]C[+0],0)`
- Firma estructural: `=ROUND((-R[-2]C[+0]*R[-7]C[+0])+R[-8]C[+0],0)`
- Traducción: En la celda H14 (Score Calibrado por plazo), se calcula redondeando el resultado de: el negativo del valor en H12 multiplicado por el valor en H7, más el valor en H6.
- Variantes contextuales: **1**

Ejemplos:
- `H14`: `=ROUND((-H12*H7)+H6,0)`

## XL-0007 · Calculadora · PD TEMPORAL
- Tipo: **CALCULO_MODELO**
- Orientación: **HORIZONTAL**
- Columnas cubiertas: `I:BZ`
- Filas cubiertas: `27`
- Celdas cubiertas: **70**
- Fórmula canónica contextual: `=IF({Calculadora!H8}R_ABS[8]C_ABS[H]<=19,1/(1+EXP(-({Calculadora!I21}R[-6]C[+0]+{Calculadora!I22}R[-5]C[+0]*{Calculadora!H12}R_ABS[12]C_ABS[H]))),IF({Calculadora!H8}R_ABS[8]C_ABS[H]<=25,1/(1+EXP(-({Calculadora!I23}R[-4]C[+0]+{Calculadora!I24}R[-3]C[+0]*{Calculadora!H12}R_ABS[12]C_ABS[H]))),1/(1+EXP(-({Calculadora!I25}R[-2]C[+0]+{Calculadora!I26}R[-1]C[+0]*{Calculadora!H12}R_ABS[12]C_ABS[H])))))`
- Firma estructural: `=IF(R_ABS[8]C_ABS[H]<=19,1/(1+EXP(-(R[-6]C[+0]+R[-5]C[+0]*R_ABS[12]C_ABS[H]))),IF(R_ABS[8]C_ABS[H]<=25,1/(1+EXP(-(R[-4]C[+0]+R[-3]C[+0]*R_ABS[12]C_ABS[H]))),1/(1+EXP(-(R[-2]C[+0]+R[-1]C[+0]*R_ABS[12]C_ABS[H])))))`
- Traducción: En las celdas I27 a BZ27 (PD TEMPORAL), se aplica una función logística condicional según el valor en H8: si es menor o igual a 19, 25 o mayor, se utiliza la correspondiente pareja de parámetros (intercepto y pendiente) de las filas 21-22, 23-24 o 25-26 respectivamente, multiplicando la pendiente por el valor en H12.
- Variantes contextuales: **70**

Ejemplos:
- `I27`: `=IF($H$8<=19,1/(1+EXP(-(I21+I22*$H$12))),IF($H$8<=25,1/(1+EXP(-(I23+I24*$H$12))),1/(1+EXP(-(I25+I26*$H$12)))))`
- `J27`: `=IF($H$8<=19,1/(1+EXP(-(J21+J22*$H$12))),IF($H$8<=25,1/(1+EXP(-(J23+J24*$H$12))),1/(1+EXP(-(J25+J26*$H$12)))))`
- `K27`: `=IF($H$8<=19,1/(1+EXP(-(K21+K22*$H$12))),IF($H$8<=25,1/(1+EXP(-(K23+K24*$H$12))),1/(1+EXP(-(K25+K26*$H$12)))))`
- `L27`: `=IF($H$8<=19,1/(1+EXP(-(L21+L22*$H$12))),IF($H$8<=25,1/(1+EXP(-(L23+L24*$H$12))),1/(1+EXP(-(L25+L26*$H$12)))))`
- `M27`: `=IF($H$8<=19,1/(1+EXP(-(M21+M22*$H$12))),IF($H$8<=25,1/(1+EXP(-(M23+M24*$H$12))),1/(1+EXP(-(M25+M26*$H$12)))))`

## XL-0008 · Calculadora · PD TEMPORAL 36 Versión Final
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **HORIZONTAL**
- Columnas cubiertas: `I:R`
- Filas cubiertas: `28`
- Celdas cubiertas: **10**
- Fórmula canónica contextual: `=+{Calculadora!I27}R[-1]C[+0]`
- Firma estructural: `=+R[-1]C[+0]`
- Traducción: En las celdas I28 a R28 (PD TEMPORAL 36 Versión Final), se copia el valor de la fila anterior en la misma columna.
- Variantes contextuales: **10**

Ejemplos:
- `I28`: `=+I27`
- `J28`: `=+J27`
- `K28`: `=+K27`
- `L28`: `=+L27`
- `M28`: `=+M27`

## XL-0009 · Calculadora · Calculadora!S:BZ fila 28
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **HORIZONTAL**
- Columnas cubiertas: `S:BZ`
- Filas cubiertas: `28`
- Celdas cubiertas: **60**
- Fórmula canónica contextual: `=+{Calculadora!R28}R[+0]C[-1]+{Calculadora!J34}R_ABS[34]C_ABS[J]`
- Firma estructural: `=+R[+0]C[-1]+R_ABS[34]C_ABS[J]`
- Traducción: En las celdas S28 a BZ28, se calcula sumando el valor de la columna anterior en la misma fila más el valor constante en J34.
- Variantes contextuales: **60**

Ejemplos:
- `S28`: `=+R28+$J$34`
- `T28`: `=+S28+$J$34`
- `U28`: `=+T28+$J$34`
- `V28`: `=+U28+$J$34`
- `W28`: `=+V28+$J$34`

## XL-0010 · Calculadora · Calculadora!AP fila 30
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `AP`
- Filas cubiertas: `30`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=+{Calculadora!AP28}R[-2]C[+0]-{Calculadora!AP29}R[-1]C[+0]`
- Firma estructural: `=+R[-2]C[+0]-R[-1]C[+0]`
- Traducción: En la celda AP30, se calcula restando el valor en AP29 del valor en AP28.
- Variantes contextuales: **1**

Ejemplos:
- `AP30`: `=+AP28-AP29`

## XL-0011 · Calculadora · Para el plazo 36
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `I`
- Filas cubiertas: `34`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=+{PD TEMPORAL 36 Versión Final}R[+0]C[-1]*{Calculadora!R27}R[-7]C[+9]`
- Firma estructural: `=+R[+0]C[-1]*R[-7]C[+9]`
- Traducción: En la celda I34 (Para el plazo 36), se calcula multiplicando el valor en H34 por el valor en R27.
- Variantes contextuales: **1**

Ejemplos:
- `I34`: `=+H34*R27`

## XL-0012 · Calculadora · Calculadora!J fila 34
- Tipo: **FORMULA_AUXILIAR**
- Orientación: **CELDA_UNICA**
- Columnas cubiertas: `J`
- Filas cubiertas: `34`
- Celdas cubiertas: **1**
- Fórmula canónica contextual: `=+({Calculadora!I34}R[+0]C[-1]-{Calculadora!R27}R[-7]C[+8])/24`
- Firma estructural: `=+(R[+0]C[-1]-R[-7]C[+8])/24`
- Traducción: En la celda J34, se calcula dividiendo entre 24 la diferencia entre el valor en I34 y el valor en R27.
- Variantes contextuales: **1**

Ejemplos:
- `J34`: `=+(I34-R27)/24`
