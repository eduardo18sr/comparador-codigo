# Reconciliación numérica

- Estado: **NOT_RUN**
- Modo: **AUTO**
- Estrategia seleccionada: **Ninguna**
- Confianza de estrategia: **0.0**
- Comparaciones realizadas: **0**
- Coincidencias: **0**
- Diferencias: **0**
- Motivo: No se seleccionó una estrategia numérica. Estado del descubrimiento: NOT_SELECTED.