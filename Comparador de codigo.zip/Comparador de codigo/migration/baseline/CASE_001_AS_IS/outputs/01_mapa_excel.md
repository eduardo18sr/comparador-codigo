# Mapa del Excel

Archivo: `/dbfs/FileStore/comparador/input/calculadora_final.xlsx`

Hojas: **1**

## Calculadora
- Estado: `visible`
- Rango usado: `G5:BZ34`
- Celdas no vacías: **680**
- Celdas con fórmula: **150**
- Celdas constantes: **530**
- Fórmulas matriciales registradas: **0**
- Clasificación heurística: **zona probable de cálculo**
- Celdas combinadas: G23:G24, K5:M5, G21:G22, G25:G26, K7:M7
- Referencias frecuentes: `$H$12` (210), `$H$8` (142), `$J$34` (60), `R27` (3), `H7` (2), `H9` (2), `$H$9` (2), `H12` (2), `AP28` (2), `H11` (1), `$H$6` (1), `$H$7` (1)

Fórmulas completas:
```text
H6: =400-H7*LN(50)
H7: =40/LN(2)
H9: =-(H11-$H$6)/$H$7
H10: =1/(1+EXP(-H9))
H12: =IF($H$8<=19,L9+M9*$H$9,
IF($H$8<=25, L10+M10*$H$9,L11+M11*H9))
H13: =1/(1+EXP(-H12))
H14: =ROUND((-H12*H7)+H6,0)
I27: =IF($H$8<=19,1/(1+EXP(-(I21+I22*$H$12))),IF($H$8<=25,1/(1+EXP(-(I23+I24*$H$12))),1/(1+EXP(-(I25+I26*$H$12)))))
J27: =IF($H$8<=19,1/(1+EXP(-(J21+J22*$H$12))),IF($H$8<=25,1/(1+EXP(-(J23+J24*$H$12))),1/(1+EXP(-(J25+J26*$H$12)))))
K27: =IF($H$8<=19,1/(1+EXP(-(K21+K22*$H$12))),IF($H$8<=25,1/(1+EXP(-(K23+K24*$H$12))),1/(1+EXP(-(K25+K26*$H$12)))))
L27: =IF($H$8<=19,1/(1+EXP(-(L21+L22*$H$12))),IF($H$8<=25,1/(1+EXP(-(L23+L24*$H$12))),1/(1+EXP(-(L25+L26*$H$12)))))
M27: =IF($H$8<=19,1/(1+EXP(-(M21+M22*$H$12))),IF($H$8<=25,1/(1+EXP(-(M23+M24*$H$12))),1/(1+EXP(-(M25+M26*$H$12)))))
N27: =IF($H$8<=19,1/(1+EXP(-(N21+N22*$H$12))),IF($H$8<=25,1/(1+EXP(-(N23+N24*$H$12))),1/(1+EXP(-(N25+N26*$H$12)))))
O27: =IF($H$8<=19,1/(1+EXP(-(O21+O22*$H$12))),IF($H$8<=25,1/(1+EXP(-(O23+O24*$H$12))),1/(1+EXP(-(O25+O26*$H$12)))))
P27: =IF($H$8<=19,1/(1+EXP(-(P21+P22*$H$12))),IF($H$8<=25,1/(1+EXP(-(P23+P24*$H$12))),1/(1+EXP(-(P25+P26*$H$12)))))
Q27: =IF($H$8<=19,1/(1+EXP(-(Q21+Q22*$H$12))),IF($H$8<=25,1/(1+EXP(-(Q23+Q24*$H$12))),1/(1+EXP(-(Q25+Q26*$H$12)))))
R27: =IF($H$8<=19,1/(1+EXP(-(R21+R22*$H$12))),IF($H$8<=25,1/(1+EXP(-(R23+R24*$H$12))),1/(1+EXP(-(R25+R26*$H$12)))))
S27: =IF($H$8<=19,1/(1+EXP(-(S21+S22*$H$12))),IF($H$8<=25,1/(1+EXP(-(S23+S24*$H$12))),1/(1+EXP(-(S25+S26*$H$12)))))
T27: =IF($H$8<=19,1/(1+EXP(-(T21+T22*$H$12))),IF($H$8<=25,1/(1+EXP(-(T23+T24*$H$12))),1/(1+EXP(-(T25+T26*$H$12)))))
U27: =IF($H$8<=19,1/(1+EXP(-(U21+U22*$H$12))),IF($H$8<=25,1/(1+EXP(-(U23+U24*$H$12))),1/(1+EXP(-(U25+U26*$H$12)))))
V27: =IF($H$8<=19,1/(1+EXP(-(V21+V22*$H$12))),IF($H$8<=25,1/(1+EXP(-(V23+V24*$H$12))),1/(1+EXP(-(V25+V26*$H$12)))))
W27: =IF($H$8<=19,1/(1+EXP(-(W21+W22*$H$12))),IF($H$8<=25,1/(1+EXP(-(W23+W24*$H$12))),1/(1+EXP(-(W25+W26*$H$12)))))
X27: =IF($H$8<=19,1/(1+EXP(-(X21+X22*$H$12))),IF($H$8<=25,1/(1+EXP(-(X23+X24*$H$12))),1/(1+EXP(-(X25+X26*$H$12)))))
Y27: =IF($H$8<=19,1/(1+EXP(-(Y21+Y22*$H$12))),IF($H$8<=25,1/(1+EXP(-(Y23+Y24*$H$12))),1/(1+EXP(-(Y25+Y26*$H$12)))))
Z27: =IF($H$8<=19,1/(1+EXP(-(Z21+Z22*$H$12))),IF($H$8<=25,1/(1+EXP(-(Z23+Z24*$H$12))),1/(1+EXP(-(Z25+Z26*$H$12)))))
AA27: =IF($H$8<=19,1/(1+EXP(-(AA21+AA22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AA23+AA24*$H$12))),1/(1+EXP(-(AA25+AA26*$H$12)))))
AB27: =IF($H$8<=19,1/(1+EXP(-(AB21+AB22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AB23+AB24*$H$12))),1/(1+EXP(-(AB25+AB26*$H$12)))))
AC27: =IF($H$8<=19,1/(1+EXP(-(AC21+AC22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AC23+AC24*$H$12))),1/(1+EXP(-(AC25+AC26*$H$12)))))
AD27: =IF($H$8<=19,1/(1+EXP(-(AD21+AD22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AD23+AD24*$H$12))),1/(1+EXP(-(AD25+AD26*$H$12)))))
AE27: =IF($H$8<=19,1/(1+EXP(-(AE21+AE22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AE23+AE24*$H$12))),1/(1+EXP(-(AE25+AE26*$H$12)))))
AF27: =IF($H$8<=19,1/(1+EXP(-(AF21+AF22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AF23+AF24*$H$12))),1/(1+EXP(-(AF25+AF26*$H$12)))))
AG27: =IF($H$8<=19,1/(1+EXP(-(AG21+AG22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AG23+AG24*$H$12))),1/(1+EXP(-(AG25+AG26*$H$12)))))
AH27: =IF($H$8<=19,1/(1+EXP(-(AH21+AH22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AH23+AH24*$H$12))),1/(1+EXP(-(AH25+AH26*$H$12)))))
AI27: =IF($H$8<=19,1/(1+EXP(-(AI21+AI22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AI23+AI24*$H$12))),1/(1+EXP(-(AI25+AI26*$H$12)))))
AJ27: =IF($H$8<=19,1/(1+EXP(-(AJ21+AJ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AJ23+AJ24*$H$12))),1/(1+EXP(-(AJ25+AJ26*$H$12)))))
AK27: =IF($H$8<=19,1/(1+EXP(-(AK21+AK22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AK23+AK24*$H$12))),1/(1+EXP(-(AK25+AK26*$H$12)))))
AL27: =IF($H$8<=19,1/(1+EXP(-(AL21+AL22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AL23+AL24*$H$12))),1/(1+EXP(-(AL25+AL26*$H$12)))))
AM27: =IF($H$8<=19,1/(1+EXP(-(AM21+AM22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AM23+AM24*$H$12))),1/(1+EXP(-(AM25+AM26*$H$12)))))
AN27: =IF($H$8<=19,1/(1+EXP(-(AN21+AN22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AN23+AN24*$H$12))),1/(1+EXP(-(AN25+AN26*$H$12)))))
AO27: =IF($H$8<=19,1/(1+EXP(-(AO21+AO22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AO23+AO24*$H$12))),1/(1+EXP(-(AO25+AO26*$H$12)))))
AP27: =IF($H$8<=19,1/(1+EXP(-(AP21+AP22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AP23+AP24*$H$12))),1/(1+EXP(-(AP25+AP26*$H$12)))))
AQ27: =IF($H$8<=19,1/(1+EXP(-(AQ21+AQ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AQ23+AQ24*$H$12))),1/(1+EXP(-(AQ25+AQ26*$H$12)))))
AR27: =IF($H$8<=19,1/(1+EXP(-(AR21+AR22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AR23+AR24*$H$12))),1/(1+EXP(-(AR25+AR26*$H$12)))))
AS27: =IF($H$8<=19,1/(1+EXP(-(AS21+AS22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AS23+AS24*$H$12))),1/(1+EXP(-(AS25+AS26*$H$12)))))
AT27: =IF($H$8<=19,1/(1+EXP(-(AT21+AT22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AT23+AT24*$H$12))),1/(1+EXP(-(AT25+AT26*$H$12)))))
AU27: =IF($H$8<=19,1/(1+EXP(-(AU21+AU22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AU23+AU24*$H$12))),1/(1+EXP(-(AU25+AU26*$H$12)))))
AV27: =IF($H$8<=19,1/(1+EXP(-(AV21+AV22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AV23+AV24*$H$12))),1/(1+EXP(-(AV25+AV26*$H$12)))))
AW27: =IF($H$8<=19,1/(1+EXP(-(AW21+AW22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AW23+AW24*$H$12))),1/(1+EXP(-(AW25+AW26*$H$12)))))
AX27: =IF($H$8<=19,1/(1+EXP(-(AX21+AX22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AX23+AX24*$H$12))),1/(1+EXP(-(AX25+AX26*$H$12)))))
AY27: =IF($H$8<=19,1/(1+EXP(-(AY21+AY22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AY23+AY24*$H$12))),1/(1+EXP(-(AY25+AY26*$H$12)))))
AZ27: =IF($H$8<=19,1/(1+EXP(-(AZ21+AZ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(AZ23+AZ24*$H$12))),1/(1+EXP(-(AZ25+AZ26*$H$12)))))
BA27: =IF($H$8<=19,1/(1+EXP(-(BA21+BA22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BA23+BA24*$H$12))),1/(1+EXP(-(BA25+BA26*$H$12)))))
BB27: =IF($H$8<=19,1/(1+EXP(-(BB21+BB22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BB23+BB24*$H$12))),1/(1+EXP(-(BB25+BB26*$H$12)))))
BC27: =IF($H$8<=19,1/(1+EXP(-(BC21+BC22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BC23+BC24*$H$12))),1/(1+EXP(-(BC25+BC26*$H$12)))))
BD27: =IF($H$8<=19,1/(1+EXP(-(BD21+BD22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BD23+BD24*$H$12))),1/(1+EXP(-(BD25+BD26*$H$12)))))
BE27: =IF($H$8<=19,1/(1+EXP(-(BE21+BE22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BE23+BE24*$H$12))),1/(1+EXP(-(BE25+BE26*$H$12)))))
BF27: =IF($H$8<=19,1/(1+EXP(-(BF21+BF22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BF23+BF24*$H$12))),1/(1+EXP(-(BF25+BF26*$H$12)))))
BG27: =IF($H$8<=19,1/(1+EXP(-(BG21+BG22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BG23+BG24*$H$12))),1/(1+EXP(-(BG25+BG26*$H$12)))))
BH27: =IF($H$8<=19,1/(1+EXP(-(BH21+BH22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BH23+BH24*$H$12))),1/(1+EXP(-(BH25+BH26*$H$12)))))
BI27: =IF($H$8<=19,1/(1+EXP(-(BI21+BI22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BI23+BI24*$H$12))),1/(1+EXP(-(BI25+BI26*$H$12)))))
BJ27: =IF($H$8<=19,1/(1+EXP(-(BJ21+BJ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BJ23+BJ24*$H$12))),1/(1+EXP(-(BJ25+BJ26*$H$12)))))
BK27: =IF($H$8<=19,1/(1+EXP(-(BK21+BK22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BK23+BK24*$H$12))),1/(1+EXP(-(BK25+BK26*$H$12)))))
BL27: =IF($H$8<=19,1/(1+EXP(-(BL21+BL22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BL23+BL24*$H$12))),1/(1+EXP(-(BL25+BL26*$H$12)))))
BM27: =IF($H$8<=19,1/(1+EXP(-(BM21+BM22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BM23+BM24*$H$12))),1/(1+EXP(-(BM25+BM26*$H$12)))))
BN27: =IF($H$8<=19,1/(1+EXP(-(BN21+BN22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BN23+BN24*$H$12))),1/(1+EXP(-(BN25+BN26*$H$12)))))
BO27: =IF($H$8<=19,1/(1+EXP(-(BO21+BO22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BO23+BO24*$H$12))),1/(1+EXP(-(BO25+BO26*$H$12)))))
BP27: =IF($H$8<=19,1/(1+EXP(-(BP21+BP22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BP23+BP24*$H$12))),1/(1+EXP(-(BP25+BP26*$H$12)))))
BQ27: =IF($H$8<=19,1/(1+EXP(-(BQ21+BQ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BQ23+BQ24*$H$12))),1/(1+EXP(-(BQ25+BQ26*$H$12)))))
BR27: =IF($H$8<=19,1/(1+EXP(-(BR21+BR22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BR23+BR24*$H$12))),1/(1+EXP(-(BR25+BR26*$H$12)))))
BS27: =IF($H$8<=19,1/(1+EXP(-(BS21+BS22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BS23+BS24*$H$12))),1/(1+EXP(-(BS25+BS26*$H$12)))))
BT27: =IF($H$8<=19,1/(1+EXP(-(BT21+BT22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BT23+BT24*$H$12))),1/(1+EXP(-(BT25+BT26*$H$12)))))
BU27: =IF($H$8<=19,1/(1+EXP(-(BU21+BU22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BU23+BU24*$H$12))),1/(1+EXP(-(BU25+BU26*$H$12)))))
BV27: =IF($H$8<=19,1/(1+EXP(-(BV21+BV22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BV23+BV24*$H$12))),1/(1+EXP(-(BV25+BV26*$H$12)))))
BW27: =IF($H$8<=19,1/(1+EXP(-(BW21+BW22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BW23+BW24*$H$12))),1/(1+EXP(-(BW25+BW26*$H$12)))))
BX27: =IF($H$8<=19,1/(1+EXP(-(BX21+BX22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BX23+BX24*$H$12))),1/(1+EXP(-(BX25+BX26*$H$12)))))
BY27: =IF($H$8<=19,1/(1+EXP(-(BY21+BY22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BY23+BY24*$H$12))),1/(1+EXP(-(BY25+BY26*$H$12)))))
BZ27: =IF($H$8<=19,1/(1+EXP(-(BZ21+BZ22*$H$12))),IF($H$8<=25,1/(1+EXP(-(BZ23+BZ24*$H$12))),1/(1+EXP(-(BZ25+BZ26*$H$12)))))
I28: =+I27
J28: =+J27
K28: =+K27
L28: =+L27
M28: =+M27
N28: =+N27
O28: =+O27
P28: =+P27
Q28: =+Q27
R28: =+R27
S28: =+R28+$J$34
T28: =+S28+$J$34
U28: =+T28+$J$34
V28: =+U28+$J$34
W28: =+V28+$J$34
X28: =+W28+$J$34
Y28: =+X28+$J$34
Z28: =+Y28+$J$34
AA28: =+Z28+$J$34
AB28: =+AA28+$J$34
AC28: =+AB28+$J$34
AD28: =+AC28+$J$34
AE28: =+AD28+$J$34
AF28: =+AE28+$J$34
AG28: =+AF28+$J$34
AH28: =+AG28+$J$34
AI28: =+AH28+$J$34
AJ28: =+AI28+$J$34
AK28: =+AJ28+$J$34
AL28: =+AK28+$J$34
AM28: =+AL28+$J$34
AN28: =+AM28+$J$34
AO28: =+AN28+$J$34
AP28: =+AO28+$J$34
AQ28: =+AP28+$J$34
AR28: =+AQ28+$J$34
AS28: =+AR28+$J$34
AT28: =+AS28+$J$34
AU28: =+AT28+$J$34
AV28: =+AU28+$J$34
AW28: =+AV28+$J$34
AX28: =+AW28+$J$34
AY28: =+AX28+$J$34
AZ28: =+AY28+$J$34
BA28: =+AZ28+$J$34
BB28: =+BA28+$J$34
BC28: =+BB28+$J$34
BD28: =+BC28+$J$34
BE28: =+BD28+$J$34
BF28: =+BE28+$J$34
BG28: =+BF28+$J$34
BH28: =+BG28+$J$34
BI28: =+BH28+$J$34
BJ28: =+BI28+$J$34
BK28: =+BJ28+$J$34
BL28: =+BK28+$J$34
BM28: =+BL28+$J$34
BN28: =+BM28+$J$34
BO28: =+BN28+$J$34
BP28: =+BO28+$J$34
BQ28: =+BP28+$J$34
BR28: =+BQ28+$J$34
BS28: =+BR28+$J$34
BT28: =+BS28+$J$34
BU28: =+BT28+$J$34
BV28: =+BU28+$J$34
BW28: =+BV28+$J$34
BX28: =+BW28+$J$34
BY28: =+BX28+$J$34
BZ28: =+BY28+$J$34
AP30: =+AP28-AP29
I34: =+H34*R27
J34: =+(I34-R27)/24
```
## Nombres definidos
- `_AMO_UniqueIdentifier` → `"'bf9ec970-2179-4e48-bcd7-1d9999678c7a'"`

## Referencias externas
- `{'repr': "<openpyxl.workbook.external_link.external.ExternalLink object> Parameters: externalBook=<openpyxl.workbook.external_link.external.ExternalBook object> Parameters: id='rId1', sheetNames=<openpyxl.workbook.external_link.external.ExternalSheetNames object> Parameters: sheetName=['Calculadora Template', 'Calculadora', 'Sustento', 'Hoja1', 'Hoja2'], definedNames=[], sheetDataSet=<openpyxl.workbook.external_link.external.ExternalSheetDataSet object> Parameters: sheetData=[<openpyxl.workbook.externa...", 'file_link': 'file:///D:\\Datos%20de%20Usuarios\\T80554\\Downloads\\calculadora_original.xlsx'}`

## Advertencia
`data_only=True` no recalcula fórmulas. Solo recupera el último valor cacheado guardado por una aplicación de hoja de cálculo. Un valor cacheado vacío no implica que la fórmula devuelva vacío.
