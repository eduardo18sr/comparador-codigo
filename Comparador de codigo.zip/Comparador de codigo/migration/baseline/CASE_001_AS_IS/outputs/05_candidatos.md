# Candidatos de implementación

Se excluyen pruebas, mocks, cachés y entornos configurados. Las tres señales se calculan de forma independiente.

## clv/source/engine/utils.py
- Puntaje: **51**
- Léxica: 12 · Estructural: 14 · Aritmética: 25
- Motivos: términos/encabezados: coeficientes, factor, offset; literales exactos: factor, offset; firma aritmética: operadores=59, constantes=1
- Funciones: transf_gar, flg_zona1, flg_zona2, flg_zona4, get_product_code, get_codigo_prod, get_product_code_final, can_transform, can_predict_old, can_predict, pd_transform, pd_predict, pd_predict_new, pre_transform, pre_predict_old, pre_predict, lgd_transform, lgd_predict, rr1_transform, rr1_predict, rr2_transform, rr2_predict, cap_transform, cap_predict_old, cap_predict, costos_transform, inof_transform, tt_desc_transform, get_df_azul, limpiezaseguimiento, get_formato_clv, get_df_cen, get_df_afi, get_df_wtp_afi, get_alpha_formato_clv, get_alpha_formato_clv_3, reglas_de_negocio, reglas_de_negocio_afi, get_alpha_formato_clv_leads, get_df_top_afi, get_synth_update, get_redondeo, get_target_profitability, get_target_profitability_topafi, get_target_profitability_cen, get_target_profitability_product, get_target_profitability_campania, get_target_profitability_alpha, get_target_profitability_reactivo_ct_roas_vc, get_target_profitability_alpha_v2, get_df_cen_v2, get_target_profitability_cen_v2, get_target_profitability_cen_v3, cal_score_rate_old, cal_score_rate_old, cal_score_rate

## wtp_activo_fijo_inmueble/source/engine/utils_wtp.py
- Puntaje: **36**
- Léxica: 4 · Estructural: 7 · Aritmética: 25
- Motivos: términos/encabezados: factor; literales exactos: factor; firma aritmética: operadores=40, constantes=1
- Funciones: terciles_factor, key_patr, keep_vars_inciales, keep_vars_finales, imputing_init, capeo_init, logartimica, scale_init, preproc_perc, preprocessing_cluster, read_pickle, predict_clust, df_x_4, init_adj, imputing, capeo, scaling, log_conv, validacion, categoricas, complementarias, preprocessing_spread, predict_spread, get_tercil, cap_tea, reshape_df, calculo_probs, change_names, predict_tea

## clv/source/engine/CLV_Engine.py
- Puntaje: **29**
- Léxica: 4 · Estructural: 0 · Aritmética: 25
- Motivos: términos/encabezados: factor; firma aritmética: operadores=59, constantes=1
- Funciones: __init__, set_path_product_codes, set_path_can, set_path_pd, set_path_pre, set_path_lgd, set_path_rr1, set_path_rr2, set_path_ecap, set_path_costos, set_path_inof, set_path_tt_desc, __init__, transform, predict, get_parameters_pv, get_rmin, get_tea_irr_target, get_tea_roa_target, get_tea_roa_target_new, roa_actualization, get_irr, get_components, get_profitability_indicators, get_tasas_campana_azul_afi, get_profitability_datamart, getMinRate, getAggProfitability, getAllOutputs, get_wtp_afi_process, get_wtp_af_new_scenarios, get_wtp_cen_scenarios, get_wtp_alpha_scenarios, get_wtp_acen_new_scenarios_new, get_wtp_acen_new_scenarios, get_rates_with_tir_input, get_board_and_autonomy_interest_rates, get_irr_of_input_rate, funct, compute, funct, compute, funct, compute, funct, compute, funct, compute

## clv/source/engine/utils_clv.py
- Puntaje: **29**
- Léxica: 4 · Estructural: 0 · Aritmética: 25
- Motivos: términos/encabezados: factor; firma aritmética: operadores=57, constantes=1
- Funciones: get_delta_entidades, get_tipo_cliente, Bfactor2, Afactor1, Bf1, Bfactor1, shift, cif_to_cond_prob, compute_S, pbroyden, pbroyden_new, pbroyden_new_piecewise, get_tt_dscto_parameters_transform, get_tt_dscto_parameters_predict, get_pv_param, get_pd_param, pv_structure, roa_estimator, get_participacion_cosecha_en_calendario, get_components

## wtp_capital_de_trabajo_inf/source/engine/utils_wtp.py
- Puntaje: **29**
- Léxica: 4 · Estructural: 0 · Aritmética: 25
- Motivos: términos/encabezados: factor; firma aritmética: operadores=59, constantes=1
- Funciones: cat_missing_imp, num_missing_imp_old, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform_old, cluster_transform, cluster_predict_old, cluster_predict, dummy_transform, numeric_transform_old, numeric_transform, numeric_capping, numeric_standarization, woe_transform, get_woe, new_features, get_cluster, preprocessing_old, preprocessing, tkr_predict_old, tkr_predict, van_optimization, ajustar_probabilidad, van_optimization_new, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_capital_de_trabajo_new/source/engine/utils_wtp.py
- Puntaje: **29**
- Léxica: 4 · Estructural: 0 · Aritmética: 25
- Motivos: términos/encabezados: factor; firma aritmética: operadores=58, constantes=1
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, get_cluster, preprocessing, tkr_predict, van_optimization, ajustar_probabilidad, van_optimization_new, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_capital_de_trabajo_new_reactivo/source/engine/utils_wtp.py
- Puntaje: **29**
- Léxica: 4 · Estructural: 0 · Aritmética: 25
- Motivos: términos/encabezados: factor; firma aritmética: operadores=56, constantes=1
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, max_van_v2, cluster_transform, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, get_cluster, preprocessing, tkr_predict, van_optimization, van_optimization_v2, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## [ACEN_PILOTO] 1.get_tasas_cen_wtp_new_piloto_new_format_inferencia_inf.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=13, constantes=0
- Funciones: no extraídas

## [ACEN_PILOTO] 1.get_tasas_cen_wtp_new_piloto_new_format_inferencia_pdtasa.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=13, constantes=0
- Funciones: no extraídas

## [ACEN_PILOTO] 2.multiprocess_wtp_acen.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=21, constantes=0
- Funciones: opt_port, rutas_almacenamiento, create_sample, get_tasas_finales_opt

## [ALPHA] 4.get_tasas_alpha_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=13, constantes=0
- Funciones: no extraídas

## [ALPHA] 5.multiprocess_wtp_alpha_cluster_0.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=20, constantes=0
- Funciones: opt_port, rutas_almacenamiento, create_sample, get_tasas_finales_opt

## [ALPHA] 6.multiprocess_wtp_alpha_cluster_1_2_3.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=19, constantes=0
- Funciones: opt_port, rutas_almacenamiento, create_sample, get_tasas_finales_opt

## [ALPHA_PILOTO] 4.get_tasas_alpha_wtp_piloto.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=19, constantes=0
- Funciones: no extraídas

## [ALPHA_PILOTO] 4.get_tasas_alpha_wtp_piloto_inf.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=19, constantes=0
- Funciones: no extraídas

## [ALPHA_PILOTO] 5.multiprocess_wtp_alpha_cluster_0_piloto.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=20, constantes=0
- Funciones: opt_port, rutas_almacenamiento, create_sample, get_tasas_finales_opt

## [ALPHA_PILOTO] 6.multiprocess_wtp_alpha_cluster_1_2_3_piloto.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=19, constantes=0
- Funciones: opt_port, rutas_almacenamiento, create_sample, get_tasas_finales_opt

## [ALPHA_PILOTO] 8.get_tasas_alpha_wtp_pasiveros_piloto.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=15, constantes=0
- Funciones: no extraídas

## [SEGUIMIENTO] 1.new_format_tabla.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=16, constantes=0
- Funciones: no extraídas

## [SEGUIMIENTO] 5.get_all_outputs.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=16, constantes=0
- Funciones: no extraídas

## [TT] 1.get_update_tt_zdf.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=15, constantes=0
- Funciones: no extraídas

## [TT] 2.get_update_prepayment_curves_pyme.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=29, constantes=1
- Funciones: split_ofsaa_name, get_prepayment_curves

## wtp_af/source/engine/WTP_AF.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=15, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate

## wtp_af/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=18, constantes=1
- Funciones: num_missing_imp, numeric_transform, numeric_capping, dummy_transform, preprocessing, tkr_predict, max_van, van_optimization

## wtp_afi_reactivo/source/engine/WTP_AF.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=15, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate

## wtp_afi_reactivo/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=24, constantes=1
- Funciones: num_missing_imp, numeric_transform, numeric_capping, dummy_transform, preprocessing, tkr_predict, max_van, van_optimization

## wtp_alpha/source/engine/WTP_ALPHA.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=14, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## wtp_alpha/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=42, constantes=1
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, get_cluster, preprocessing, tkr_predict, van_optimization, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_alpha/source/engine/utils_wtp_databricks.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=42, constantes=1
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, get_cluster, preprocessing, tkr_predict, van_optimization, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_alpha_inf/source/engine/WTP_ALPHA.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=14, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## wtp_alpha_inf/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=56, constantes=1
- Funciones: cat_missing_imp, num_missing_imp_old, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform_old, cluster_transform, cluster_predict_old, cluster_predict, dummy_transform, numeric_transform_old, numeric_transform, numeric_capping, numeric_standarization, woe_transform, get_woe, get_cluster, preprocessing_old, preprocessing, tkr_predict, van_optimization, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_alpha_pasiveros/source/engine/WTP_ALPHA.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=14, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## wtp_alpha_pasiveros/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=49, constantes=0
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform, predict_kmeans, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, get_cluster, preprocessing, tkr_predict, ajustar_probabilidad, van_optimization, port_optimization, flg_outlier_f, piloto_control, val_randomization_alpha, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## wtp_capital_de_trabajo/source/engine/WTP_CEN.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=19, constantes=0
- Funciones: __init__, set_path_wtp, __init__, get_cluster, transform, get_takeup_rate, get_efectividad, get_porcentaje_oferta, get_final_rate, get_portfolio_optimization

## wtp_capital_de_trabajo/source/engine/utils_wtp.py
- Puntaje: **25**
- Léxica: 0 · Estructural: 0 · Aritmética: 25
- Motivos: firma aritmética: operadores=29, constantes=1
- Funciones: cat_missing_imp, num_missing_imp, df_to_records, read_pickle, max_van, cluster_transform, cluster_predict, dummy_transform, numeric_transform, numeric_capping, numeric_standarization, preprocessing, tkr_predict, van_optimization, port_optimization, randomization, psi_comb, plotear_hist, rand_validation, get_randomization

## [ALPHA] 2.get_profitability_alpha.py
- Puntaje: **24**
- Léxica: 4 · Estructural: 0 · Aritmética: 20
- Motivos: términos/encabezados: pd temporal; firma aritmética: operadores=10, constantes=0
- Funciones: no extraídas

## [ALPHA_PILOTO] 2.get_profitability_alpha_piloto.py
- Puntaje: **24**
- Léxica: 4 · Estructural: 0 · Aritmética: 20
- Motivos: términos/encabezados: pd temporal; firma aritmética: operadores=10, constantes=0
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/source/engine/WTP_ACEN_NEW.py
- Puntaje: **24**
- Léxica: 0 · Estructural: 0 · Aritmética: 24
- Motivos: firma aritmética: operadores=12, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## wtp_capital_de_trabajo_new/source/engine/WTP_ACEN_NEW.py
- Puntaje: **24**
- Léxica: 0 · Estructural: 0 · Aritmética: 24
- Motivos: firma aritmética: operadores=12, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## wtp_capital_de_trabajo_new_reactivo/source/engine/WTP_ACEN_NEW_REACTIVO.py
- Puntaje: **24**
- Léxica: 0 · Estructural: 0 · Aritmética: 24
- Motivos: firma aritmética: operadores=12, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_final_rate_v2, get_portfolio_optimization

## [ACEN_PILOTO] 4..get_formato_entrega_acen_adv_pre_rentabilidad_inf.py
- Puntaje: **20**
- Léxica: 0 · Estructural: 0 · Aritmética: 20
- Motivos: firma aritmética: operadores=10, constantes=0
- Funciones: no extraídas

## [ACEN_PILOTO] 4..get_formato_entrega_acen_adv_pre_rentabilidad_pdtasa.py
- Puntaje: **20**
- Léxica: 0 · Estructural: 0 · Aritmética: 20
- Motivos: firma aritmética: operadores=10, constantes=0
- Funciones: no extraídas

## [ALPHA] 3.pre_wtp_alpha_consolidado.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## [ALPHA] 7.pre_wtp_alpha_correc.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## [ALPHA] 8.get_tasas_alpha_wtp_pasiveros.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## [ALPHA_PILOTO] 7.pre_wtp_alpha_correc_piloto.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## [REACTIVO] 1.get_tasas_reactivo_wtp_new.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## [SEGUIMIENTO] 4.get_profitability_indicators.py
- Puntaje: **18**
- Léxica: 0 · Estructural: 0 · Aritmética: 18
- Motivos: firma aritmética: operadores=9, constantes=0
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/source/engine/WTP_AFI.py
- Puntaje: **18**
- Léxica: 4 · Estructural: 0 · Aritmética: 14
- Motivos: términos/encabezados: factor; firma aritmética: operadores=7, constantes=0
- Funciones: __init__, set_path_cluster, set_path_spread, __init__, transform_cluster, transform_spread, get_cluster, spread_predict, tea_predict

## [ACEN_PILOTO] 3.get_homogenizacion_acen.py
- Puntaje: **16**
- Léxica: 0 · Estructural: 0 · Aritmética: 16
- Motivos: firma aritmética: operadores=8, constantes=0
- Funciones: no extraídas

## [ACEN_PILOTO] 5.get_formato_entrega_acen_adv_post_rentabilidad_inf.py
- Puntaje: **14**
- Léxica: 0 · Estructural: 0 · Aritmética: 14
- Motivos: firma aritmética: operadores=7, constantes=0
- Funciones: no extraídas

## [ACEN_PILOTO] 5.get_formato_entrega_acen_adv_post_rentabilidad_pdtasa.py
- Puntaje: **14**
- Léxica: 0 · Estructural: 0 · Aritmética: 14
- Motivos: firma aritmética: operadores=7, constantes=0
- Funciones: no extraídas

## wtp_alpha/source/engine/WTP_ALPHA_databricks.py
- Puntaje: **14**
- Léxica: 0 · Estructural: 0 · Aritmética: 14
- Motivos: firma aritmética: operadores=7, constantes=0
- Funciones: __init__, set_path_wtp, __init__, transform, get_takeup_rate, get_efectividad, get_final_rate, get_portfolio_optimization

## [ALPHA] 1.get_base_alpha_formato_clv.py
- Puntaje: **12**
- Léxica: 0 · Estructural: 0 · Aritmética: 12
- Motivos: firma aritmética: operadores=6, constantes=0
- Funciones: no extraídas

## [ALPHA] 10.get_homogenizacion_alpha.py
- Puntaje: **12**
- Léxica: 0 · Estructural: 0 · Aritmética: 12
- Motivos: firma aritmética: operadores=6, constantes=0
- Funciones: no extraídas

## profiler.py
- Puntaje: **11**
- Léxica: 0 · Estructural: 0 · Aritmética: 11
- Motivos: firma aritmética: operadores=4, constantes=1
- Funciones: main

## [SEGUIMIENTO] 3.get_base_formato_clv.py
- Puntaje: **10**
- Léxica: 0 · Estructural: 0 · Aritmética: 10
- Motivos: firma aritmética: operadores=5, constantes=0
- Funciones: no extraídas

## clv/params/pd_scalars.csv
- Puntaje: **8**
- Léxica: 8 · Estructural: 0 · Aritmética: 0
- Motivos: términos/encabezados: factor, offset
- Funciones: no extraídas

## clv/params/ecap_scalars_optimizado_feb26.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_scalars_optimizado_jun25.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/param_lgd_wo.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_factor.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_factor_202511.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_factor_202601.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_factor_202602.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_factor.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_factor_202511.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_factor_202601.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_factor_202602.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_factores_garantia_por_tercil_pd_mto.csv
- Puntaje: **7**
- Léxica: 4 · Estructural: 0 · Aritmética: 3
- Motivos: términos/encabezados: factor; firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/source/engine/curves_all.py
- Puntaje: **4**
- Léxica: 4 · Estructural: 0 · Aritmética: 0
- Motivos: términos/encabezados: factor
- Funciones: __init__, transform, predict, __init__, transform, predict, __init__, transform, predict, __init__, transform, predict, __init__, transform, predict, __init__, transform, predict, __init__, transform, predict, __init__, transform, __init__, transform, __init__, transform

## clv/params/can_thetaTt.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_1_1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_202507.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_36.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_36_swat_final_final_final.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_36_swat_final_final_final_1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/can_thetaTt_old.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202508.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202509.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202509_con_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202509_no_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202511_con_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202601.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202601_alpha_fake.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202601_alpha_fake_25.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_202605.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_consolidado_campania.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_ene25.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_may23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_may23_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_oct23_2_last_apertura_con_consultoria.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_oct23_2_last_apertura_no_consultoria.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_oct23_2_last_apertura_no_consultoria_no_afi.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_lifetime_set22.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202508.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202509.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202509_con_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202509_con_alpha_fake.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202509_no_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202511_con_alpha.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202601.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202601_alpha_fake.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202601_alpha_fake_25.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_202605.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_consolidado_campania.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_ene25.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_may23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_may23_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_nulo.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_oct23_2_last_apertura_con_consultoria.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_oct23_2_last_apertura_no_consultoria.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_oct23_2_last_apertura_no_consultoria_no_afi.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_oct23_2_last_apertura_no_consultoria_no_afi_fake.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/costos_t_0_set22.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_adelanto_ventas.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_AF_202510.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_AF_202510_2.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202404.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202406.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202406_prueba.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202508.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202602_POST_ACTUALIZACION.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202602_POST_ACTUALIZACION_CAL.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202602_PRE_ACTUALIZACION.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202602_PRE_ACTUALIZACION_piloto.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_202602_PRE_ACTUALIZACION_piloto_parametros.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_20260424.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_20260424_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_20260424_update_2.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_20260424_update_3.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasa_descuento_reactivo_FICO_20260603_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/descuentos_tasadescuento_reactivo.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_pd_ttc.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_pd_ttc_actualizado_abr24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_pd_ttc_actualizado_nov22.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_pd_ttc_actualizado_nov22_abril2024.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_pd_ttc_feb25.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_scalars_optimizado_mar24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_scalars_optimizado_oct23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ecap_scalars_optimizado_set24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_alpha_202209.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_alpha_202303.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_alpha_202304.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_alpha_202304_ROA.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202206.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202206_60.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202209_modelos.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202212_advisory.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202303.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historico_tarifarios/descuentos_tasadescuento_cen_202304.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202302.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202303.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202304.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202305.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202306.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202307.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202308.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202309.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_curva_zdf_202310.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202302.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202303.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202304.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202305.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202306.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202307.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202308.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202309.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/historicos_tt_prepagos/tt_prepagos_rdm_202310.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios_set23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios_set23_ajust.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios_set23_ajust_FICO.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios_set23_ajust_no_desgravamen.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/ingresos_x_servicios_set23_no_portes.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_for_ecap_map.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_for_ecap_map_set23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_202406.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_final.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_final_202406.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_final_abr24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_final_set23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/lgd_thetaT_set23.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/param_localidad_zona.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_rango_Tt.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_rango_Tt_202605.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_rango_Tt_sep24_v2.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaT.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaT_actualizado_202605.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaT_actualizado_nov22.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaT_actualizado_sep24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaT_actualizado_sep24_v2.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt_actualizado_202605.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt_actualizado_nov22.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt_actualizado_sep24.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt_actualizado_sep24_v2.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pd_thetaTt_wkc.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_202507.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_old.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_swat_final_final_final.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_swat_final_final_final_new_format.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_swat_final_final_final_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/pre_thetaTt_swat_final_final_final_update_factor_1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_coef.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_coef_202511.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_coef_202601.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll1_coef_202602.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_coef.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_coef_202511.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_coef_202601.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_coef_202602.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/roll2_coef_plazo36.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tarifario_reactivo_api_af_ct.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_202404.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_202406.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_202407.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20241228.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250128.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250228.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250328.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_202504.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250428.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250528.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250628.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250728.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250828.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20250928.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20251028.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20251128.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20251228.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20260128.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20260328.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20260428.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_20260528.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_curva_zdf_prueba.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_202404.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_20250407.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_202601_NEW.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_202601_OLD.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_noviembre_mary.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_octubre_mary.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_prueba.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_prepagos_rdm_setiembre_mary.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_zdf_20231201.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_zdf_mary_202312.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## clv/params/tt_zdf_mary_202402.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## requirements.txt
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/cluster_limits_tea_probas.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/cluster_regression_betas.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_betas_predict_spread.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_calculo_probs.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_cuartiles_pd_mto_venta.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_delta_tt_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_percentiles.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_preproc_patrimonio_imputing_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_preproc_ventas_imputing_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_spread_computation_capping_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_spread_computation_imputing_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_spread_computation_scaling_values.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_terciles_mto.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_terciles_pd.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/param_terciles_pd_mto.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_activo_fijo_inmueble/params/terciles_cluster_pd_mto.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha/data/params/dem_betas_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha/data/params/num_capping_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha/data/params/num_imputing_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha/data/params/num_standarization_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha_inf/data/params/dem_betas_alpha_update_old.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha_inf/data/params/num_capping_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha_inf/data/params/num_imputing_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_alpha_inf/data/params/num_standarization_alpha_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/inputs/df_cluster1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/params/dem_betas.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/params/dem_betas_simulados.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/params/num_capping.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/params/num_imputing.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo/data/params/num_standarization.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/inputs/df_cluster1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/params/dem_betas_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/params/num_capping_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/params/num_standarization_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/params/wtp_acen_params.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_inf/data/params/wtp_acen_woe_bins.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new/data/inputs/df_cluster1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new/data/params/dem_betas_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new/data/params/num_capping_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new/data/params/num_standarization_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new_reactivo/data/inputs/df_cluster1.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new_reactivo/data/params/dem_betas_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new_reactivo/data/params/dem_betas_wkc_new_update.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new_reactivo/data/params/num_capping_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas

## wtp_capital_de_trabajo_new_reactivo/data/params/num_standarization_wkc_new.csv
- Puntaje: **3**
- Léxica: 0 · Estructural: 0 · Aritmética: 3
- Motivos: firma aritmética: operadores=0, constantes=1
- Funciones: no extraídas
