# AS_IS_GAP_ANALYSIS.md

## 0. Propósito y alcance

Este documento concilia el árbol real del repositorio con los artefactos de transferencia disponibles. El análisis confirma únicamente existencia y ubicación de archivos. No confirma comportamiento interno, calidad, dependencias efectivas ni soporte funcional hasta inspeccionar el contenido.

Fuentes analizadas:

- `ACTUAL_REPOSITORY_TREE.txt`
- `HANDOFF_AS_IS.md`
- `HANDOFF_AS_IS_REVIEWED.md`
- `CURRENT_REPOSITORY_TREE.txt`
- `CURRENT_REQUIREMENTS.md`
- `CURRENT_KNOWN_ISSUES.md`
- `CURRENT_TEST_CASES.md`
- `CURRENT_DEPENDENCIES.txt`
- `CURRENT_DECISIONS.md`

---

## 1. Resumen ejecutivo

- **Contradicciones explícitas identificadas:** 0.
- **Archivos presentes en el árbol real:** 28.
- **Archivos de código Python presentes:** 23, contando `tests/test_canonical.py`.
- **Archivos pendientes de inspección de contenido:** 28.
- **Elementos mencionados por el handoff y ausentes del árbol real:** 0 archivos fuente confirmados.
- **Conclusión:** el handoff acertó en los archivos que declaró como observados, pero omitió una parte importante del repositorio. El árbol real confirma una base más amplia con módulos de inventario, fórmulas, LLM, mapping, exploración del proyecto, call graph, reportes, configuración, empaquetado y una prueba existente.

No se detectó una contradicción porque `CURRENT_REPOSITORY_TREE.txt` ya declaraba expresamente que el árbol era parcial. Lo encontrado es una **brecha de cobertura documental**, no una inconsistencia factual.

---

## 2. Archivos y directorios confirmados por árbol real y handoff

Los siguientes elementos aparecen en el árbol real y también fueron mencionados explícitamente en el handoff:

### Punto de entrada y reconciliación

- `excel_code_compare/cli.py`
- `excel_code_compare/reconciliation.py`
- `excel_code_compare/strategy_discovery.py`

### Estrategias

- `excel_code_compare/strategies/__init__.py`
- `excel_code_compare/strategies/base.py`
- `excel_code_compare/strategies/parameter_table.py`
- `excel_code_compare/strategies/production_function.py`
- `excel_code_compare/strategies/scalar_formula.py`
- `excel_code_compare/strategies/tabular_formula.py`
- `excel_code_compare/strategies/temporal_curve.py`

### Adaptadores

- `excel_code_compare/adapters/__init__.py`
- `excel_code_compare/adapters/ead_curve.py`

### Directorios

- `excel_code_compare/`
- `excel_code_compare/strategies/`
- `excel_code_compare/adapters/`

**Alcance de la confirmación:** se confirma que existen en esas ubicaciones. No se confirma su contenido ni que implementen exactamente las responsabilidades atribuidas por el handoff.

---

## 3. Archivos encontrados únicamente en el árbol real

Estos archivos existen en el repositorio real, pero no fueron inventariados individualmente en la sección de archivos confirmados del handoff. Su propósito queda como **PENDIENTE DE INSPECCIÓN**.

### Módulos del paquete

- `excel_code_compare/__init__.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/callgraph.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/excel_inventory.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/formulas.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/llm.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/mapping.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/project_scan.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/reconcile.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/report.py` — PENDIENTE DE INSPECCIÓN.
- `excel_code_compare/utils.py` — PENDIENTE DE INSPECCIÓN.

### Ejecución y pruebas

- `notebooks/00_ejecutar_en_databricks` — PENDIENTE DE INSPECCIÓN.
- `tests/test_canonical.py` — PENDIENTE DE INSPECCIÓN.

### Configuración, empaquetado y documentación

- `config.example.yaml` — PENDIENTE DE INSPECCIÓN.
- `pyproject.toml` — PENDIENTE DE INSPECCIÓN.
- `README.md` — PENDIENTE DE INSPECCIÓN.
- `requirements.txt` — PENDIENTE DE INSPECCIÓN.

### Hallazgo relevante, sin inferir comportamiento

Existen simultáneamente:

- `excel_code_compare/reconcile.py`
- `excel_code_compare/reconciliation.py`

El árbol no permite determinar si son complementarios, alternativos, legado o duplicación. La relación debe verificarse leyendo ambos archivos y sus consumidores.

---

## 4. Elementos mencionados únicamente en el handoff

### Archivos fuente

No se identificó ningún archivo fuente explícitamente confirmado por el handoff que esté ausente del árbol real.

### Artefactos de ejecución

- `strategy_discovery.json`: confirmado en el historial como salida, pero no aparece en el árbol del repositorio. Esto no demuestra ausencia, porque puede generarse fuera de la raíz o durante una ejecución.
- `reconciliation.json`: ya estaba clasificado como **NO CONFIRMADO** y no aparece en el árbol real. Mantener como **NO CONFIRMADO**.
- Reportes Markdown generados: se confirman como salidas históricas, pero el árbol no muestra archivos de salida. La ubicación permanece **NO CONFIRMADA**.
- Configuraciones CSV relacionadas: mencionadas en el handoff, pero no aparecen en el árbol. Clasificación: **NO CONFIRMADO**.

### Capacidades

- Word como fuente principal: **NO CONFIRMADO**.
- PDF como fuente principal: **NO CONFIRMADO**.

La existencia de `report.py`, `llm.py` u otros módulos no prueba soporte Word/PDF.

---

## 5. Contradicciones

### Contradicciones explícitas

**No se identificaron contradicciones explícitas.**

### Brechas de cobertura, no contradicciones

1. `CURRENT_REPOSITORY_TREE.txt` listaba una estructura parcial. El árbol real agrega módulos, notebook, prueba, configuración, empaquetado y documentación.
2. `CURRENT_DEPENDENCIES.txt` solo confirmaba Python, Databricks y openpyxl, mientras el árbol real demuestra que existen `requirements.txt` y `pyproject.toml`. Esto no confirma dependencias adicionales, pero revela que el inventario de dependencias puede completarse inspeccionando esos archivos.
3. El handoff decía que Inventory/Mapping habían sido mencionados. El árbol confirma archivos llamados `excel_inventory.py` y `mapping.py`, pero no confirma sus responsabilidades.
4. El handoff reportó problemas en imports/exports de `__init__.py`. El árbol confirma la existencia de tres archivos `__init__.py`, pero no confirma el defecto hasta leer contenido o reproducir el error.
5. El handoff reportó `NOT_SELECTED` y `NOT_RUN`. El árbol confirma módulos potencialmente relacionados, pero no confirma causas ni comportamiento.

---

## 6. Vacíos que requieren inspección de código

Todos los archivos siguen pendientes de lectura, pero el orden debe priorizar las preguntas abiertas del handoff.

### 6.1 Punto de entrada y flujo real

- `README.md`
- `notebooks/00_ejecutar_en_databricks`
- `excel_code_compare/cli.py`
- `excel_code_compare/__init__.py`

Confirmar:

- comando o notebook de ejecución;
- argumentos y rutas de entrada;
- orden real del pipeline;
- artefactos de salida;
- configuración consumida.

### 6.2 Imports, exports y registro

- `excel_code_compare/__init__.py`
- `excel_code_compare/strategies/__init__.py`
- `excel_code_compare/adapters/__init__.py`
- `excel_code_compare/strategies/base.py`

Confirmar:

- exports reales;
- imports circulares o faltantes;
- definiciones de `StrategyContext` y `StrategyDetection`;
- forma de registrar estrategias y adaptadores.

### 6.3 Descubrimiento y selección de estrategia

- `excel_code_compare/strategy_discovery.py`
- los cinco módulos concretos bajo `strategies/`;
- `config.example.yaml`.

Confirmar:

- origen de `allowed_strategies`;
- uso de `minimum_confidence = 0.80`;
- uso de `ambiguity_margin = 0.03`;
- por qué el caso PYME produce `candidates=[]` y `NOT_SELECTED`;
- si la detección depende de configuración o heurísticas rígidas.

### 6.4 Inventario, extracción y representación

- `excel_code_compare/excel_inventory.py`
- `excel_code_compare/formulas.py`
- `excel_code_compare/project_scan.py`
- `excel_code_compare/callgraph.py`
- `excel_code_compare/mapping.py`
- `excel_code_compare/utils.py`
- `tests/test_canonical.py`.

Confirmar:

- qué representación intermedia existe realmente;
- qué significa “canonical” en la prueba;
- cómo se extraen fórmulas y símbolos Python;
- cómo se construyen mappings;
- qué comportamiento es determinístico;
- presencia de hardcoding específico del caso PYME.

### 6.5 Reconciliación

- `excel_code_compare/reconcile.py`
- `excel_code_compare/reconciliation.py`
- `excel_code_compare/adapters/ead_curve.py`
- módulos de `strategies/`.

Confirmar:

- diferencia entre `reconcile.py` y `reconciliation.py`;
- cuál es consumido por el flujo principal;
- condiciones que producen `NOT_RUN`;
- contrato de entrada y salida;
- acoplamiento a EAD, PD temporal, offset o factor.

### 6.6 LLM y comportamiento probabilístico

- `excel_code_compare/llm.py`
- consumidores encontrados mediante imports.

Confirmar:

- qué decisiones delega al LLM;
- endpoint o abstracción utilizada;
- estructura de prompts;
- formatos de salida;
- manejo de errores;
- trazabilidad;
- configuración y secretos, sin exponer valores sensibles.

### 6.7 Reporte y evidencia

- `excel_code_compare/report.py`
- `excel_code_compare/cli.py`
- módulos de reconciliación.

Confirmar:

- ubicación de reportes;
- esquema de resultados;
- correspondencia entre hallazgos y evidencia;
- si mezcla contenido específico de EAD con modo AUTO;
- existencia efectiva de `strategy_discovery.json` y `reconciliation.json`.

### 6.8 Dependencias y entorno

- `requirements.txt`
- `pyproject.toml`
- `config.example.yaml`
- notebook de Databricks.

Confirmar:

- dependencias reales y versiones;
- versión de Python;
- estructura instalable del paquete;
- variables de entorno requeridas;
- supuestos de Databricks;
- comandos reproducibles.

---

## 7. Orden de inspección recomendado

El orden parte de ejecución y configuración, sigue imports y modelos base, y después recorre extracción, selección, reconciliación y reporte.

1. `README.md`
2. `pyproject.toml`
3. `requirements.txt`
4. `config.example.yaml`
5. `notebooks/00_ejecutar_en_databricks`
6. `excel_code_compare/cli.py`
7. `excel_code_compare/__init__.py`
8. `excel_code_compare/strategies/__init__.py`
9. `excel_code_compare/adapters/__init__.py`
10. `excel_code_compare/strategies/base.py`
11. `excel_code_compare/excel_inventory.py`
12. `excel_code_compare/formulas.py`
13. `excel_code_compare/project_scan.py`
14. `excel_code_compare/callgraph.py`
15. `excel_code_compare/mapping.py`
16. `excel_code_compare/llm.py`
17. `excel_code_compare/strategy_discovery.py`
18. `excel_code_compare/strategies/parameter_table.py`
19. `excel_code_compare/strategies/scalar_formula.py`
20. `excel_code_compare/strategies/tabular_formula.py`
21. `excel_code_compare/strategies/temporal_curve.py`
22. `excel_code_compare/strategies/production_function.py`
23. `excel_code_compare/adapters/ead_curve.py`
24. `excel_code_compare/reconcile.py`
25. `excel_code_compare/reconciliation.py`
26. `excel_code_compare/report.py`
27. `excel_code_compare/utils.py`
28. `tests/test_canonical.py`

Este orden es una recomendación de inspección, no una afirmación sobre las dependencias reales.

---

## 8. Cobertura del handoff

| Sección del handoff | Estado frente al árbol | Motivo |
|---|---|---|
| 1. Objetivo actual | NO CONFIRMADA POR EL ÁRBOL | Un árbol no confirma comportamiento. |
| 2. Estado actual | PARCIALMENTE CONFIRMADA | Confirma existencia de módulos, no estado funcional. |
| 3. Inventario de archivos | PARCIALMENTE CONFIRMADA | Los archivos listados existen, pero faltaban 16 archivos del árbol real. |
| 4. Flujo end-to-end | NO CONFIRMADA POR EL ÁRBOL | Requiere leer punto de entrada y llamadas. |
| 5. Arquitectura real | PARCIALMENTE CONFIRMADA | Confirma componentes nominales, no relaciones. |
| 6. Reglas de negocio | NO CONFIRMADA POR EL ÁRBOL | Requiere contenido y evidencias. |
| 7. Heurísticas y hardcoding | NO CONFIRMADA POR EL ÁRBOL | Requiere leer configuración y código. |
| 8. Modelo de datos | NO CONFIRMADA POR EL ÁRBOL | Requiere inspeccionar `base.py` y consumidores. |
| 9. Dependencias | PARCIALMENTE CONFIRMADA | Existen manifiestos, contenido aún no inspeccionado. |
| 10. Pruebas realizadas | PARCIALMENTE CONFIRMADA | Existe una prueba, pero su contenido y resultados no están verificados. |
| 11. Resultados validados manualmente | NO CONFIRMADA POR EL ÁRBOL | El árbol no contiene evidencia suficiente. |
| 12. Deuda técnica | PARCIALMENTE CONFIRMADA | La estructura relacionada existe; los defectos requieren reproducción. |
| 13. Decisiones tomadas | NO CONFIRMADA POR EL ÁRBOL | Proviene del historial, no de la estructura. |
| 14. Árbol del repositorio | CONTRADICCIÓN: NO | Era explícitamente parcial; queda sustituido como evidencia por el árbol real. |
| 15. Comandos de ejecución | PARCIALMENTE CONFIRMADA | Existe notebook y README, contenido pendiente. |
| 16. Archivos a conservar | PARCIALMENTE CONFIRMADA | El paquete existe; las salidas y CSV no aparecen en el árbol. |
| 17. Preguntas abiertas | CONFIRMADA COMO PENDIENTE | El árbol resuelve la estructura, no los demás vacíos. |

---

## 9. Alcance actualizado del baseline AS-IS

### Confirmado estructuralmente

- Existe un paquete `excel_code_compare`.
- Existen cinco estrategias concretas y una base común.
- Existe un adaptador `ead_curve.py`.
- Existen módulos separados para CLI, inventario Excel, fórmulas, LLM, mapping, exploración de proyecto, call graph, descubrimiento de estrategia, reconciliación y reporte.
- Existen dos módulos con nombres relacionados a reconciliación.
- Existe una prueba llamada `test_canonical.py`.
- Existen manifiestos de configuración y dependencias.
- Existe un notebook de ejecución en Databricks.

### Aún no confirmado

- Que el paquete se ejecute sin errores.
- Que las cinco estrategias estén correctamente registradas.
- Que el soporte Word/PDF exista.
- Que haya una representación canónica completa.
- Que la selección AUTO funcione.
- Que la reconciliación genérica funcione.
- Que `reconciliation.json` exista.
- Que las dependencias declaradas sean completas.
- Que las salidas estén trazadas a evidencia.
- Que el código esté desacoplado del caso PYME/EAD.

---

## 10. Decisión del análisis

El árbol real permite cerrar la pregunta “qué archivos existen”, pero todavía no permite construir una Specification fiable ni una arquitectura objetivo. El siguiente paso metodológico debe ser una **inspección de contenido AS-IS**, empezando por los manifiestos, el notebook y `cli.py`, antes de redactar contratos o refactorizar.

No se recomienda aún:

- corregir imports;
- corregir `NOT_SELECTED`;
- corregir `NOT_RUN`;
- crear nuevas skills;
- migrar módulos;
- diseñar el chasis objetivo;
- declarar Word/PDF como soportados.
