from __future__ import annotations

import csv
import json
import re

from collections import defaultdict
from pathlib import Path
from typing import Any

from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import column_index_from_string

from .utils import (
    contiguous_ranges,
    dump_json,
    write_text
)


CELL_RE = re.compile(
    r"(?P<sheet>(?:'[^']+'|[A-Za-z_][\w .-]*)!)?"
    r"(?P<colabs>\$?)"
    r"(?P<col>[A-Z]{1,3})"
    r"(?P<rowabs>\$?)"
    r"(?P<row>\d+)"
)


VALID_FORMULA_TYPES = {
    "CONTROL_VALIDACION",
    "CALCULO_MODELO",
    "TRANSFORMACION",
    "FORMULA_AUXILIAR"
}


def normalize_formula(
    formula: str
) -> str:
    """
    Normaliza separadores y espacios sin modificar
    la lógica de la fórmula.
    """
    return (
        str(formula)
        .strip()
        .replace(";", ",")
    )


def classify_formula(
    sheet_name: str,
    formula: str,
    coordinate: str
) -> str:
    """
    Clasifica una fórmula antes de compararla contra código.

    Los controles del Excel no deben tratarse automáticamente
    como reglas productivas.
    """
    normalized = (
        normalize_formula(formula)
        .upper()
        .replace(" ", "")
    )

    sheet_normalized = (
        sheet_name
        .lower()
        .replace("_", " ")
        .replace("-", " ")
    )

    control_sheet_tokens = {
        "comparacion",
        "comparación",
        "validacion",
        "validación",
        "control",
        "check",
        "cuadre"
    }

    if any(
        token in sheet_normalized
        for token in control_sheet_tokens
    ):
        return "CONTROL_VALIDACION"

    # Ejemplos:
    # =F4=C4
    # =B21=B11
    # La primera igualdad inicia la fórmula.
    simple_comparison = re.fullmatch(
        r"="
        r"(?:'[^']+'!)?\$?[A-Z]{1,3}\$?\d+"
        r"(?:=|<>|<=|>=|<|>)"
        r"(?:'[^']+'!)?\$?[A-Z]{1,3}\$?\d+",
        normalized
    )

    if simple_comparison:
        return "CONTROL_VALIDACION"

    calculation_functions = {
        "SUMPRODUCT(",
        "SUM(",
        "LN(",
        "LOG(",
        "LOG10(",
        "EXP(",
        "POWER(",
        "PRODUCT("
    }

    if any(
        function in normalized
        for function in calculation_functions
    ):
        return "CALCULO_MODELO"

    transformation_functions = {
        "IF(",
        "IFS(",
        "OR(",
        "AND(",
        "MAX(",
        "MIN(",
        "ROUND(",
        "ROUNDUP(",
        "ROUNDDOWN(",
        "IFERROR(",
        "VLOOKUP(",
        "HLOOKUP(",
        "XLOOKUP(",
        "INDEX(",
        "MATCH("
    }

    if any(
        function in normalized
        for function in transformation_functions
    ):
        return "TRANSFORMACION"

    return "FORMULA_AUXILIAR"


def is_valid_header(
    value: Any
) -> bool:
    """
    Evita utilizar rutas, fórmulas, números y textos
    excesivamente largos como encabezados.
    """
    if not isinstance(
        value,
        str
    ):
        return False

    value = value.strip()

    if not value:
        return False

    if len(value) > 80:
        return False

    if value.startswith("="):
        return False

    if "\\" in value:
        return False

    if "/" in value:
        return False

    if value.lower().startswith(
        (
            "dbfs:",
            "file:",
            "/workspace",
            "/dbfs",
            "/volumes"
        )
    ):
        return False

    if value.lower().endswith(
        (
            ".csv",
            ".json",
            ".xlsx",
            ".xlsm",
            ".py",
            ".sql",
            ".yaml",
            ".yml"
        )
    ):
        return False

    if not re.search(
        r"[A-Za-zÁÉÍÓÚáéíóúÑñ_]",
        value
    ):
        return False

    return True


def find_local_header(
    ws,
    row: int,
    column: int,
    max_distance: int = 15
) -> str | None:
    """
    Busca el encabezado más cercano por encima de una celda.

    Si no encuentra un encabezado confiable, devuelve None.
    """
    if row <= 1:
        return None

    minimum_row = max(
        1,
        row - max_distance
    )

    for candidate_row in range(
        row - 1,
        minimum_row - 1,
        -1
    ):
        value = ws.cell(
            candidate_row,
            column
        ).value

        if is_valid_header(value):
            return value.strip()

    return None

def find_row_label(
    ws,
    row: int,
    column: int,
    max_left_distance: int = 2
) -> str | None:
    """
    Busca primero una etiqueta funcional a la izquierda
    de la celda que contiene la fórmula.
    """
    for distance in range(
        1,
        max_left_distance + 1
    ):
        candidate_column = (
            column - distance
        )

        if candidate_column < 1:
            break

        value = ws.cell(
            row,
            candidate_column
        ).value

        if is_valid_header(value):
            return value.strip()

    return None

def describe_reference(
    wb,
    current_sheet: str,
    referenced_sheet: str,
    row: int,
    column: int
) -> str:
    """
    Obtiene una etiqueta contextual para una referencia.

    Si no encuentra un encabezado confiable, conserva
    hoja y coordenada para no inventar significado.
    """
    target_sheet = (
        referenced_sheet
        or current_sheet
    )

    if target_sheet not in wb.sheetnames:
        return (
            f"{target_sheet}!"
            f"{get_column_letter(column)}{row}"
        )

    ws = wb[target_sheet]

    header = find_local_header(
        ws=ws,
        row=row,
        column=column
    )

    if header:
        return header

    return (
        f"{target_sheet}!"
        f"{get_column_letter(column)}{row}"
    )


def _sheet_from_match(
    match,
    current_sheet: str
) -> str:
    sheet = (
        match.group("sheet")
        or ""
    )

    sheet = (
        sheet
        .rstrip("!")
        .strip("'")
    )

    return (
        sheet
        or current_sheet
    )


def canonicalize_with_context(
    formula: str,
    origin_row: int,
    origin_column: int,
    current_sheet: str,
    wb
) -> str:
    """
    Canonización legible.

    Sustituye referencias por encabezados locales cuando
    existe suficiente evidencia. También conserva offsets
    relativos de fila y columna.
    """

    def replace_reference(
        match
    ) -> str:
        referenced_sheet = _sheet_from_match(
            match,
            current_sheet
        )

        referenced_column = (
            column_index_from_string(
                match.group("col")
            )
        )

        referenced_row = int(
            match.group("row")
        )

        label = describe_reference(
            wb=wb,
            current_sheet=current_sheet,
            referenced_sheet=referenced_sheet,
            row=referenced_row,
            column=referenced_column
        )

        if match.group("rowabs"):
            row_component = (
                f"R_ABS[{referenced_row}]"
            )
        else:
            row_offset = (
                referenced_row
                - origin_row
            )

            row_component = (
                f"R[{row_offset:+d}]"
            )

        if match.group("colabs"):
            column_component = (
                "C_ABS["
                f"{get_column_letter(referenced_column)}"
                "]"
            )
        else:
            column_offset = (
                referenced_column
                - origin_column
            )

            column_component = (
                f"C[{column_offset:+d}]"
            )

        return (
            f"{{{label}}}"
            f"{row_component}"
            f"{column_component}"
        )

    normalized = normalize_formula(
        formula
    )

    return CELL_RE.sub(
        replace_reference,
        normalized
    )


def canonicalize_structural(
    formula: str,
    origin_row: int,
    origin_column: int,
    current_sheet: str
) -> str:
    """
    Firma estructural independiente de la ubicación.

    Permite agrupar:
      J38, K38, L38 ... BG38

    cuando las fórmulas son copias horizontales de la
    misma lógica.
    """

    def replace_reference(
        match
    ) -> str:
        referenced_sheet = _sheet_from_match(
            match,
            current_sheet
        )

        referenced_column = (
            column_index_from_string(
                match.group("col")
            )
        )

        referenced_row = int(
            match.group("row")
        )

        if match.group("rowabs"):
            row_component = (
                f"R_ABS[{referenced_row}]"
            )
        else:
            row_offset = (
                referenced_row
                - origin_row
            )

            row_component = (
                f"R[{row_offset:+d}]"
            )

        if match.group("colabs"):
            column_component = (
                "C_ABS["
                f"{get_column_letter(referenced_column)}"
                "]"
            )
        else:
            column_offset = (
                referenced_column
                - origin_column
            )

            column_component = (
                f"C[{column_offset:+d}]"
            )

        sheet_component = ""

        if referenced_sheet != current_sheet:
            sheet_component = (
                f"SHEET[{referenced_sheet}]"
            )

        return (
            sheet_component
            + row_component
            + column_component
        )

    normalized = (
        normalize_formula(formula)
        .upper()
        .replace(" ", "")
    )

    return CELL_RE.sub(
        replace_reference,
        normalized
    )


def excel_signature(
    formula: str
) -> dict:
    """
    Extrae funciones, operadores, constantes numéricas
    y cadenas utilizadas en una fórmula.
    """
    normalized = (
        normalize_formula(formula)
        .upper()
    )

    functions = sorted(
        set(
            re.findall(
                r"\b([A-Z][A-Z0-9_.]*)\s*\(",
                normalized
            )
        )
    )

    operators = re.findall(
        r"<>|<=|>=|[+\-*/^&=<>]",
        normalized
    )

    numbers = sorted(
        set(
            re.findall(
                r"(?<![A-Z_])"
                r"[-+]?\d+(?:\.\d+)?"
                r"(?:E[-+]?\d+)?",
                normalized
            )
        )
    )

    strings = sorted(
        set(
            re.findall(
                r'"([^"]*)"',
                formula
            )
        )
    )

    return {
        "functions": functions,
        "operators": operators,
        "numbers": numbers,
        "strings": strings
    }


def contiguous_column_ranges(
    columns
) -> list:
    """
    Convierte [10, 11, 12, 13] en ["J:M"].
    """
    values = sorted(
        set(
            int(column)
            for column in columns
        )
    )

    if not values:
        return []

    ranges = []
    start = values[0]
    previous = values[0]

    for column in values[1:]:
        if column == previous + 1:
            previous = column
            continue

        if start == previous:
            ranges.append(
                get_column_letter(start)
            )
        else:
            ranges.append(
                f"{get_column_letter(start)}:"
                f"{get_column_letter(previous)}"
            )

        start = column
        previous = column

    if start == previous:
        ranges.append(
            get_column_letter(start)
        )
    else:
        ranges.append(
            f"{get_column_letter(start)}:"
            f"{get_column_letter(previous)}"
        )

    return ranges


def determine_orientation(
    rows,
    columns
) -> str:
    unique_rows = set(
        rows
    )

    unique_columns = set(
        columns
    )

    if (
        len(unique_rows) == 1
        and len(unique_columns) > 1
    ):
        return "HORIZONTAL"

    if (
        len(unique_columns) == 1
        and len(unique_rows) > 1
    ):
        return "VERTICAL"

    if (
        len(unique_columns) > 1
        and len(unique_rows) > 1
    ):
        return "MATRICIAL"

    return "CELDA_UNICA"


def select_rule_header(
    wb,
    sheet: str,
    rows,
    columns
) -> str:
    """
    Selecciona el nombre funcional de la regla.

    Prioridad:
    1. Etiqueta a la izquierda en la misma fila.
    2. Encabezado local superior.
    3. Coordenada objetiva.
    """
    ws = wb[sheet]

    row_labels = []

    for row, column in zip(
        rows,
        columns
    ):
        row_label = find_row_label(
            ws=ws,
            row=row,
            column=column
        )

        if row_label:
            row_labels.append(
                row_label
            )

    unique_row_labels = list(
        dict.fromkeys(
            row_labels
        )
    )

    if len(unique_row_labels) == 1:
        return unique_row_labels[0]

    if unique_row_labels:
        return " / ".join(
            unique_row_labels[:5]
        )

    headers = []

    for row, column in zip(
        rows,
        columns
    ):
        header = find_local_header(
            ws=ws,
            row=row,
            column=column
        )

        if header:
            headers.append(
                header
            )

    unique_headers = list(
        dict.fromkeys(
            headers
        )
    )

    if len(unique_headers) == 1:
        return unique_headers[0]

    first_row = min(
        rows
    )

    column_ranges = contiguous_column_ranges(
        columns
    )

    return (
        f"{sheet}!"
        f"{','.join(column_ranges)}"
        f" fila {first_row}"
    )


def _detect_parameters(
    raw_cells
) -> list:
    """
    Extrae pares clave-valor candidatos.

    No interpreta automáticamente cualquier texto como
    parámetro. Conserva evidencia de celda.
    """
    parameter_pattern = re.compile(
        r"param|beta|coef|cota|min|max|imput|"
        r"intercept|threshold|factor|tasa|edad|"
        r"ing|ratio|flg|flag|theta|bin|rango",
        re.IGNORECASE
    )

    by_sheet_and_row = defaultdict(
        dict
    )

    for cell in raw_cells:
        if cell.get(
            "formula"
        ):
            continue

        by_sheet_and_row[
            (
                cell["sheet"],
                cell["row"]
            )
        ][
            cell["column"]
        ] = cell

    parameters = []

    for (
        sheet,
        row
    ), items in by_sheet_and_row.items():
        for column in sorted(
            items
        ):
            current = items[
                column
            ]

            key = current.get(
                "raw_value"
            )

            next_cell = items.get(
                column + 1
            )

            if not isinstance(
                key,
                str
            ):
                continue

            key = key.strip()

            if not key:
                continue

            if not parameter_pattern.search(
                key
            ):
                continue

            if next_cell is None:
                continue

            value = next_cell.get(
                "raw_value"
            )

            if value is None:
                value = next_cell.get(
                    "cached_value"
                )

            if value is None:
                continue

            parameters.append({
                "sheet": sheet,
                "key": key,
                "value": value,
                "key_cell": current[
                    "coordinate"
                ],
                "value_cell": next_cell[
                    "coordinate"
                ]
            })

    deduplicated = {
        (
            parameter["sheet"],
            parameter["key_cell"]
        ): parameter
        for parameter in parameters
    }

    return list(
        deduplicated.values()
    )


def _write_cells_csv(
    raw_cells,
    output_dir
) -> None:
    csv_path = (
        Path(output_dir)
        / "02_celdas.csv"
    )

    fields = [
        "sheet",
        "coordinate",
        "row",
        "column",
        "column_letter",
        "formula",
        "cached_value",
        "raw_value",
        "data_type"
    ]

    with csv_path.open(
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fields
        )

        writer.writeheader()

        for cell in raw_cells:
            writer.writerow({
                field: cell.get(
                    field
                )
                for field in fields
            })


def _build_formula_groups(
    wb,
    raw_cells
) -> dict:
    """
    Agrupa fórmulas por:

      hoja + tipo + firma estructural

    La firma estructural normaliza desplazamientos tanto
    verticales como horizontales.
    """
    groups = defaultdict(
        lambda: {
            "cells": [],
            "rows": [],
            "columns": [],
            "examples": [],
            "signature": None,
            "contextual_formulas": []
        }
    )

    for cell in raw_cells:
        formula = cell.get(
            "formula"
        )

        if not formula:
            continue

        sheet = cell[
            "sheet"
        ]

        row = int(
            cell["row"]
        )

        column = int(
            cell["column"]
        )

        coordinate = cell[
            "coordinate"
        ]

        formula_type = classify_formula(
            sheet_name=sheet,
            formula=formula,
            coordinate=coordinate
        )

        structural_formula = (
            canonicalize_structural(
                formula=formula,
                origin_row=row,
                origin_column=column,
                current_sheet=sheet
            )
        )

        contextual_formula = (
            canonicalize_with_context(
                formula=formula,
                origin_row=row,
                origin_column=column,
                current_sheet=sheet,
                wb=wb
            )
        )

        key = (
            sheet,
            formula_type,
            structural_formula
        )

        group = groups[
            key
        ]

        group["cells"].append(
            coordinate
        )

        group["rows"].append(
            row
        )

        group["columns"].append(
            column
        )

        if len(
            group["examples"]
        ) < 5:
            group["examples"].append({
                "cell": coordinate,
                "formula": formula,
                "cached": cell.get(
                    "cached_value"
                )
            })

        if contextual_formula not in group[
            "contextual_formulas"
        ]:
            group[
                "contextual_formulas"
            ].append(
                contextual_formula
            )

        group["signature"] = excel_signature(
            formula
        )

    return groups


def _groups_to_rules(
    wb,
    groups
) -> list:
    """
    Convierte grupos estructurales en reglas únicas.
    """
    rules = []

    sorted_groups = sorted(
        groups.items(),
        key=lambda item: (
            item[0][0],
            min(
                item[1]["rows"]
            ),
            min(
                item[1]["columns"]
            ),
            item[0][2]
        )
    )

    for index, (
        key,
        group
    ) in enumerate(
        sorted_groups,
        start=1
    ):
        (
            sheet,
            formula_type,
            structural_formula
        ) = key

        rows = group[
            "rows"
        ]

        columns = group[
            "columns"
        ]

        orientation = determine_orientation(
            rows,
            columns
        )

        header = select_rule_header(
            wb=wb,
            sheet=sheet,
            rows=rows,
            columns=columns
        )

        contextual_formulas = group[
            "contextual_formulas"
        ]

        canonical_formula = (
            contextual_formulas[0]
            if contextual_formulas
            else structural_formula
        )

        rules.append({
            "rule_id": (
                f"XL-{index:04d}"
            ),
            "sheet": sheet,
            "formula_type": formula_type,
            "orientation": orientation,
            "header": header,
            "columns": (
                contiguous_column_ranges(
                    columns
                )
            ),
            "row_ranges": (
                contiguous_ranges(
                    rows
                )
            ),
            "cell_count": len(
                group["cells"]
            ),
            "cells": group[
                "cells"
            ],
            "canonical_formula": (
                canonical_formula
            ),
            "structural_formula": (
                structural_formula
            ),
            "contextual_variants": len(
                contextual_formulas
            ),
            "examples": group[
                "examples"
            ],
            "signature": group[
                "signature"
            ],
            "natural_language": (
                "Pendiente de interpretación por IA"
            )
        })

    return rules


def _translate_rules_with_llm(
    rules,
    llm,
    batch_size
) -> None:
    if not llm:
        return

    system = """
Eres especialista en ingeniería inversa de hojas de cálculo.

Recibirás reglas canónicas extraídas de un Excel.

Traduce cada regla a lenguaje natural en español.

Reglas:

1. No inventes nombres ni significados.
2. Usa formula_type, orientación, celdas, encabezado,
   fórmula canónica y ejemplos.
3. Si formula_type es CONTROL_VALIDACION, explica que
   se trata de una comprobación del Excel.
4. Si el encabezado es una coordenada, no inventes el
   significado de la variable.
5. Una regla horizontal aplica a todas las columnas
   indicadas, no únicamente a la primera.
6. Devuelve exclusivamente un arreglo JSON válido.
7. Cada elemento debe contener:
   - rule_id
   - natural_language
"""

    for start in range(
        0,
        len(rules),
        batch_size
    ):
        batch = rules[
            start:start + batch_size
        ]

        payload = []

        for rule in batch:
            payload.append({
                "rule_id": rule[
                    "rule_id"
                ],
                "sheet": rule[
                    "sheet"
                ],
                "formula_type": rule[
                    "formula_type"
                ],
                "orientation": rule[
                    "orientation"
                ],
                "header": rule[
                    "header"
                ],
                "columns": rule[
                    "columns"
                ],
                "row_ranges": rule[
                    "row_ranges"
                ],
                "canonical_formula": rule[
                    "canonical_formula"
                ],
                "structural_formula": rule[
                    "structural_formula"
                ],
                "examples": rule[
                    "examples"
                ]
            })

        try:
            response = llm.chat(
                system,
                json.dumps(
                    payload,
                    ensure_ascii=False,
                    default=str
                ),
                json_mode=True
            )

            if not isinstance(
                response,
                list
            ):
                continue

            translations = {
                item.get(
                    "rule_id"
                ): item.get(
                    "natural_language",
                    ""
                )
                for item in response
                if isinstance(
                    item,
                    dict
                )
            }

            for rule in batch:
                translated = translations.get(
                    rule["rule_id"]
                )

                if translated:
                    rule[
                        "natural_language"
                    ] = str(
                        translated
                    )

        except Exception as exc:
            for rule in batch:
                rule[
                    "natural_language"
                ] = (
                    "No generada por IA: "
                    f"{type(exc).__name__}"
                )


def _write_rules_markdown(
    rules,
    output_dir
) -> None:
    lines = [
        "# Reglas canónicas del Excel",
        "",
        (
            "Las fórmulas se agrupan por firma estructural, "
            "normalizando desplazamientos verticales y horizontales."
        ),
        ""
    ]

    for rule in rules:
        columns = ", ".join(
            rule["columns"]
        )

        rows = ", ".join(
            rule["row_ranges"]
        )

        lines.extend([
            (
                f"## {rule['rule_id']} · "
                f"{rule['sheet']} · "
                f"{rule['header']}"
            ),
            (
                "- Tipo: "
                f"**{rule['formula_type']}**"
            ),
            (
                "- Orientación: "
                f"**{rule['orientation']}**"
            ),
            (
                "- Columnas cubiertas: "
                f"`{columns}`"
            ),
            (
                "- Filas cubiertas: "
                f"`{rows}`"
            ),
            (
                "- Celdas cubiertas: "
                f"**{rule['cell_count']}**"
            ),
            (
                "- Fórmula canónica contextual: "
                f"`{rule['canonical_formula']}`"
            ),
            (
                "- Firma estructural: "
                f"`{rule['structural_formula']}`"
            ),
            (
                "- Traducción: "
                f"{rule['natural_language']}"
            ),
            (
                "- Variantes contextuales: "
                f"**{rule['contextual_variants']}**"
            )
        ])

        if (
            rule["formula_type"]
            == "CONTROL_VALIDACION"
        ):
            lines.append(
                "- Tratamiento: este control no se exige "
                "literalmente en el código productivo."
            )

        if (
            rule["contextual_variants"] > 1
            and rule["orientation"]
            not in {
                "HORIZONTAL",
                "VERTICAL"
            }
        ):
            lines.append(
                "- **Señal de revisión:** el grupo contiene "
                "más de una variante contextual."
            )

        lines.extend([
            "",
            "Ejemplos:"
        ])

        for example in rule[
            "examples"
        ]:
            lines.append(
                f"- `{example['cell']}`: "
                f"`{example['formula']}`"
            )

        lines.append("")

    if not rules:
        lines.append(
            "No se detectaron fórmulas."
        )

    write_text(
        Path(output_dir)
        / "03_reglas_excel.md",
        "\n".join(lines)
    )


def extract_rules(
    wb,
    raw_cells,
    output_dir,
    llm=None,
    scan_rows=30,
    batch_size=25
):
    """
    Punto de entrada de la fase 2.

    Genera:
      - 02_celdas.csv
      - 03_reglas_excel.md
      - 04_parametros.json
      - artifacts/rules.json
    """
    output_dir = Path(
        output_dir
    )

    (
        output_dir
        / "artifacts"
    ).mkdir(
        parents=True,
        exist_ok=True
    )

    _write_cells_csv(
        raw_cells=raw_cells,
        output_dir=output_dir
    )

    groups = _build_formula_groups(
        wb=wb,
        raw_cells=raw_cells
    )

    rules = _groups_to_rules(
        wb=wb,
        groups=groups
    )

    _translate_rules_with_llm(
        rules=rules,
        llm=llm,
        batch_size=batch_size
    )

    parameters = _detect_parameters(
        raw_cells
    )

    dump_json(
        output_dir
        / "artifacts"
        / "rules.json",
        rules
    )

    dump_json(
        output_dir
        / "04_parametros.json",
        parameters
    )

    _write_rules_markdown(
        rules=rules,
        output_dir=output_dir
    )

    return (
        rules,
        parameters
    )