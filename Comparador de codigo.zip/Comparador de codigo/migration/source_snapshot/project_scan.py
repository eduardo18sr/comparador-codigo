from __future__ import annotations
import ast, json, re
from collections import Counter
from pathlib import Path
from .utils import compact, dump_json, write_text


def iter_project_files(
    root,
    include_exts,
    exclude_dirs,
    max_bytes
):
    import os
    from pathlib import Path

    root = Path(root)
    include_exts = set(include_exts)
    excluded = set(exclude_dirs)

    if not root.exists():
        raise FileNotFoundError(
            f"No existe la raíz del proyecto: {root}"
        )

    for current_root, dirs, files in os.walk(
        root,
        topdown=True,
        onerror=lambda error: None
    ):
        # Evita entrar en carpetas excluidas
        dirs[:] = [
            directory
            for directory in dirs
            if directory not in excluded
        ]

        current_path = Path(current_root)

        for filename in files:
            path = current_path / filename

            if path.suffix.lower() not in include_exts:
                continue

            try:
                if not path.is_file():
                    continue

                if path.stat().st_size > max_bytes:
                    continue

                yield path

            except (
                FileNotFoundError,
                PermissionError,
                OSError
            ):
                # El archivo pudo desaparecer o no ser accesible
                # durante el recorrido.
                continue


def read_code_text(path):
    if path.suffix.lower()==".ipynb":
        try:
            nb=json.loads(path.read_text(encoding="utf-8"))
            return "\n\n".join("".join(c.get("source",[])) for c in nb.get("cells",[]) if c.get("cell_type")=="code")
        except Exception: return ""
    for enc in ("utf-8","latin-1"):
        try:return path.read_text(encoding=enc)
        except UnicodeDecodeError:pass
    return ""


def py_features(text):
    try: tree=ast.parse(text)
    except SyntaxError:return {"strings":[],"names":[],"numbers":[],"operators":[],"functions":[]}
    strings=[]; names=[]; numbers=[]; ops=[]; funcs=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Constant):
            if isinstance(n.value,str): strings.append(n.value)
            elif isinstance(n.value,(int,float)): numbers.append(n.value)
        elif isinstance(n,ast.Name): names.append(n.id)
        elif isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)): funcs.append(n.name)
        elif isinstance(n,ast.BinOp): ops.append(type(n.op).__name__)
        elif isinstance(n,ast.Compare): ops.extend(type(x).__name__ for x in n.ops)
    return {"strings":strings,"names":names,"numbers":numbers,"operators":ops,"functions":funcs}


def score_candidate(rel,text,features,rules,params):
    lower=text.lower(); reasons=[]; lexical=0; structural=0; arithmetic=0
    terms=set()
    for p in params:
        key=str(p.get('key','')).strip()
        if len(key)>=3: terms.add(key.lower())
    for r in rules:
        h=str(r.get('header','')).strip()
        if len(h)>=3: terms.add(h.lower())
    hits=[t for t in terms if t in lower]
    lexical=min(40,len(hits)*4)
    if hits: reasons.append("términos/encabezados: "+", ".join(sorted(hits)[:12]))
    strings={str(x).lower() for x in features.get('strings',[])}
    strhits=[t for t in terms if t in strings]
    structural=min(35,len(strhits)*7)
    if strhits: reasons.append("literales exactos: "+", ".join(sorted(strhits)[:10]))
    rule_ops=Counter(op for r in rules for op in r.get('signature',{}).get('operators',[]))
    pyops=Counter(features.get('operators',[]))
    mapped={'Add':'+','Sub':'-','Mult':'*','Div':'/','Pow':'^','Eq':'=','Lt':'<','Gt':'>','LtE':'<=','GtE':'>='}
    overlaps=sum(min(pyops[k],rule_ops.get(v,0)) for k,v in mapped.items())
    nums=set(str(x) for x in features.get('numbers',[]))
    expected=set(str(p.get('value')) for p in params if isinstance(p.get('value'),(int,float)))
    numhits=len(nums & expected)
    arithmetic=min(25,overlaps*2+numhits*3)
    if arithmetic: reasons.append(f"firma aritmética: operadores={overlaps}, constantes={numhits}")
    return lexical+structural+arithmetic,{"lexical":lexical,"structural":structural,"arithmetic":arithmetic},reasons


def find_candidates(project_root,rules,params,config,output_dir):
    files=[]
    for p in iter_project_files(project_root,set(config['include_extensions']),config['exclude_dirs'],config['max_file_bytes']):
        text=read_code_text(p)
        if not text: continue
        rel=str(p.relative_to(project_root))
        features=py_features(text) if p.suffix.lower()=='.py' else {"strings":re.findall(r"['\"]([^'\"]{2,})['\"]",text),"names":[],"numbers":re.findall(r"(?<!\w)\d+(?:\.\d+)?",text),"operators":re.findall(r"<>|<=|>=|[+\-*/^=<>]",text),"functions":[]}
        score,channels,reasons=score_candidate(rel,text,features,rules,params)
        if score>0:
            files.append({"path":rel,"score":score,"channels":channels,"reasons":reasons,"functions":features.get('functions',[])[:80],"size":len(text)})
    files.sort(key=lambda x:(-x['score'],x['path']))
    dump_json(Path(output_dir)/"artifacts/candidates.json",files)
    lines=["# Candidatos de implementación","", "Se excluyen pruebas, mocks, cachés y entornos configurados. Las tres señales se calculan de forma independiente.",""]
    for x in files:
        lines += [f"## {x['path']}",f"- Puntaje: **{x['score']}**",f"- Léxica: {x['channels']['lexical']} · Estructural: {x['channels']['structural']} · Aritmética: {x['channels']['arithmetic']}",f"- Motivos: {'; '.join(x['reasons'])}",f"- Funciones: {', '.join(x['functions']) if x['functions'] else 'no extraídas'}",""]
    if not files: lines.append("No se localizaron candidatos con las señales disponibles.")
    write_text(Path(output_dir)/"05_candidatos.md","\n".join(lines))
    return files
