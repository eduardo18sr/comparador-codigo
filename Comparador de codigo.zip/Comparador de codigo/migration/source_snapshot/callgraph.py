from __future__ import annotations
import ast
from collections import defaultdict
from pathlib import Path
from .project_scan import iter_project_files, read_code_text
from .utils import dump_json, write_text

class Visitor(ast.NodeVisitor):
    def __init__(self,module):
        self.module=module; self.scope=[]; self.defs=[]; self.calls=[]; self.imports=[]; self.alias={}
    def visit_Import(self,node):
        for a in node.names:
            self.alias[a.asname or a.name.split('.')[0]]=a.name
            self.imports.append({"kind":"import","name":a.name,"alias":a.asname,"line":node.lineno})
    def visit_ImportFrom(self,node):
        mod=node.module or ''
        for a in node.names:
            target=f"{mod}.{a.name}" if mod else a.name
            self.alias[a.asname or a.name]=target
            self.imports.append({"kind":"from","name":target,"alias":a.asname,"line":node.lineno})
    def _def(self,node,kind):
        q=".".join([self.module,*self.scope,node.name])
        self.defs.append({"qname":q,"name":node.name,"kind":kind,"line":node.lineno})
        self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
    def visit_FunctionDef(self,node): self._def(node,"function")
    def visit_AsyncFunctionDef(self,node): self._def(node,"async_function")
    def visit_ClassDef(self,node): self._def(node,"class")
    def visit_Call(self,node):
        caller=".".join([self.module,*self.scope])
        raw=self._name(node.func)
        resolved=self._resolve(raw)
        self.calls.append({"caller":caller,"raw":raw,"resolved_hint":resolved,"line":node.lineno})
        self.generic_visit(node)
    def _name(self,n):
        if isinstance(n,ast.Name):return n.id
        if isinstance(n,ast.Attribute):
            base=self._name(n.value); return f"{base}.{n.attr}" if base else n.attr
        return "<dynamic>"
    def _resolve(self,raw):
        first=raw.split('.')[0]
        if first in self.alias:return self.alias[first]+raw[len(first):]
        return raw

def build_callgraph(project_root,config,output_dir):
    defs={}; calls=[]; imports=[]; module_by_file={}
    for p in iter_project_files(project_root,{'.py'},config['exclude_dirs'],config['max_file_bytes']):
        rel=p.relative_to(project_root); module='.'.join(rel.with_suffix('').parts)
        text=read_code_text(p)
        try:tree=ast.parse(text)
        except SyntaxError:continue
        v=Visitor(module); v.visit(tree)
        for d in v.defs: defs[d['qname']]={**d,"file":str(rel)}
        calls.extend({**c,"file":str(rel)} for c in v.calls)
        imports.extend({**i,"file":str(rel),"module":module} for i in v.imports)
        module_by_file[str(rel)]=module
    by_simple=defaultdict(list)
    for q,d in defs.items():by_simple[d['name']].append(q)
    edges=[]; unresolved=[]
    for c in calls:
        target=None; hint=c['resolved_hint']
        if hint in defs:target=hint
        elif hint.split('.')[-1] in by_simple and len(by_simple[hint.split('.')[-1]])==1:target=by_simple[hint.split('.')[-1]][0]
        if target: edges.append({"caller":c['caller'],"callee":target,"line":c['line'],"file":c['file']})
        else: unresolved.append(c)
    down=defaultdict(list); up=defaultdict(list)
    for e in edges: down[e['caller']].append(e['callee']); up[e['callee']].append(e['caller'])
    graph={"definitions":list(defs.values()),"edges":edges,"unresolved":unresolved,"imports":imports}
    dump_json(Path(output_dir)/"artifacts/callgraph.json",graph)
    lines=["# Grafo estático de llamadas", "", "## Árbol hacia abajo"]
    for caller,callees in sorted(down.items()):
        lines.append(f"- `{caller}`")
        lines += [f"  - `{x}`" for x in sorted(set(callees))]
    lines += ["", "## Cadena hacia arriba"]
    for callee,callers in sorted(up.items()):
        lines.append(f"- `{callee}`")
        lines += [f"  - llamado por `{x}`" for x in sorted(set(callers))]
    lines += ["", "## Puntos no resueltos"]
    for c in unresolved[:1000]:lines.append(f"- `{c['file']}:{c['line']}` · `{c['caller']}` → `{c['raw']}`")
    if not unresolved:lines.append("- Ninguno.")
    write_text(Path(output_dir)/"06_grafo.md","\n".join(lines))
    return graph
