from __future__ import annotations
import json, re, hashlib
from pathlib import Path
from typing import Any, Iterable


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def json_default(obj: Any):
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    return str(obj)


def dump_json(path: str | Path, data: Any) -> None:
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, default=json_default), encoding="utf-8")


def write_text(path: str | Path, text: str) -> None:
    Path(path).write_text(text, encoding="utf-8")


def safe_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).replace("\r\n", "\n").replace("\r", "\n")


def compact(value: Any, limit: int = 240) -> str:
    s = re.sub(r"\s+", " ", safe_text(value)).strip()
    return s if len(s) <= limit else s[: limit - 3] + "..."


def contiguous_ranges(rows: Iterable[int]) -> list[str]:
    xs = sorted(set(int(x) for x in rows))
    if not xs:
        return []
    out, start, prev = [], xs[0], xs[0]
    for x in xs[1:]:
        if x == prev + 1:
            prev = x
            continue
        out.append(str(start) if start == prev else f"{start}-{prev}")
        start = prev = x
    out.append(str(start) if start == prev else f"{start}-{prev}")
    return out


def stable_id(*parts: Any) -> str:
    raw = "|".join(map(str, parts)).encode("utf-8", errors="replace")
    return hashlib.sha1(raw).hexdigest()[:12]
