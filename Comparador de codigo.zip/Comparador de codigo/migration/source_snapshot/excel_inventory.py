from __future__ import annotations
from collections import Counter
from pathlib import Path
import re
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from .utils import compact, dump_json, write_text, safe_text

FORMULA_REF_RE = re.compile(r"(?:(?:'[^']+'|[A-Za-z_][\w .-]*)!)?\$?[A-Z]{1,3}\$?\d+")


def _used_bounds(ws):
    nonempty=[]
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                nonempty.append((c.row,c.column))
    if not nonempty:
        return None
    rows=[x[0] for x in nonempty]; cols=[x[1] for x in nonempty]
    return min(rows), min(cols), max(rows), max(cols)


def _classify_sheet(ws, stats, threshold=.65):
    texts=[]; numerics=0
    for row in ws.iter_rows():
        for c in row:
            v=c.value
            if v is None: continue
            if isinstance(v,(int,float)): numerics+=1
            else: texts.append(str(v).lower())
    blob=" ".join(texts[:2000])
    param_hits=sum(k in blob for k in ["param", "beta", "coef", "cota", "imput", "threshold", "hiper", "config"])
    calc_hits=sum(k in blob for k in ["calculo", "resultado", "estimad", "formula", "output", "score", "ead", "lgd", "pd"])
    formula_ratio=stats["formula_cells"]/max(1,stats["nonempty_cells"])
    if param_hits>=2 and calc_hits>=1: return "mixta: parámetros y cálculo"
    if param_hits>=2 or (stats["constant_cells"] and formula_ratio < .05 and numerics/max(1,stats["constant_cells"])>=threshold): return "zona probable de parámetros/datos"
    if calc_hits>=2 or formula_ratio>=.08: return "zona probable de cálculo"
    return "contenido mixto o no concluyente"


def inventory_excel(excel_path, output_dir):
    wb_formula=load_workbook(excel_path, data_only=False, read_only=False, keep_links=True)
    wb_values=load_workbook(excel_path, data_only=True, read_only=False, keep_links=True)
    sheets=[]; raw_cells=[]
    for ws in wb_formula.worksheets:
        wsv=wb_values[ws.title]
        bounds=_used_bounds(ws)
        stats={"nonempty_cells":0,"formula_cells":0,"constant_cells":0,"array_formula_cells":0}
        refs=Counter(); formula_samples=[]
        for row in ws.iter_rows():
            for c in row:
                v=c.value
                if v is None: continue
                stats["nonempty_cells"]+=1
                formula = safe_text(v) if c.data_type=="f" or safe_text(v).startswith("=") else ""
                if formula:
                    stats["formula_cells"] += 1

                    formula_samples.append(
                        f"{c.coordinate}: {formula}"
                    )

                    for ref in FORMULA_REF_RE.findall(formula):
                        refs[ref] += 1
                else: stats["constant_cells"]+=1
                if c.coordinate in getattr(ws,"array_formulae",{}): stats["array_formula_cells"]+=1
                raw_cells.append({"sheet":ws.title,"coordinate":c.coordinate,"row":c.row,"column":c.column,"column_letter":get_column_letter(c.column),"formula":formula,"cached_value":wsv[c.coordinate].value,"raw_value":None if formula else v,"data_type":c.data_type})
        rng="vacía" if not bounds else f"{get_column_letter(bounds[1])}{bounds[0]}:{get_column_letter(bounds[3])}{bounds[2]}"
        sheet={"name":ws.title,"state":ws.sheet_state,"used_range":rng,"merged_cells":[str(x) for x in ws.merged_cells.ranges],"formula_references":refs.most_common(50),"formula_samples":formula_samples,**stats}
        sheet["classification"]=_classify_sheet(ws,stats)
        sheets.append(sheet)
    defined=[]
    for item in wb_formula.defined_names.values():
        defined.append({"name":item.name,"attr_text":item.attr_text,"type":item.type,"hidden":item.hidden,"localSheetId":item.localSheetId})
    external=[]
    for link in getattr(wb_formula,"_external_links",[]) or []:
        external.append({"repr":compact(link,500),"file_link":compact(getattr(getattr(link,"file_link",None),"Target",None),500)})
    workbook={"file":str(excel_path),"sheet_count":len(sheets),"sheets":sheets,"defined_names":defined,"external_links":external,"calculation":compact(getattr(wb_formula,"calculation",None),500)}
    dump_json(Path(output_dir)/"artifacts/excel_inventory.json",workbook)
    dump_json(Path(output_dir)/"artifacts/raw_cells.json",raw_cells)
    lines=[f"# Mapa del Excel\n\nArchivo: `{excel_path}`\n",f"Hojas: **{len(sheets)}**\n"]
    for s in sheets:
        lines += [f"## {s['name']}",f"- Estado: `{s['state']}`",f"- Rango usado: `{s['used_range']}`",f"- Celdas no vacías: **{s['nonempty_cells']}**",f"- Celdas con fórmula: **{s['formula_cells']}**",f"- Celdas constantes: **{s['constant_cells']}**",f"- Fórmulas matriciales registradas: **{s['array_formula_cells']}**",f"- Clasificación heurística: **{s['classification']}**",f"- Celdas combinadas: {', '.join(s['merged_cells']) if s['merged_cells'] else 'ninguna'}"]
        if s['formula_references']:
            lines.append("- Referencias frecuentes: "+", ".join(f"`{r}` ({n})" for r,n in s['formula_references'][:12]))
        if s['formula_samples']:
            lines += ["\nFórmulas completas:","```text",*s['formula_samples'],"```"]
    lines += ["## Nombres definidos"]
    lines += [f"- `{x['name']}` → `{x['attr_text']}`" for x in defined] or ["- Ninguno detectado."]
    lines += ["\n## Referencias externas"]
    lines += [f"- `{x}`" for x in external] or ["- Ninguna registrada por openpyxl."]
    lines += ["\n## Advertencia","`data_only=True` no recalcula fórmulas. Solo recupera el último valor cacheado guardado por una aplicación de hoja de cálculo. Un valor cacheado vacío no implica que la fórmula devuelva vacío."]
    write_text(Path(output_dir)/"01_mapa_excel.md","\n".join(lines)+"\n")
    return wb_formula, workbook, raw_cells
