from __future__ import annotations
import importlib, math
from pathlib import Path
from .utils import write_text, compact


def load_callable(spec):
    module,name=spec.split(':',1)
    return getattr(importlib.import_module(module),name)


def close(a,b,abs_tol,rel_tol):
    try:return math.isclose(float(a),float(b),abs_tol=abs_tol,rel_tol=rel_tol)
    except (TypeError,ValueError):return a==b


def reconcile(wb_values,config,output_dir):
    lines=["# Reconciliación numérica",""]
    if not config.get('enabled'):
        lines += ["Estado: **NO EJECUTADA**","", "La reconciliación está deshabilitada en la configuración."]
        write_text(Path(output_dir)/"08_reconciliacion.md","\n".join(lines));return {"status":"NOT_RUN","reason":"disabled"}
    adapter_spec=config.get('adapter','')
    if not adapter_spec:
        lines += ["Estado: **NO EJECUTADA**","", "No se configuró `reconciliation.adapter`. La ejecución segura del proyecto requiere un punto de entrada explícito."]
        write_text(Path(output_dir)/"08_reconciliacion.md","\n".join(lines));return {"status":"NOT_RUN","reason":"missing_adapter"}
    ws=wb_values[config['sheet']]; row=int(config['row'])
    header_to_col={str(ws.cell(1,c).value).strip():c for c in range(1,ws.max_column+1) if ws.cell(1,c).value is not None}
    missing=[x for x in config['input_columns']+config['expected_columns'] if x not in header_to_col]
    if missing:
        lines += ["Estado: **NO EJECUTADA**",f"Encabezados no encontrados en la fila 1: {', '.join(missing)}"]
        write_text(Path(output_dir)/"08_reconciliacion.md","\n".join(lines));return {"status":"NOT_RUN","reason":"missing_headers","missing":missing}
    inputs={h:ws.cell(row,header_to_col[h]).value for h in config['input_columns']}
    expected={h:ws.cell(row,header_to_col[h]).value for h in config['expected_columns']}
    func=load_callable(adapter_spec); actual=func(inputs)
    abs_tol=float(config.get('abs_tolerance',1e-6)); rel_tol=float(config.get('rel_tolerance',1e-6))
    comparisons=[]
    for k,v in expected.items():
        comparisons.append({"output":k,"expected":v,"actual":actual.get(k),"matches":close(v,actual.get(k),abs_tol,rel_tol)})
    ok=all(x['matches'] for x in comparisons)
    lines += [f"Estado: **{'COINCIDE' if ok else 'DIVERGE'}**",f"- Hoja/fila: `{config['sheet']}!{row}`",f"- Tolerancia absoluta: `{abs_tol}`",f"- Tolerancia relativa: `{rel_tol}`", "", "## Comparación"]
    for x in comparisons:lines.append(f"- `{x['output']}`: esperado `{x['expected']}`, código `{x['actual']}`, coincide `{x['matches']}`")
    if not ok and isinstance(actual.get('_stages'),dict):
        lines += ["", "## Etapas intermedias devueltas por el adaptador"]
        lines += [f"- `{k}`: `{compact(v,500)}`" for k,v in actual['_stages'].items()]
    write_text(Path(output_dir)/"08_reconciliacion.md","\n".join(lines))
    return {"status":"MATCH" if ok else "DIVERGE","comparisons":comparisons,"inputs":inputs,"actual":actual}
