from __future__ import annotations

import json
import re
import ast
from pathlib import Path
from typing import Any

from .project_scan import read_code_text
from .utils import compact, dump_json, write_text


VALID_VERDICTS = {
    "EQUIVALENTE",
    "DIFIERE",
    "NO_LOCALIZADO",
    "NO_VERIFICABLE",
    "NO_APLICA_CONTROL",
    "SOLO_EN_CODIGO"
}


SYSTEM = """
Eres un revisor especializado en comparar reglas extraídas de Excel
contra implementaciones en un repositorio Python.

Veredictos permitidos:

- EQUIVALENTE
- DIFIERE
- NO_LOCALIZADO
- NO_VERIFICABLE
- NO_APLICA_CONTROL
- SOLO_EN_CODIGO

Definiciones:

EQUIVALENTE:
Se encontró una implementación funcionalmente equivalente, aunque la
sintaxis o los nombres sean diferentes.

DIFIERE:
Se encontró una implementación concreta en el código, pero contradice
la lógica, los parámetros, el orden de operaciones o las condiciones
del Excel.

NO_LOCALIZADO
Se revisó la evidencia recibida, pero no se encontró una implementación
relacionada. Esto no demuestra que la lógica no exista en todo el proyecto.

NO_VERIFICABLE:
Faltan archivos, dependencias, contexto, contenido completo o información
suficiente para llegar a una conclusión.

NO_APLICA_CONTROL:
La fórmula del Excel es un control de validación, una comparación auxiliar
o una comprobación manual. No es una regla que necesariamente deba existir
en el código productivo.

SOLO_EN_CODIGO:
Se detectó lógica relevante en el código que no tiene una regla equivalente
en el Excel.

Reglas obligatorias:

1. No inventes evidencia.
2. La similitud de nombres no prueba equivalencia.
3. La ausencia de coincidencias no prueba que algo no esté implementado.
4. Usa DIFIERE únicamente cuando exista evidencia concreta de una
   implementación contradictoria.
5. Si faltan módulos importados o archivos necesarios, usa NO_VERIFICABLE.
6. Si la regla tiene formula_type CONTROL_VALIDACION, usa
   NO_APLICA_CONTROL, salvo que exista una razón clara y documentada
   para evaluarla como lógica productiva.
7. Evalúa equivalencia funcional, no igualdad textual.
8. Revisa constantes, funciones, condiciones, parámetros, operadores,
   orden de cálculos y archivos de configuración.
9. Cada correspondencia debe citar archivos y evidencia breve.
10. Devuelve exclusivamente JSON válido.
11. No uses Markdown.
12. No agregues texto antes ni después del JSON.
13. Escapa correctamente comillas, barras y saltos de línea.
14. No declares EQUIVALENTE por compartir operaciones matemáticas
generales como dot, log, maximum, clip, where o power.

15. Para declarar EQUIVALENTE deben coincidir:
- variables de entrada o su mapeo documentado;
- parámetros o coeficientes;
- operadores;
- orden de las operaciones;
- condiciones;
- salida funcional.

16. Si solo existe similitud estructural o matemática parcial,
usa NO_VERIFICABLE.

17. No compares una regla EAD contra lógica de capital, PD, LGD,
saldos u otro módulo, salvo que exista una llamada o mapeo explícito
que demuestre que forma parte del mismo cálculo.

18. No afirmes que un archivo no existe o no fue proporcionado.
Solo puedes decir que no fue incluido en la evidencia de la regla.
Devuelve exactamente esta estructura:

19. Una diferencia en la representación de entrada no demuestra una
diferencia funcional. Excel puede usar códigos numéricos mientras Python
consume una categoría textual generada previamente.

20. Cuando Excel utilice códigos y Python categorías, busca una
transformación o catálogo que conecte ambas representaciones.

21. Si el mapeo entre códigos y categorías no está incluido en la
evidencia, usa NO_VERIFICABLE. No uses DIFIERE.

22. Usa DIFIERE únicamente si puedes citar un caso concreto de entrada
para el cual Excel y Python producen resultados distintos.

23. La coincidencia de números aislados en archivos CSV no prueba una
correspondencia. Los números deben aparecer asociados explícitamente a
la variable, condición o categoría evaluada.

24. No interpretes números contenidos en nombres de columnas, como t18,
t20 o segment22, como códigos de negocio equivalentes a constantes de
una fórmula Excel.

{
  "correspondences": [
    {
      "rule_id": "XL-0001",
      "verdict": "EQUIVALENTE",
      "files": ["ruta/archivo.py"],
      "evidence": "fragmento breve o descripción concreta",
      "explanation": "explicación técnica breve",
      "confidence": 0.95
    }
  ],
  "code_only": [],
  "unverified_zones": []
}
"""


def _extract_rule_terms(
    rule: dict
) -> set[str]:
    """
    Extrae términos útiles de una regla para localizar
    archivos relacionados en el proyecto.
    """
    terms: set[str] = set()

    fields = [
        rule.get("header", ""),
        rule.get("canonical_formula", ""),
        rule.get("natural_language", ""),
        rule.get("formula_type", "")
    ]

    for field in fields:
        text = str(field).lower()

        for token in re.findall(
            r"[a-záéíóúñ_][a-záéíóúñ0-9_]{2,}",
            text
        ):
            terms.add(token)

    ignored_terms = {
        "abs",
        "fila",
        "filas",
        "columna",
        "columnas",
        "formula",
        "fórmula",
        "calculo",
        "cálculo",
        "modelo",
        "regla",
        "valor",
        "valores",
        "actual",
        "anterior",
        "siguiente",
        "true",
        "false",
        "if",
        "and",
        "or",
        "max",
        "min",
        "sum",
        "ln",
        "con",
        "del",
        "por",
        "para",
        "los",
        "las",
        "uno",
        "una",
        "entre",
        "más",
        "mas",
        "máximo",
        "maximo",
        "natural",
        "multiplicado",
        "diferencia",
        "producto",
        "escalar",
        "horizontal",
        "hoja1",
        "calcula",
        "coeficiente",
        "coeficientes",
        "calculo_modelo",
        "r_abs",
        "c_abs"
    }   

    return {
        term
        for term in terms
        if term not in ignored_terms
        and len(term) >= 3
    }


def _read_candidate(
    project_root: Path,
    candidate: dict
) -> tuple[Path, str] | None:
    """
    Lee un archivo candidato de manera segura.
    """
    candidate_path = Path(
        candidate.get(
            "path",
            ""
        )
    )

    path = (
        project_root
        / candidate_path
    )

    try:
        if not path.is_file():
            return None

        text = read_code_text(path)

        if not text:
            return None

        return path, text

    except (
        FileNotFoundError,
        PermissionError,
        OSError
    ):
        return None

def _extract_relevant_snippets(
    text: str,
    terms,
    max_chars: int = 12000,
    context_lines: int = 20
) -> str:
    """
    Extrae fragmentos alrededor de los términos relevantes.

    Evita descartar archivos grandes completos, como utils.py.
    """
    lines = text.splitlines()

    normalized_terms = [
        str(term).lower()
        for term in terms
        if term
    ]

    matching_lines = []

    for index, line in enumerate(lines):
        lower_line = line.lower()

        if any(
            term in lower_line
            for term in normalized_terms
        ):
            matching_lines.append(
                index
            )

    if not matching_lines:
        return text[:max_chars]

    selected_indexes = set()

    for index in matching_lines:
        start = max(
            0,
            index - context_lines
        )

        end = min(
            len(lines),
            index + context_lines + 1
        )

        selected_indexes.update(
            range(start, end)
        )

    snippets = []
    previous_index = None

    for index in sorted(selected_indexes):
        if (
            previous_index is not None
            and index > previous_index + 1
        ):
            snippets.append(
                "\n# ... fragmento omitido ...\n"
            )

        snippets.append(
            f"{index + 1}: {lines[index]}"
        )

        current_text = "\n".join(
            snippets
        )

        if len(current_text) >= max_chars:
            break

        previous_index = index

    return "\n".join(
        snippets
    )[:max_chars]

def _extract_python_functions(
    text: str,
    function_names,
    max_chars: int = 18000
) -> str:
    """
    Extrae funciones o métodos Python completos usando AST.
    No corta una función a la mitad.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return ""

    lines = text.splitlines()

    normalized_names = {
        str(name).lower()
        for name in function_names
        if name
    }

    blocks = []
    used_chars = 0

    for node in ast.walk(tree):
        if not isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef
            )
        ):
            continue

        node_name = node.name.lower()

        matched = any(
            term == node_name
            or term in node_name
            or node_name in term
            for term in normalized_names
        )

        if not matched:
            continue

        start = node.lineno - 1
        end = getattr(
            node,
            "end_lineno",
            node.lineno
        )

        block = (
            f"# FUNCIÓN COMPLETA: {node.name}\n"
            + "\n".join(
                lines[start:end]
            )
        )

        if used_chars + len(block) > max_chars:
            continue

        blocks.append(
            block
        )

        used_chars += len(
            block
        )

    return "\n\n".join(
        blocks
    )

def _evidence_text_for_file(
    path: Path,
    text: str,
    matched_terms,
    max_chars: int = 18000
) -> str:
    """
    Para archivos Python intenta extraer funciones completas.
    Para archivos de parámetros conserva el contenido disponible.
    """
    if path.suffix.lower() != ".py":
        return text[:max_chars]

    function_terms = set(
        matched_terms
    )

    path_lower = str(
        path
    ).replace(
        "\\",
        "/"
    ).lower()

    if path_lower.endswith(
        "source/engine/utils.py"
    ):
        function_terms.update({
            "ead_transform",
            "ead_predict",
            "calcula_ing_bci_acot",
            "calcula_l_ing_bci_medio_acot",
            "calcula_l_ing_bci_acot",
            "calcula_edad_acot",
            "calcula_flg_sur",
            "calcula_flg_centro",
            "calcula_rt_pmactivo_max_6_24",
            "calcula_rt_util_24_acot"
        })

    elif path_lower.endswith(
        "source/engine/curves_all.py"
    ):
        function_terms.update({
            "transform",
            "predict"
        })

    elif path_lower.endswith(
        "source/engine/clv_engine.py"
    ):
        function_terms.update({
            "__init__",
            "transform",
            "predict"
        })

    extracted = _extract_python_functions(
        text=text,
        function_names=function_terms,
        max_chars=max_chars
    )

    if extracted:
        return extracted

    return _extract_relevant_snippets(
        text=text,
        terms=matched_terms,
        max_chars=max_chars,
        context_lines=30
    )

def build_evidence_for_rule(
    project_root,
    rule,
    candidates,
    max_chars=50000,
    max_files=12
):
    """
    Selecciona evidencia específica para una regla.

    No manda los primeros archivos del proyecto de forma global.
    Prioriza archivos que contienen términos, constantes o referencias
    relacionadas con la regla.
    """
    project_root = Path(
        project_root
    )

    terms = _extract_rule_terms(
        rule
    )

    formula = str(
        rule.get(
            "canonical_formula",
            ""
        )
    )

    canonical_formula_lower = (
        formula.lower()
    )

    signature = rule.get(
        "signature",
        {}
    )

    formula_functions = {
        str(function).upper()
        for function in signature.get(
            "functions",
            []
        )
    }

    # Enriquecer los términos usando la estructura matemática
    if "SUMPRODUCT" in formula_functions:
        terms.update({
            "dot",
            "np.dot",
            "theta",
            "beta",
            "predict"
        })

    if "LN" in formula_functions:
        terms.update({
            "log",
            "np.log",
            "logaritmo"
        })

    if "MAX" in formula_functions:
        terms.update({
            "maximum",
            "np.maximum",
            "clip"
        })

    # La presencia de variables de ingreso o BEX orienta la búsqueda
    # hacia el flujo EAD de este proyecto.
    if (
        "ing_bci" in canonical_formula_lower
        or "bex" in canonical_formula_lower
    ):
        terms.update({
            "ead",
            "curveead",
            "ead_transform",
            "ead_predict",
            "calcula_ing_bci_acot",
            "calcula_l_ing_bci_medio_acot",
            "calcula_l_ing_bci_acot",
            "calcula_flg_sur",
            "calcula_flg_centro",
            "calcula_rt_pmactivo_max_6_24",
            "calcula_rt_util_24_acot"
        })

    formula_numbers = set(
        re.findall(
            r"(?<![A-Za-z_])"
            r"[-+]?\d+(?:\.\d+)?"
            r"(?:E[-+]?\d+)?",
            formula,
            flags=re.IGNORECASE
        )
    )

    scored_files = []

    for candidate in candidates:
        loaded = _read_candidate(
            project_root,
            candidate
        )

        if loaded is None:
            continue

        path, text = loaded
        lower_text = text.lower()

        try:
            relative_path = path.relative_to(
                project_root
            )
        except ValueError:
            relative_path = path

        searchable_path = str(
            relative_path
        ).lower()

        matched_terms = sorted(
            term
            for term in terms
            if (
                term in lower_text
                or term in searchable_path
            )
        )

        matched_numbers = sorted(
            number
            for number in formula_numbers
            if number in text
        )

        lexical_score = (
            len(matched_terms)
            * 20
        )

        numeric_score = (
            len(matched_numbers)
            * 4
        )

        candidate_score = float(
            candidate.get(
                "score",
                0
            )
        )

        total_score = (
            candidate_score
            + lexical_score
            + numeric_score
        )

        suffix = path.suffix.lower()

        if suffix in {
            ".json",
            ".yaml",
            ".yml",
            ".csv",
            ".toml",
            ".ini",
            ".cfg"
        }:
            total_score += 5

        # Priorizar componentes conectados al flujo EAD
        relative_text = str(
            relative_path
        ).replace(
            "\\",
            "/"
        ).lower()

        priority_paths = {
            "source/engine/utils.py": 100,
            "source/engine/curves_all.py": 80,
            "source/engine/clv_engine.py": 70,
            "data/params/modulo_riesgos/ead_thetat.csv": 70,
            "data/params/hyperparams/general_params.json": 40
        }

        domain_terms = {
            "ead",
            "curveead",
            "ead_transform",
            "ead_predict",
            "ing_bci",
            "calcula_ing_bci_acot",
            "calcula_l_ing_bci_medio_acot",
            "theta",
            "beta",
            "flg_sur",
            "flg_centro"
        }

        is_ead_related_rule = bool(
            terms.intersection(
                domain_terms
            )
        )

        if is_ead_related_rule:
            priority_bonus = priority_paths.get(
                relative_text,
                0
            )

            total_score += priority_bonus

        if matched_terms:
            scored_files.append({
                "score": total_score,
                "path": path,
                "text": text,
                "matched_terms": matched_terms,
                "matched_numbers": matched_numbers
            })
    if not scored_files:
        for candidate in candidates[:5]:
            loaded = _read_candidate(
                project_root,
                candidate
            )

            if loaded is None:
                continue

            path, text = loaded

            scored_files.append({
                "score": float(
                    candidate.get(
                        "score",
                        0
                    )
                ),
                "path": path,
                "text": text,
                "matched_terms": [],
                "matched_numbers": []
            })

    scored_files.sort(
        key=lambda item: (
            -item["score"],
            str(item["path"])
        )
    )

    blocks = []
    selected_files = []
    used_chars = 0

    for item in scored_files:
        if len(selected_files) >= max_files:
            break

        path = item["path"]
        text = item["text"]

        try:
            relative = path.relative_to(
                project_root
            )
        except ValueError:
            relative = path

        metadata = {
            "score": item["score"],
            "matched_terms": item["matched_terms"],
            "matched_numbers": item["matched_numbers"]
        }

        relevant_text = _evidence_text_for_file(
            path=path,
            text=text,
            matched_terms=(
                item["matched_terms"]
                or terms
            ),
            max_chars=18000
        )

        block = (
            f"\n===== ARCHIVO: {relative} =====\n"
            f"METADATA_BUSQUEDA: "
            f"{json.dumps(metadata, ensure_ascii=False)}\n"
            f"{relevant_text}\n"
        )

        if used_chars + len(block) > max_chars:
            continue

        blocks.append(
            block
        )

        selected_files.append(
            str(relative)
        )

        used_chars += len(
            block
        )

    return {
        "text": "".join(blocks),
        "selected_files": selected_files,
        "terms": sorted(terms),
        "characters": used_chars
    }


def _normalize_files(
    files: Any
) -> list[str]:
    if files is None:
        return []

    if isinstance(
        files,
        str
    ):
        return [files]

    if not isinstance(
        files,
        list
    ):
        return []

    return [
        str(item)
        for item in files
        if item is not None
    ]


def _normalize_response(
    response
):
    """
    Normaliza la respuesta de Haiku y limita los veredictos
    a los permitidos.
    """
    if not isinstance(
        response,
        dict
    ):
        return {
            "correspondences": [],
            "code_only": [],
            "unverified_zones": [
                (
                    "El endpoint no devolvió "
                    "un objeto JSON."
                )
            ]
        }

    raw_correspondences = response.get(
        "correspondences",
        []
    )

    if not isinstance(
        raw_correspondences,
        list
    ):
        raw_correspondences = []

    normalized = []

    for item in raw_correspondences:
        if not isinstance(
            item,
            dict
        ):
            continue

        verdict = str(
            item.get(
                "verdict",
                "NO_VERIFICABLE"
            )
        ).upper().strip()

        if verdict not in VALID_VERDICTS:
            verdict = "NO_VERIFICABLE"

        confidence = item.get(
            "confidence",
            0.0
        )

        try:
            confidence = float(
                confidence
            )
        except (
            TypeError,
            ValueError
        ):
            confidence = 0.0

        confidence = max(
            0.0,
            min(
                1.0,
                confidence
            )
        )

        normalized.append({
            "rule_id": str(
                item.get(
                    "rule_id",
                    "SIN_ID"
                )
            ),
            "verdict": verdict,
            "files": _normalize_files(
                item.get(
                    "files",
                    []
                )
            ),
            "evidence": str(
                item.get(
                    "evidence",
                    ""
                )
            ),
            "explanation": str(
                item.get(
                    "explanation",
                    ""
                )
            ),
            "confidence": confidence
        })

    code_only = response.get(
        "code_only",
        []
    )

    if not isinstance(
        code_only,
        list
    ):
        code_only = []

    unverified_zones = response.get(
        "unverified_zones",
        []
    )

    if not isinstance(
        unverified_zones,
        list
    ):
        unverified_zones = []

    return {
        "correspondences": normalized,
        "code_only": code_only,
        "unverified_zones": unverified_zones
    }

def _apply_verdict_guards(
    response: dict,
    rules_by_id: dict
) -> dict:
    """
    Aplica controles determinísticos después de la respuesta del LLM.

    Evita declarar DIFIERE cuando la supuesta diferencia solamente
    corresponde a representaciones distintas de la entrada y no existe
    evidencia de un mapeo que permita compararlas.
    """
    guarded_correspondences = []

    representation_markers = {
        "códigos numéricos",
        "codigo numérico",
        "código numérico",
        "categoría textual",
        "cadena textual",
        "tipos de datos",
        "mapeo documentado",
        "mapeo explícito",
        "no existe evidencia de un mapeo",
        "sin un catálogo explícito",
        "no puede afirmarse equivalencia"
    }

    concrete_difference_markers = {
        "produce un resultado distinto",
        "producen resultados distintos",
        "para la entrada",
        "caso concreto",
        "valor esperado",
        "valor obtenido",
        "diferencia numérica",
        "parámetro distinto",
        "constante distinta",
        "operador distinto"
    }

    for correspondence in response.get(
        "correspondences",
        []
    ):
        item = dict(
            correspondence
        )

        rule_id = str(
            item.get(
                "rule_id",
                ""
            )
        )

        rule = rules_by_id.get(
            rule_id,
            {}
        )

        verdict = str(
            item.get(
                "verdict",
                ""
            )
        ).upper()

        explanation_text = (
            str(
                item.get(
                    "evidence",
                    ""
                )
            )
            + " "
            + str(
                item.get(
                    "explanation",
                    ""
                )
            )
        ).lower()

        has_representation_issue = any(
            marker in explanation_text
            for marker in representation_markers
        )

        has_concrete_difference = any(
            marker in explanation_text
            for marker in concrete_difference_markers
        )

        # Si la propia respuesta admite que falta el puente entre
        # representaciones, no existe evidencia suficiente para DIFIERE.
        if (
            verdict == "DIFIERE"
            and has_representation_issue
            and not has_concrete_difference
        ):
            original_explanation = str(
                item.get(
                    "explanation",
                    ""
                )
            )

            item["verdict"] = "NO_VERIFICABLE"

            item["explanation"] = (
                "La evidencia muestra representaciones de entrada "
                "diferentes, pero no demuestra una contradicción "
                "funcional. Excel evalúa códigos numéricos y Python "
                "consume una categoría textual derivada. Como no se "
                "incluyó el mapeo entre ambas representaciones ni un "
                "caso concreto donde produzcan salidas distintas, la "
                "regla queda como NO_VERIFICABLE. "
                "Evaluación original del modelo: "
                + original_explanation
            )

            item["confidence"] = min(
                float(
                    item.get(
                        "confidence",
                        0.0
                    )
                ),
                0.65
            )

        # Guardia específica para flags geográficos del Excel.
        # Solo actúa si el motivo de DIFIERE es numérico vs texto.
        header = str(
            rule.get(
                "header",
                ""
            )
        ).upper()

        if (
            item.get("verdict") == "DIFIERE"
            and header in {
                "FLG_SUR",
                "FLG_CENTRO"
            }
            and has_representation_issue
            and not has_concrete_difference
        ):
            item["verdict"] = "NO_VERIFICABLE"

            item["explanation"] = (
                "El Excel calcula el indicador desde un código de "
                "departamento y Python lo calcula desde la categoría "
                "'region'. No se incluyó evidencia del mapeo previo "
                "código-región. La diferencia de representación no "
                "demuestra que las salidas sean contradictorias."
            )

            item["confidence"] = min(
                float(
                    item.get(
                        "confidence",
                        0.0
                    )
                ),
                0.65
            )

        guarded_correspondences.append(
            item
        )

    result = dict(
        response
    )

    result["correspondences"] = (
        guarded_correspondences
    )

    return result

def _control_correspondence(
    rule: dict
) -> dict:
    """
    Convierte directamente una fórmula de control en NO_APLICA_CONTROL.
    No necesita consumir una llamada al modelo.
    """
    return {
        "rule_id": rule.get(
            "rule_id",
            "SIN_ID"
        ),
        "verdict": "NO_APLICA_CONTROL",
        "files": [],
        "evidence": (
            rule.get(
                "canonical_formula",
                ""
            )
        ),
        "explanation": (
            "La fórmula fue clasificada como CONTROL_VALIDACION. "
            "Corresponde a una comprobación dentro del Excel y no "
            "se exige su existencia literal en el código productivo."
        ),
        "confidence": 1.0
    }


def _missing_response_correspondence(
    rule: dict,
    message: str
) -> dict:
    return {
        "rule_id": rule.get(
            "rule_id",
            "SIN_ID"
        ),
        "verdict": "NO_VERIFICABLE",
        "files": [],
        "evidence": "",
        "explanation": message,
        "confidence": 0.0
    }


def _build_batch_payload(
    project_root,
    batch_rules,
    candidates,
    max_chars_per_rule
):
    items = []

    for rule in batch_rules:
        evidence = build_evidence_for_rule(
            project_root=project_root,
            rule=rule,
            candidates=candidates,
            max_chars=max_chars_per_rule
        )

        items.append({
            "rule": rule,
            "evidence": {
                "selected_files": (
                    evidence[
                        "selected_files"
                    ]
                ),
                "search_terms": (
                    evidence[
                        "terms"
                    ]
                ),
                "content": (
                    evidence[
                        "text"
                    ]
                )
            }
        })

    return {
        "items": items
    }


def build_mapping(
    project_root,
    rules,
    candidates,
    llm,
    output_dir,
    max_chars=40000,
    batch_size=1
):
    """
    Compara reglas del Excel contra evidencia seleccionada
    específicamente para cada regla.
    """
    project_root = Path(
        project_root
    )

    output_dir = Path(
        output_dir
    )

    raw_dir = (
        output_dir
        / "artifacts"
        / "mapping_batches"
    )

    raw_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    all_correspondences = []
    all_code_only = []
    all_unverified_zones = []

    controls = []
    applicable_rules = []

    for rule in rules:
        formula_type = str(
            rule.get(
                "formula_type",
                ""
            )
        ).upper()

        if formula_type == "CONTROL_VALIDACION":
            controls.append(
                rule
            )
        else:
            applicable_rules.append(
                rule
            )

    for rule in controls:
        all_correspondences.append(
            _control_correspondence(
                rule
            )
        )

    if not llm:
        for rule in applicable_rules:
            all_correspondences.append(
                _missing_response_correspondence(
                    rule,
                    (
                        "La IA estaba deshabilitada. "
                        "La regla no pudo evaluarse."
                    )
                )
            )

        all_unverified_zones.append(
            "Comparación semántica no ejecutada."
        )

    else:
        for start in range(
            0,
            len(applicable_rules),
            batch_size
        ):
            batch_number = (
                start // batch_size
            ) + 1

            batch_rules = applicable_rules[
                start:start + batch_size
            ]

            payload = _build_batch_payload(
                project_root=project_root,
                batch_rules=batch_rules,
                candidates=candidates,
                max_chars_per_rule=max_chars
            )

            input_path = (
                raw_dir
                / (
                    f"batch_{batch_number:04d}"
                    "_input.json"
                )
            )

            dump_json(
                input_path,
                payload
            )

            try:
                response = llm.chat(
                    SYSTEM,
                    json.dumps(
                        payload,
                        ensure_ascii=False,
                        default=str
                    ),
                    json_mode=True
                )

                response = _normalize_response(
                    response
                )
                rules_by_id = {
                    str(
                        rule.get(
                            "rule_id",
                            ""
                        )
                    ): rule
                    for rule in batch_rules
                }

                response = _apply_verdict_guards(
                    response=response,
                    rules_by_id=rules_by_id
                )
                
                response_path = (
                    raw_dir
                    / (
                        f"batch_{batch_number:04d}"
                        "_response.json"
                    )
                )

                dump_json(
                    response_path,
                    response
                )

                response_by_rule = {
                    item.get(
                        "rule_id"
                    ): item
                    for item in response[
                        "correspondences"
                    ]
                }

                for rule in batch_rules:
                    rule_id = rule.get(
                        "rule_id",
                        "SIN_ID"
                    )

                    correspondence = (
                        response_by_rule.get(
                            rule_id
                        )
                    )

                    if correspondence is None:
                        correspondence = (
                            _missing_response_correspondence(
                                rule,
                                (
                                    "El modelo no devolvió "
                                    "una correspondencia para "
                                    f"la regla {rule_id}."
                                )
                            )
                        )

                    all_correspondences.append(
                        correspondence
                    )

                all_code_only.extend(
                    response.get(
                        "code_only",
                        []
                    )
                )

                all_unverified_zones.extend(
                    response.get(
                        "unverified_zones",
                        []
                    )
                )

            except Exception as exc:
                error_message = (
                    f"Lote {batch_number}: "
                    f"{type(exc).__name__}: "
                    f"{exc}"
                )

                all_unverified_zones.append(
                    error_message
                )

                error_path = (
                    raw_dir
                    / (
                        f"batch_{batch_number:04d}"
                        "_error.txt"
                    )
                )

                write_text(
                    error_path,
                    error_message
                )

                for rule in batch_rules:
                    all_correspondences.append(
                        _missing_response_correspondence(
                            rule,
                            error_message
                        )
                    )

    result = {
        "correspondences": (
            all_correspondences
        ),
        "code_only": (
            all_code_only
        ),
        "unverified_zones": (
            all_unverified_zones
        )
    }

    dump_json(
        output_dir
        / "artifacts"
        / "mapping.json",
        result
    )

    lines = [
        "# Tabla de correspondencia",
        "",
        (
            "Veredictos permitidos: "
            "`EQUIVALENTE`, `DIFIERE`, "
            "`NO_LOCALIZADO`, `NO_VERIFICABLE`, "
            "`NO_APLICA_CONTROL`, "
            "`SOLO_EN_CODIGO`."
        ),
        ""
    ]

    for item in result.get(
        "correspondences",
        []
    ):
        files = _normalize_files(
            item.get(
                "files",
                []
            )
        )

        files_text = (
            ", ".join(files)
            if files
            else "ninguno"
        )

        lines.extend([
            (
                f"## "
                f"{item.get('rule_id', 'SIN_ID')} · "
                f"{item.get('verdict', '')}"
            ),
            (
                "- Archivos: "
                f"{files_text}"
            ),
            (
                "- Evidencia: "
                + compact(
                    item.get(
                        "evidence",
                        ""
                    ),
                    1000
                )
            ),
            (
                "- Explicación: "
                + str(
                    item.get(
                        "explanation",
                        ""
                    )
                )
            ),
            (
                "- Confianza: "
                + str(
                    item.get(
                        "confidence",
                        ""
                    )
                )
            ),
            ""
        ])

    lines.append(
        "## Solo en código"
    )

    if all_code_only:
        for item in all_code_only:
            lines.append(
                f"- {compact(item, 600)}"
            )
    else:
        lines.append(
            "- Ningún elemento registrado."
        )

    lines.extend([
        "",
        "## Zonas no verificadas"
    ])

    if all_unverified_zones:
        for zone in all_unverified_zones:
            if isinstance(
                zone,
                dict
            ):
                location = (
                    zone.get("file")
                    or zone.get("location")
                    or zone.get("zone")
                    or "Ubicación no indicada"
                )

                reason = (
                    zone.get("reason")
                    or zone.get("explanation")
                    or str(zone)
                )

                lines.append(
                    f"- `{location}` · {reason}"
                )
            else:
                lines.append(
                    f"- {zone}"
                )
    else:
        lines.append(
            "- Ninguna registrada."
        )

    write_text(
        output_dir
        / "07_correspondencia.md",
        "\n".join(lines)
    )

    return result