# COMMAND ----------
import importlib

import excel_code_compare.formulas
import excel_code_compare.mapping
import excel_code_compare.report
import excel_code_compare.cli

importlib.reload(
    excel_code_compare.formulas
)

importlib.reload(
    excel_code_compare.mapping
)

importlib.reload(
    excel_code_compare.report
)

importlib.reload(
    excel_code_compare.cli
)

print("Módulos recargados")
# COMMAND ----------
%pip install openpyxl PyYAML requests databricks-sdk
# COMMAND ----------
import sys
from pathlib import Path

# Carpeta raíz donde están:
# excel_code_compare/, notebooks/, tests/, README.md, etc.
COMPARADOR_ROOT = Path(
    "/Workspace/Users/eduardosaldana@bcp.com.pe/agente comparador"
)

PACKAGE_PATH = (
    COMPARADOR_ROOT
    / "excel_code_compare"
    / "__init__.py"
)

# Agregar la raíz al buscador de módulos de Python
if str(COMPARADOR_ROOT) not in sys.path:
    sys.path.insert(0, str(COMPARADOR_ROOT))

print("Raíz del comparador:", COMPARADOR_ROOT)
print("Paquete encontrado:", PACKAGE_PATH.exists())

assert PACKAGE_PATH.exists(), (
    "No se encontró el paquete excel_code_compare en: "
    f"{PACKAGE_PATH}"
)

print("Comparador listo para importar")
# COMMAND ----------
import yaml

from pathlib import Path


config = {
    "excel_path": (
        "/dbfs/FileStore/comparador/input/"
        "calculadora_final.xlsx"
    ),

    "project_root": (
        "/Workspace/Users/eduardosaldana@bcp.com.pe/"
        "proyecto/"
        "prdl-app-clv-pyme-ct-af-modelos-feature-inicial"
    ),

    "output_dir": (
        "/dbfs/FileStore/comparador/output"
    ),

    "excel": {
        "header_scan_rows": 50,
        "parameter_density_threshold": 0.65,
        "max_cells_for_llm_sample": 500
    },

    "project": {
        "include_extensions": [
            ".py",
            ".json",
            ".yaml",
            ".yml",
            ".toml",
            ".ini",
            ".cfg",
            ".sql",
            ".csv",
            ".md",
            ".txt",
            ".ipynb"
        ],

        "exclude_dirs": [
            ".git",
            "tests",
            "test",
            "mocks",
            "mock",
            "__pycache__",
            ".venv",
            "venv",
            "env",
            ".tox",
            ".mypy_cache",
            ".pytest_cache",
            "site-packages"
        ],

        "max_file_bytes": 2_000_000
    },

    "llm": {
        "enabled": True,
        "endpoint": (
            "databricks-claude-haiku-4-5"
        ),
        "temperature": 0.0,
        "max_tokens": 8000,
        "timeout_seconds": 180,
        "batch_rules": 25
    },

    "reconciliation": {
        "enabled": True,

        # El comparador intenta determinar qué clase
        # de reconciliación es técnicamente viable.
        "mode": "auto",

        # Si no encuentra una estrategia confiable,
        # devuelve NOT_RUN y no fuerza una comparación.
        "on_unresolved_strategy": "not_run",

        "parameter_discovery": {
            "enabled": True,

            # Buscar en todo el repositorio, no asumir
            # que siempre existe data/params.
            "search_paths": [
                "."
            ],

            "include_extensions": [
                ".csv",
                ".json",
                ".yaml",
                ".yml",
                ".toml",
                ".ini",
                ".cfg"
            ],

            "exclude_paths": [
                ".git",
                "tests",
                "test",
                "mocks",
                "mock",
                "__pycache__",
                ".venv",
                "venv",
                "site-packages",
                "data/logs"
            ],

            "max_file_bytes": 2_000_000,

            # La selección se basa en estructura.
            "minimum_name_coverage": 0.70,
            "minimum_confidence": 0.70,
            "ambiguity_margin": 0.03,

            # Los valores sirven para detectar diferencias,
            # no para escoger el archivo.
            "use_values_for_selection": False,
            "use_values_for_validation": True,

            # Alias generales únicamente.
            "aliases": {
                "intercept": [
                    "intercepto",
                    "constant",
                    "const"
                ],

                "flag": [
                    "flg",
                    "indicator",
                    "indicador"
                ],

                "coefficient": [
                    "coef",
                    "beta",
                    "parameter",
                    "parametro"
                ]
            }
        },

        "strategy_discovery": {
            "enabled": True,

            # Estrategias que el motor puede considerar.
            "allowed_strategies": [
                "parameter_table_comparison",
                "formula_recalculation",
                "scalar_output_comparison",
                "tabular_output_comparison"
            ],

            # No ejecutar código arbitrario automáticamente.
            "allow_dynamic_import": False,

            # Una función productiva solo se ejecuta si un
            # adaptador explícito la describe.
            "require_adapter_for_function_execution": True,

            "minimum_confidence": 0.80
        },

        "tolerances": {
            "absolute": 1.0e-8,
            "relative": 1.0e-6
        },

        # Sin adaptador específico para este primer análisis.
        "adapter": None
    }
}


CONFIG_PATH = Path(
    "/tmp/config_comparador.yaml"
)

CONFIG_PATH.write_text(
    yaml.safe_dump(
        config,
        allow_unicode=True,
        sort_keys=False
    ),
    encoding="utf-8"
)

print(
    "Config creado en:",
    CONFIG_PATH
)
# COMMAND ----------
from excel_code_compare.cli import main
import sys

sys.argv = [
    "excel-code-compare",
    "--config",
    str(CONFIG_PATH)
]

main()
# COMMAND ----------
display(
    dbutils.fs.ls(
        "dbfs:/FileStore/comparador/output"
    )
)