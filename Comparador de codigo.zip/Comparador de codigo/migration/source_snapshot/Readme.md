# Comparador Excel vs. repositorio Python

Pipeline agnóstico para inventariar un Excel, extraer y canonizar fórmulas, localizar implementaciones candidatas en un repositorio Python, construir un grafo AST, generar una tabla de correspondencia asistida por un endpoint de Databricks y reconciliar numéricamente mediante un adaptador ejecutable.

## Salidas

- `01_mapa_excel.md`
- `02_celdas.csv`
- `03_reglas_excel.md`
- `04_parametros.json`
- `05_candidatos.md`
- `06_grafo.md`
- `07_correspondencia.md`
- `08_reconciliacion.md`
- `resultado_final.md`
- carpeta `artifacts/` con JSON intermedios

## Instalación en Databricks

```python
%pip install -r requirements.txt
```

Reinicia Python después de instalar librerías si el notebook lo solicita.

## Configuración

Copia `config.example.yaml` como `config.yaml` y ajusta:

- `excel_path`: ruta del Excel en `/Workspace`, `/Volumes` o ruta local accesible.
- `project_root`: raíz del repositorio Python.
- `output_dir`: carpeta de resultados.
- `llm.endpoint`: nombre exacto del endpoint de Model Serving. El código no presupone que el endpoint se llame Haiku.
- `reconciliation.adapter`: función importable `modulo:funcion` que recibe un diccionario con entradas y devuelve un diccionario con resultados.

Autenticación, en este orden:

1. `DATABRICKS_HOST` y `DATABRICKS_TOKEN`.
2. Credenciales resueltas por `databricks-sdk` dentro del workspace.

## Ejecución

```bash
python -m excel_code_compare.cli --config config.yaml
```

Para omitir la IA temporalmente:

```bash
python -m excel_code_compare.cli --config config.yaml --no-llm
```

## Reconciliación numérica

La ejecución automática de cualquier repositorio no puede inferirse con seguridad solo leyendo archivos. Por ello, la fase 6 usa un adaptador explícito. Ejemplo:

```python
# mi_adaptador.py
def ejecutar(inputs: dict) -> dict:
    from source.modelo import calcular
    return calcular(inputs)
```

En `config.yaml`:

```yaml
reconciliation:
  enabled: true
  adapter: "mi_adaptador:ejecutar"
  sheet: "Hoja1"
  row: 5
  input_columns: ["PD", "EAD", "LGD"]
  expected_columns: ["PERDIDA_ESPERADA"]
```

El pipeline compara con tolerancia absoluta y relativa `1e-6`. Si el adaptador devuelve etapas en `_stages`, también reporta la primera etapa divergente.

## Alcances importantes

- `openpyxl` no calcula fórmulas. `data_only=True` solo lee valores cacheados guardados previamente por Excel.
- El grafo AST es estático. Las llamadas dinámicas, reflexión, `eval`, monkey patching o dispatch de frameworks pueden quedar como no resueltas.
- Los notebooks `.ipynb` se indexan como código para búsqueda, pero el grafo AST principal se limita a `.py`.
- El veredicto final conserva zonas no verificadas y no convierte ausencia de evidencia en cumplimiento.
