from excel_code_compare.formulas import canonicalize

def test_relative_rows():
    headers={4:'PD',5:'EAD',6:'LGD'}
    got=canonicalize('=D5*E5*F5',5,headers,'Hoja1')
    assert got=='={PD}[+0]*{EAD}[+0]*{LGD}[+0]'

def test_offsets():
    headers={4:'PD'}
    assert canonicalize('=D4+D5+$D$2',5,headers,'H')=='={PD}[-1]+{PD}[+0]+{PD}ABS[2]'
