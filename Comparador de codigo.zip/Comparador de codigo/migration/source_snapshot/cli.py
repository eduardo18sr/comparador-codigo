from __future__ import annotations

import argparse
import os

from pathlib import Path

import yaml

from openpyxl import load_workbook

from .utils import ensure_dir
from .llm import DatabricksChatClient
from .excel_inventory import inventory_excel
from .formulas import extract_rules
from .project_scan import find_candidates
from .callgraph import build_callgraph
from .mapping import build_mapping
from .reconciliation import run_reconciliation
from .report import final_report

from datetime import datetime
from time import perf_counter


def print_phase(
    phase_number,
    phase_name,
    status="INICIANDO",
    started_at=None,
    detail=None
):
    """
    Muestra avances del pipeline inmediatamente en Databricks.
    """
    timestamp = datetime.now().strftime(
        "%H:%M:%S"
    )

    message = (
        f"[{timestamp}] "
        f"FASE {phase_number} | "
        f"{status} | "
        f"{phase_name}"
    )

    if (
        status == "COMPLETADA"
        and started_at is not None
    ):
        elapsed_seconds = (
            perf_counter()
            - started_at
        )

        message += (
            f" | {elapsed_seconds:.2f} s"
        )

    if detail:
        message += (
            f" | {detail}"
        )

    print(
        message,
        flush=True
    )

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--config",
        required=True
    )

    parser.add_argument(
        "--no-llm",
        action="store_true"
    )

    args = parser.parse_args()

    print(
        "=" * 90,
        flush=True
    )

    print(
        "EXCEL CODE COMPARE",
        flush=True
    )

    print(
        "=" * 90,
        flush=True
    )

    # =====================================================
    # FASE 0: CARGAR CONFIGURACIÓN
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        0,
        "Carga y validación de configuración"
    )

    config_path = Path(
        args.config
    )

    cfg = yaml.safe_load(
        config_path.read_text(
            encoding="utf-8"
        )
    )

    if not isinstance(
        cfg,
        dict
    ):
        raise ValueError(
            "El archivo de configuración no contiene "
            "un objeto YAML válido."
        )

    excel_path = Path(
        cfg["excel_path"]
    )

    project_root = Path(
        cfg["project_root"]
    )

    output_dir = ensure_dir(
        cfg["output_dir"]
    )

    ensure_dir(
        output_dir
        / "artifacts"
    )

    print_phase(
        0,
        "Carga y validación de configuración",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"Excel: {excel_path.name}"
        )
    )

    # =====================================================
    # FASE 1: CONFIGURAR LLM
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        1,
        "Configuración del cliente LLM"
    )

    llm = None

    llm_enabled = bool(
        cfg.get(
            "llm",
            {}
        ).get(
            "enabled",
            True
        )
        and not args.no_llm
    )

    if llm_enabled:
        llm_config = cfg.get(
            "llm",
            {}
        )

        llm = DatabricksChatClient(
            databricks_chat_endpoint=(
                llm_config.get(
                    "endpoint"
                )
                or os.getenv(
                    "DATABRICKS_CHAT_ENDPOINT"
                )
                or "databricks-claude-haiku-4-5"
            ),
            temperature=llm_config.get(
                "temperature",
                0.0
            ),
            max_tokens=llm_config.get(
                "max_tokens",
                6000
            ),
            timeout=llm_config.get(
                "timeout_seconds",
                180
            )
        )

    print_phase(
        1,
        "Configuración del cliente LLM",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            "LLM habilitado"
            if llm_enabled
            else "LLM deshabilitado"
        )
    )

    # =====================================================
    # FASE 2: INVENTARIO DEL EXCEL
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        2,
        "Inventario y lectura del Excel"
    )

    (
        wb_formula,
        inventory,
        raw_cells
    ) = inventory_excel(
        excel_path,
        output_dir
    )

    wb_values = load_workbook(
        excel_path,
        data_only=True,
        read_only=False,
        keep_links=True
    )

    print_phase(
        2,
        "Inventario y lectura del Excel",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"{len(wb_formula.sheetnames)} hojas"
        )
    )

    # =====================================================
    # FASE 3: EXTRAER REGLAS
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        3,
        "Extracción y clasificación de reglas Excel"
    )

    rules, parameters = extract_rules(
        wb=wb_formula,
        raw_cells=raw_cells,
        output_dir=output_dir,
        llm=llm,
        scan_rows=(
            cfg.get(
                "excel",
                {}
            ).get(
                "header_scan_rows",
                30
            )
        ),
        batch_size=(
            cfg.get(
                "llm",
                {}
            ).get(
                "batch_rules",
                25
            )
        )
    )

    print_phase(
        3,
        "Extracción y clasificación de reglas Excel",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"{len(rules)} reglas | "
            f"{len(parameters)} parámetros"
        )
    )

    # =====================================================
    # FASE 4: ESCANEAR PROYECTO
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        4,
        "Búsqueda de candidatos en el repositorio"
    )

    candidates = find_candidates(
        project_root,
        rules,
        parameters,
        cfg["project"],
        output_dir
    )

    print_phase(
        4,
        "Búsqueda de candidatos en el repositorio",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"{len(candidates)} candidatos"
        )
    )

    # =====================================================
    # FASE 5: CONSTRUIR GRAFO
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        5,
        "Construcción del grafo de llamadas"
    )

    build_callgraph(
        project_root,
        cfg["project"],
        output_dir
    )

    print_phase(
        5,
        "Construcción del grafo de llamadas",
        status="COMPLETADA",
        started_at=phase_start
    )

    # =====================================================
    # FASE 6: MAPPING SEMÁNTICO
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        6,
        "Comparación semántica Excel contra código"
    )

    mapping = build_mapping(
        project_root=project_root,
        rules=rules,
        candidates=candidates,
        llm=llm,
        output_dir=output_dir
    )

    correspondences = mapping.get(
        "correspondences",
        []
    )

    print_phase(
        6,
        "Comparación semántica Excel contra código",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"{len(correspondences)} correspondencias"
        )
    )

    # =====================================================
    # FASE 7: RECONCILIACIÓN NUMÉRICA
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        7,
        "Reconciliación numérica"
    )

    reconciliation = run_reconciliation(
        wb=wb_formula,
        wb_values=wb_values,
        project_root=project_root,
        output_dir=output_dir,
        config=cfg,
        excel_inventory=inventory,
        rules=rules,
        project_candidates=candidates
    )

    numeric_status = reconciliation.get(
        "status",
        "NOT_RUN"
    )

    production_status = (
        reconciliation.get(
            "production_function",
            {}
        ).get(
            "status",
            "NOT_RUN"
        )
    )

    print_phase(
        7,
        "Reconciliación numérica",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"Estado: {numeric_status} | "
            f"Función productiva: {production_status}"
        )
    )

    # =====================================================
    # FASE 8: GENERAR REPORTE FINAL
    # =====================================================

    phase_start = perf_counter()

    print_phase(
        8,
        "Generación del reporte final"
    )

    report_result = final_report(
        mapping=mapping,
        reconciliation=reconciliation,
        output_dir=output_dir
    )

    print_phase(
        8,
        "Generación del reporte final",
        status="COMPLETADA",
        started_at=phase_start,
        detail=(
            f"Archivo: "
            f"{report_result.get('output_path', '')}"
        )
    )

    # =====================================================
    # PROCESO COMPLETADO
    # =====================================================

    print(
        "",
        flush=True
    )

    print(
        "=" * 90,
        flush=True
    )

    print(
        "PROCESO COMPLETADO",
        flush=True
    )

    print(
        f"Resultados: {output_dir}",
        flush=True
    )

    print(
        "Estado de reconciliación: "
        f"{numeric_status}",
        flush=True
    )

    print(
        "Veredicto final: "
        f"{report_result.get('verdict', '')}",
        flush=True
    )

    print(
        "=" * 90,
        flush=True
    )


if __name__ == "__main__":
    main()