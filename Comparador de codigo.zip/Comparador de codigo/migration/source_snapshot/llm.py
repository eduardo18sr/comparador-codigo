from __future__ import annotations

import json
import os
import re
import requests

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DatabricksChatClient:
    databricks_chat_endpoint: str = field(
        default_factory=lambda: os.getenv(
            "DATABRICKS_CHAT_ENDPOINT",
            "databricks-claude-haiku-4-5"
        )
    )

    temperature: float = 0.0
    max_tokens: int = 6000
    timeout: int = 180

    def __post_init__(self):
        self.host, self.headers = self._credentials()

    @property
    def endpoint(self) -> str:
        """
        Mantiene compatibilidad con el resto del proyecto,
        que actualmente utiliza self.endpoint.
        """
        return self.databricks_chat_endpoint

    def _credentials(self):
        host = os.getenv("DATABRICKS_HOST", "").rstrip("/")
        token = os.getenv("DATABRICKS_TOKEN", "")

        if host and token:
            return host, {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }

        try:
            from databricks.sdk import WorkspaceClient

            workspace = WorkspaceClient()

            headers = dict(workspace.config.authenticate())
            headers["Content-Type"] = "application/json"

            return workspace.config.host.rstrip("/"), headers

        except Exception as exc:
            raise RuntimeError(
                "No se pudieron resolver las credenciales de Databricks. "
                "Configura DATABRICKS_HOST y DATABRICKS_TOKEN, o ejecuta "
                "el proyecto dentro de un workspace autenticado."
            ) from exc

    def chat(
        self,
        system: str,
        user: str,
        json_mode: bool = False
    ) -> Any:

        url = (
            f"{self.host}/serving-endpoints/"
            f"{self.databricks_chat_endpoint}/invocations"
        )

        payload = {
            "messages": [
                {
                    "role": "system",
                    "content": system
                },
                {
                    "role": "user",
                    "content": user
                }
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens
        }

        response = requests.post(
            url,
            headers=self.headers,
            json=payload,
            timeout=self.timeout
        )

        response.raise_for_status()

        data = response.json()
        text = self._extract_text(data)

        if json_mode:
            return self._parse_json(text)

        return text

    @staticmethod
    def _extract_text(data: dict) -> str:
        if data.get("choices"):
            choice = data["choices"][0]

            if isinstance(choice.get("message"), dict):
                content = choice["message"].get("content", "")

                if isinstance(content, list):
                    return "".join(
                        item.get("text", "")
                        for item in content
                        if isinstance(item, dict)
                    )

                return str(content)

            return str(choice.get("text", ""))

        if isinstance(data.get("output"), list):
            parts = []

            for item in data["output"]:
                for content in item.get("content", []):
                    if (
                        isinstance(content, dict)
                        and content.get("text")
                    ):
                        parts.append(content["text"])

            if parts:
                return "".join(parts)

        if data.get("predictions"):
            prediction = data["predictions"][0]

            if isinstance(prediction, str):
                return prediction

            return json.dumps(
                prediction,
                ensure_ascii=False
            )

        raise ValueError(
            "La respuesta del endpoint no tiene un formato reconocido. "
            f"Campos recibidos: {list(data)}"
        )

    @staticmethod
    def _parse_json(text: str):
        cleaned = text.strip()

        cleaned = re.sub(
            r"^```(?:json)?\s*",
            "",
            cleaned,
            flags=re.IGNORECASE
        )

        cleaned = re.sub(
            r"\s*```$",
            "",
            cleaned
        )

        try:
            return json.loads(cleaned)

        except json.JSONDecodeError:
            match = re.search(
                r"(\{.*\}|\[.*\])",
                cleaned,
                flags=re.DOTALL
            )

            if not match:
                raise ValueError(
                    "El modelo no devolvió un JSON válido. "
                    f"Respuesta recibida: {cleaned[:1000]}"
                )

            return json.loads(match.group(1))
