from pathlib import Path

from .utils import write_text


def final_report(
    mapping,
    reconciliation,
    output_dir
):
    correspondences = mapping.get(
        "correspondences",
        []
    )

    differences = [
        item
        for item in correspondences
        if item.get("verdict") == "DIFIERE"
    ]

    equivalents = [
        item
        for item in correspondences
        if item.get("verdict") == "EQUIVALENTE"
    ]

    unresolved = [
        item
        for item in correspondences
        if item.get("verdict") in {
            "NO_LOCALIZADO",
            "NO_VERIFICABLE"
        }
    ]

    controls = [
        item
        for item in correspondences
        if item.get("verdict") == "NO_APLICA_CONTROL"
    ]

    code_only_correspondences = [
        item
        for item in correspondences
        if item.get("verdict") == "SOLO_EN_CODIGO"
    ]

    numeric_status = str(
        reconciliation.get(
            "status",
            "NOT_RUN"
        )
    ).upper()

    production_status = str(
        reconciliation.get(
            "production_function",
            {}
        ).get(
            "status",
            "NOT_RUN"
        )
    ).upper()

    parameter_discovery = reconciliation.get(
        "parameter_discovery",
        {}
    )

    production_function = reconciliation.get(
        "production_function",
        {}
    )

    formula_reconstruction = reconciliation.get(
        "formula_reconstruction",
        {}
    )

    unresolved_count = len(
        unresolved
    )

    rule_word = (
        "regla"
        if unresolved_count == 1
        else "reglas"
    )


    # =========================================================
    # DETERMINAR VEREDICTO FINAL
    # =========================================================

    # Existe al menos una diferencia lógica confirmada.
    if differences:
        verdict = (
            "NO: se identificaron diferencias lógicas "
            "con evidencia."
        )

    # La comparación numérica encontró diferencias.
    elif numeric_status == "DIVERGE":
        verdict = (
            "NO: la reconciliación numérica identificó "
            "diferencias fuera de tolerancia."
        )

    # La reconciliación no pudo completarse.
    elif numeric_status == "ERROR":
        verdict = (
            "NO DETERMINABLE: la reconciliación numérica "
            "no pudo completarse debido a un error."
        )

    # La reconciliación matemática y productiva coinciden,
    # pero todavía quedan reglas semánticas pendientes.
    elif (
        unresolved
        and numeric_status == "MATCH"
        and production_status == "MATCH"
    ):
        verdict = (
            "NO DETERMINABLE: la reconciliación numérica "
            "de la fórmula y de la función productiva fue "
            "coincidente, pero aún existen "
            f"{unresolved_count} {rule_word} semánticas "
            "no verificables."
        )

    # La fórmula coincide, pero la función productiva
    # no fue ejecutada o no forma parte del alcance.
    elif (
        unresolved
        and numeric_status == "MATCH"
    ):
        verdict = (
            "NO DETERMINABLE: la reconciliación numérica "
            "de la fórmula fue coincidente, pero aún existen "
            f"{unresolved_count} {rule_word} semánticas "
            "no verificables."
        )

    # Solo se concluye SÍ cuando no quedan reglas pendientes
    # y la fórmula y la función productiva coinciden.
    elif (
        correspondences
        and not unresolved
        and numeric_status == "MATCH"
        and production_status == "MATCH"
    ):
        verdict = (
            "SÍ: las reglas evaluadas son equivalentes, "
            "las betas coinciden con el archivo de parámetros "
            "identificado automáticamente y la función "
            "productiva coincide con los resultados del Excel."
        )

    # No quedan pendientes y la fórmula coincide, pero la
    # función productiva no fue reconciliada.
    elif (
        correspondences
        and not unresolved
        and numeric_status == "MATCH"
    ):
        verdict = (
            "NO DETERMINABLE: las reglas evaluadas y la "
            "reconciliación de la fórmula fueron coincidentes, "
            "pero la función productiva no fue validada."
        )

    # Existen reglas pendientes y además no hay MATCH numérico.
    elif unresolved:
        verdict = (
            "NO DETERMINABLE: existen "
            f"{unresolved_count} {rule_word} semánticas "
            "no verificables."
        )

    # No se ejecutó ninguna reconciliación.
    elif numeric_status == "NOT_RUN":
        verdict = (
            "NO DETERMINABLE: no se ejecutó la "
            "reconciliación numérica."
        )

    else:
        verdict = (
            "NO DETERMINABLE: no existe evidencia "
            "suficiente para emitir una conclusión."
        )

    mapping_code_only = mapping.get(
        "code_only",
        []
    )

    all_code_only = (
        code_only_correspondences
        + mapping_code_only
    )

    lines = [
        "# Veredicto final",
        "",
        f"**{verdict}**",
        "",
        "## Resumen de correspondencias",
        "",
        f"- Reglas equivalentes: **{len(equivalents)}**",
        f"- Diferencias confirmadas: **{len(differences)}**",
        (
            "- Reglas pendientes de verificación: "
            f"**{len(unresolved)}**"
        ),
        (
            "- Controles del Excel que no aplican al código: "
            f"**{len(controls)}**"
        ),
        (
            "- Elementos encontrados solo en código: "
            f"**{len(all_code_only)}**"
        ),
        (
            "- Estado de reconciliación numérica: "
            f"**{numeric_status}**"
        ),
        "",
        "## Hallazgos críticos"
    ]

    if differences:
        for item in differences:
            lines.append(
                f"- `{item.get('rule_id', 'SIN_ID')}` · "
                f"**DIFIERE** · "
                f"{item.get('explanation', '')}"
            )

    elif numeric_status == "DIVERGE":
        lines.append(
            "- La reconciliación numérica presentó divergencias."
        )

    else:
        lines.append(
            "- No se registraron diferencias confirmadas con evidencia."
        )

    lines.extend([
        "",
        "## Reconciliación numérica",
        "",
        (
            "- Estado: "
            f"**{numeric_status}**"
        ),
        (
            "- Modo: "
            f"**{reconciliation.get('mode', 'No disponible')}**"
        ),
        (
            "- Periodos comparados: "
            f"**{reconciliation.get('periods_compared', 0)}**"
        ),
        (
            "- Periodos coincidentes: "
            f"**{reconciliation.get('matching_periods', 0)}**"
        ),
        (
            "- Periodos no coincidentes: "
            f"**{reconciliation.get('non_matching_periods', 0)}**"
        ),
        (
            "- Curva coincidente: "
            f"**{reconciliation.get('curve_match', False)}**"
        ),
        (
            "- Betas principales mapeadas: "
            f"**{reconciliation.get('all_betas_mapped', False)}**"
        ),
        (
            "- Betas principales coincidentes: "
            f"**{reconciliation.get('model_betas_match', False)}**"
        ),
        (
            "- Betas temporales coincidentes: "
            f"**{reconciliation.get('temporal_betas_match', False)}**"
        ),
        (
            "- Rango de periodos completo: "
            f"**{reconciliation.get('periods_match_expected_range', False)}**"
        ),
        (
            "- Diferencia absoluta máxima: "
            f"**{reconciliation.get('max_absolute_difference')}**"
        ),
        (
            "- Diferencia relativa máxima: "
            f"**{reconciliation.get('max_relative_difference')}**"
        ),
        "",
        (
            "Alcance: "
            f"{reconciliation.get('scope', 'No disponible')}."
        )
    ])

    # =====================================================
    # DESCUBRIMIENTO AUTOMÁTICO DE PARÁMETROS
    # =====================================================

    discovery_confidence = parameter_discovery.get(
        "confidence"
    )

    name_coverage = parameter_discovery.get(
        "name_coverage"
    )

    value_coverage = parameter_discovery.get(
        "value_coverage"
    )

    temporal_name_coverage = parameter_discovery.get(
        "temporal_name_coverage"
    )

    temporal_value_coverage = parameter_discovery.get(
        "temporal_value_coverage"
    )

    unmatched_variables = parameter_discovery.get(
        "unmatched_variables",
        []
    )

    lines.extend([
        "",
        "### Descubrimiento del archivo de parámetros",
        "",
        (
            "- Estado: "
            f"**{parameter_discovery.get('status', 'NOT_RUN')}**"
        ),
        (
            "- Archivo identificado automáticamente: "
            f"**{parameter_discovery.get('selected_file', 'No disponible')}**"
        ),
        (
            "- Confianza estructural: "
            f"**{discovery_confidence if discovery_confidence is not None else 'No disponible'}**"
        ),
        (
            "- Cobertura de nombres: "
            f"**{name_coverage if name_coverage is not None else 'No disponible'}**"
        ),
        (
            "- Cobertura de valores: "
            f"**{value_coverage if value_coverage is not None else 'No disponible'}**"
        ),
        (
            "- Cobertura de nombres temporales: "
            f"**{temporal_name_coverage if temporal_name_coverage is not None else 'No disponible'}**"
        ),
        (
            "- Cobertura de valores temporales: "
            f"**{temporal_value_coverage if temporal_value_coverage is not None else 'No disponible'}**"
        ),
        (
            "- Variables no encontradas: "
            f"**{len(unmatched_variables)}**"
        )
    ])

    # =====================================================
    # RECONSTRUCCIÓN DE FÓRMULA
    # =====================================================

    lines.extend([
        "",
        "### Reconstrucción de la fórmula",
        "",
        (
            "- Estado: "
            f"**{formula_reconstruction.get('status', 'NOT_RUN')}**"
        ),
        (
            "- Periodos comparados: "
            f"**{formula_reconstruction.get('periods_compared', 0)}**"
        ),
        (
            "- Periodos coincidentes: "
            f"**{formula_reconstruction.get('matching_periods', 0)}**"
        ),
        (
            "- Periodos no coincidentes: "
            f"**{formula_reconstruction.get('non_matching_periods', 0)}**"
        ),
        (
            "- Curva coincidente: "
            f"**{formula_reconstruction.get('curve_match', False)}**"
        ),
        (
            "- Diferencia absoluta máxima: "
            f"**{formula_reconstruction.get('max_absolute_difference', 'No disponible')}**"
        ),
        (
            "- Diferencia relativa máxima: "
            f"**{formula_reconstruction.get('max_relative_difference', 'No disponible')}**"
        )
    ])

    # =====================================================
    # FUNCIÓN PRODUCTIVA
    # =====================================================

    lines.extend([
        "",
        "### Función productiva",
        "",
        (
            "- Función: "
            f"**{production_function.get('function', 'No disponible')}**"
        ),
        (
            "- Ejecutada: "
            f"**{production_function.get('function_executed', False)}**"
        ),
        (
            "- Estado: "
            f"**{production_function.get('status', 'NOT_RUN')}**"
        ),
        (
            "- Periodos comparados: "
            f"**{production_function.get('periods_compared', 0)}**"
        ),
        (
            "- Periodos coincidentes: "
            f"**{production_function.get('matching_periods', 0)}**"
        ),
        (
            "- Periodos no coincidentes: "
            f"**{production_function.get('non_matching_periods', 0)}**"
        ),
        (
            "- Curva productiva coincidente: "
            f"**{production_function.get('curve_match', False)}**"
        ),
        (
            "- Diferencia absoluta máxima: "
            f"**{production_function.get('max_absolute_difference', 'No disponible')}**"
        ),
        (
            "- Diferencia relativa máxima: "
            f"**{production_function.get('max_relative_difference', 'No disponible')}**"
        ),
        "",
        (
            "Alcance productivo: "
            f"{production_function.get('scope', 'No disponible')}"
        )
    ])

    lines.extend([
        "",
        "## Reglas equivalentes"
    ])

    if equivalents:
        for item in equivalents:
            files = item.get(
                "files",
                []
            )

            if isinstance(files, str):
                files = [files]

            files_text = (
                ", ".join(files)
                if files
                else "archivo no indicado"
            )

            lines.append(
                f"- `{item.get('rule_id', 'SIN_ID')}` · "
                f"{files_text} · "
                f"{item.get('explanation', '')}"
            )

    else:
        lines.append(
            "- No se registraron reglas equivalentes."
        )

    lines.extend([
        "",
        "## Reglas pendientes de verificación"
    ])

    if unresolved:
        for item in unresolved:
            lines.append(
                f"- `{item.get('rule_id', 'SIN_ID')}` · "
                f"**{item.get('verdict', '')}** · "
                f"{item.get('explanation', '')}"
            )

    else:
        lines.append(
            "- No se registraron reglas pendientes."
        )

    lines.extend([
        "",
        "## Controles del Excel"
    ])

    if controls:
        for item in controls:
            lines.append(
                f"- `{item.get('rule_id', 'SIN_ID')}` · "
                f"{item.get('explanation', '')}"
            )

    else:
        lines.append(
            "- No se registraron controles separados "
            "de la lógica productiva."
        )

    lines.extend([
        "",
        "## Elementos solo en código"
    ])

    if all_code_only:
        for item in all_code_only:
            if isinstance(
                item,
                dict
            ):
                rule_id = item.get(
                    "rule_id",
                    ""
                )

                description = (
                    item.get("explanation")
                    or item.get("description")
                    or item.get("evidence")
                    or str(item)
                )

                files = item.get(
                    "files",
                    []
                )

                if isinstance(
                    files,
                    str
                ):
                    files = [
                        files
                    ]

                files_text = (
                    ", ".join(files)
                    if files
                    else ""
                )

                parts = []

                if rule_id:
                    parts.append(
                        f"`{rule_id}`"
                    )

                if files_text:
                    parts.append(
                        files_text
                    )

                parts.append(
                    description
                )

                lines.append(
                    "- "
                    + " · ".join(parts)
                )

            else:
                lines.append(
                    f"- {item}"
                )

    else:
        lines.append(
            "- No se registraron elementos exclusivos "
            "del código."
        )

    # =====================================================
    # ZONAS NO VERIFICADAS
    # =====================================================
    #
    # Este bloque está fuera del if all_code_only.
    # Por eso zones siempre queda inicializada.
    # =====================================================

    zones = list(
        mapping.get(
            "unverified_zones",
            []
        )
    )

    # La reconciliación numérica es evidencia posterior y
    # determinística. Cuando termina en MATCH, se eliminan
    # observaciones semánticas que ya fueron resueltas.
    if numeric_status == "MATCH":
        obsolete_zone_markers = {
            "ead_thetat.csv",
            "valores numéricos en el csv",
            "valores exactos de los coeficientes",
            "orden de columnas",
            "orden esperado",
            "mapeo de índices",
            "c4:c15",
            "b38:bg38",
            "58 columnas",
            "60 períodos",
            "60 periodos",
            "rango de tiempo",
            "arange(1,61)",
            "arange(1, 61)",
            "período t en python vs. bex",
            "periodo t en python vs. bex"
        }

        filtered_zones = []

        for zone in zones:
            zone_text = str(
                zone
            ).lower()

            is_obsolete = any(
                marker in zone_text
                for marker in obsolete_zone_markers
            )

            if not is_obsolete:
                filtered_zones.append(
                    zone
                )

        zones = filtered_zones

    else:
        zones.append(
            "No se completó una reconciliación "
            "numérica coincidente."
        )

    lines.extend([
        "",
        "## Zonas no verificadas"
    ])

    if zones:
        for zone in zones:
            if isinstance(
                zone,
                dict
            ):
                location = (
                    zone.get("file")
                    or zone.get("location")
                    or zone.get("zone")
                    or zone.get("issue")
                    or "Ubicación no indicada"
                )

                reason = (
                    zone.get("reason")
                    or zone.get("explanation")
                    or zone.get("description")
                    or str(zone)
                )

                lines.append(
                    f"- `{location}` · {reason}"
                )

            else:
                lines.append(
                    f"- {zone}"
                )

    else:
        lines.append(
            "- Ninguna registrada."
        )

    output_path = (
        Path(output_dir)
        / "resultado_final.md"
    )

    write_text(
        output_path,
        "\n".join(lines)
    )

    return {
        "verdict": verdict,
        "equivalent_count": len(equivalents),
        "difference_count": len(differences),
        "unresolved_count": len(unresolved),
        "control_count": len(controls),
        "code_only_count": len(all_code_only),
        "numeric_status": numeric_status,
        "curve_match": reconciliation.get(
            "curve_match",
            False
        ),
        "matching_periods": reconciliation.get(
            "matching_periods",
            0
        ),
        "non_matching_periods": reconciliation.get(
            "non_matching_periods",
            0
        ),
        "parameter_discovery_status": (
            parameter_discovery.get(
                "status",
                "NOT_RUN"
            )
        ),
        "selected_parameter_file": (
            parameter_discovery.get(
                "selected_file"
            )
        ),
        "parameter_discovery_confidence": (
            parameter_discovery.get(
                "confidence"
            )
        ),
        "formula_reconstruction_status": (
            formula_reconstruction.get(
                "status",
                "NOT_RUN"
            )
        ),
        "production_function_status": (
            production_function.get(
                "status",
                "NOT_RUN"
            )
        ),
        "production_function_executed": (
            production_function.get(
                "function_executed",
                False
            )
        ),
        "output_path": str(output_path)
    }