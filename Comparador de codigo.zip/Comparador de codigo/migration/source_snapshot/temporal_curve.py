from __future__ import annotations

from itertools import groupby

import numpy as np
import pandas as pd

from .base import ReconciliationStrategy, StrategyContext, StrategyDetection, safe_float, write_component_csv
from .scalar_formula import ScalarFormulaStrategy


class TemporalCurveStrategy(ReconciliationStrategy):
    name = "temporal_curve"
    title = "Reconciliación de series y curvas"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        series = []
        for ws in context.workbook.worksheets:
            for row in range(1, ws.max_row + 1):
                numeric = []
                for column in range(1, ws.max_column + 1):
                    value = safe_float(ws.cell(row, column).value)
                    numeric.append((column, value))
                for _, group in groupby(numeric, key=lambda item: item[1] is not None):
                    grouped = list(group)
                    if grouped and grouped[0][1] is not None and len(grouped) >= 6:
                        columns = [item[0] for item in grouped]
                        values = [item[1] for item in grouped]
                        monotonic_header = all(abs(values[index] - values[index - 1] - 1) < 1e-9 for index in range(1, len(values)))
                        if monotonic_header:
                            for candidate_row in range(row + 1, min(ws.max_row, row + 8) + 1):
                                cells = [ws.cell(candidate_row, column) for column in columns]
                                expected = [safe_float(cell.value) for cell in cells]
                                formulas = [isinstance(cell.value, str) and cell.value.startswith("=") for cell in cells]
                                if sum(formulas) >= max(3, int(len(cells) * 0.5)):
                                    label = self._row_label(ws, candidate_row, columns[0])
                                    series.append({
                                        "sheet": ws.title,
                                        "header_row": row,
                                        "data_row": candidate_row,
                                        "start_column": columns[0],
                                        "end_column": columns[-1],
                                        "periods": values,
                                        "cells": [cell.coordinate for cell in cells],
                                        "label": label,
                                    })
        series.sort(key=lambda item: (-len(item["periods"]), item["sheet"], item["data_row"]))
        confidence = min(0.97, 0.70 + 0.01 * len(series[0]["periods"])) if series else 0.0
        return StrategyDetection(
            strategy=self.name,
            confidence=confidence,
            status="DETECTED" if series else "NOT_DETECTED",
            sheet=series[0]["sheet"] if series else None,
            evidence=[{"type": "temporal_series", "count": len(series)}],
            payload={"series": series},
            reason=None if series else "No se detectaron cabeceras temporales continuas con fórmulas asociadas.",
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        try:
            evaluator = ScalarFormulaStrategy()
            atol, rtol = self._tolerances(context)
            rows = []
            for series_index, series in enumerate(detection.payload.get("series", []), start=1):
                ws = context.workbook[series["sheet"]]
                ws_values = context.workbook_values[series["sheet"]] if context.workbook_values else None
                for period, coordinate in zip(series["periods"], series["cells"]):
                    formula = ws[coordinate].value
                    expected = ws_values[coordinate].value if ws_values else None
                    calculated, reason = evaluator._evaluate_supported_formula(ws, formula)
                    expected_number = safe_float(expected)
                    supported = calculated is not None and expected_number is not None
                    within = bool(np.isclose(calculated, expected_number, atol=atol, rtol=rtol)) if supported else False
                    rows.append({
                        "series": series_index, "sheet": series["sheet"], "label": series["label"],
                        "period": period, "cell": coordinate, "formula": formula,
                        "expected": expected_number, "calculated": calculated,
                        "supported": supported, "within_tolerance": within, "reason": reason,
                    })
            comparison = pd.DataFrame(rows)
            supported = comparison[comparison["supported"]] if not comparison.empty else comparison
            comparisons = len(supported)
            matches = int(supported["within_tolerance"].sum()) if comparisons else 0
            differences = comparisons - matches
            status = "NOT_RUN" if comparisons == 0 else ("MATCH" if differences == 0 else "DIVERGE")
            artifact = write_component_csv(context, "strategy_temporal_curve.csv", comparison)
            return {
                "strategy": self.name, "title": self.title, "status": status,
                "confidence": detection.confidence, "series_detected": len(detection.payload.get("series", [])),
                "comparisons": comparisons, "matches": matches, "differences": differences,
                "artifacts": [artifact],
            }
        except Exception as exc:
            return self.error(exc, detection)

    @staticmethod
    def _row_label(ws, row: int, first_column: int) -> str | None:
        for column in range(first_column - 1, 0, -1):
            value = ws.cell(row, column).value
            if isinstance(value, str) and value.strip() and not value.startswith("="):
                return value.strip()
        return None

    @staticmethod
    def _tolerances(context: StrategyContext) -> tuple[float, float]:
        config = context.config.get("tolerances", {})
        return float(config.get("absolute", 1e-8)), float(config.get("relative", 1e-6))
