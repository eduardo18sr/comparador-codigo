from __future__ import annotations

from collections import Counter

import numpy as np
import pandas as pd
from openpyxl.formula.translate import Translator

from .base import ReconciliationStrategy, StrategyContext, StrategyDetection, safe_float, write_component_csv
from .scalar_formula import ScalarFormulaStrategy


class TabularFormulaStrategy(ReconciliationStrategy):
    name = "tabular_formula"
    title = "Reconciliación de bloques tabulares"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        regions = []
        for ws in context.workbook.worksheets:
            formula_cells = [cell for row in ws.iter_rows() for cell in row if isinstance(cell.value, str) and cell.value.startswith("=")]
            by_row = Counter(cell.row for cell in formula_cells)
            by_column = Counter(cell.column for cell in formula_cells)
            for row, count in by_row.items():
                if count >= 3:
                    cells = sorted([cell.coordinate for cell in formula_cells if cell.row == row])
                    regions.append({"sheet": ws.title, "axis": "horizontal", "index": row, "cells": cells, "count": count})
            for column, count in by_column.items():
                if count >= 3:
                    cells = sorted([cell.coordinate for cell in formula_cells if cell.column == column])
                    regions.append({"sheet": ws.title, "axis": "vertical", "index": column, "cells": cells, "count": count})
        regions.sort(key=lambda item: (-item["count"], item["sheet"], item["axis"]))
        confidence = min(0.93, 0.60 + 0.02 * regions[0]["count"]) if regions else 0.0
        return StrategyDetection(
            strategy=self.name,
            confidence=confidence,
            status="DETECTED" if regions else "NOT_DETECTED",
            sheet=regions[0]["sheet"] if regions else None,
            evidence=[{"type": "repeated_formula_regions", "count": len(regions)}],
            payload={"regions": regions},
            reason=None if regions else "No se encontraron regiones con fórmulas repetidas.",
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        try:
            evaluator = ScalarFormulaStrategy()
            atol, rtol = self._tolerances(context)
            rows = []
            seen = set()
            for region in detection.payload.get("regions", []):
                ws = context.workbook[region["sheet"]]
                ws_values = context.workbook_values[region["sheet"]] if context.workbook_values else None
                for coordinate in region["cells"]:
                    key = (region["sheet"], coordinate)
                    if key in seen:
                        continue
                    seen.add(key)
                    formula = ws[coordinate].value
                    expected = ws_values[coordinate].value if ws_values else None
                    calculated, reason = evaluator._evaluate_supported_formula(ws, formula)
                    expected_number = safe_float(expected)
                    supported = calculated is not None and expected_number is not None
                    within = bool(np.isclose(calculated, expected_number, atol=atol, rtol=rtol)) if supported else False
                    rows.append({
                        "sheet": region["sheet"], "cell": coordinate, "formula": formula,
                        "expected": expected_number, "calculated": calculated,
                        "supported": supported, "within_tolerance": within, "reason": reason,
                    })
            comparison = pd.DataFrame(rows)
            supported = comparison[comparison["supported"]] if not comparison.empty else comparison
            comparisons = len(supported)
            matches = int(supported["within_tolerance"].sum()) if comparisons else 0
            differences = comparisons - matches
            status = "NOT_RUN" if comparisons == 0 else ("MATCH" if differences == 0 else "DIVERGE")
            artifact = write_component_csv(context, "strategy_tabular_formula.csv", comparison)
            return {
                "strategy": self.name, "title": self.title, "status": status,
                "confidence": detection.confidence, "comparisons": comparisons,
                "matches": matches, "differences": differences,
                "regions_detected": len(detection.payload.get("regions", [])),
                "artifacts": [artifact],
            }
        except Exception as exc:
            return self.error(exc, detection)

    @staticmethod
    def _tolerances(context: StrategyContext) -> tuple[float, float]:
        config = context.config.get("tolerances", {})
        return float(config.get("absolute", 1e-8)), float(config.get("relative", 1e-6))
