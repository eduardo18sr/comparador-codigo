from __future__ import annotations

import csv
import json
import importlib
import sys
import re
import unicodedata

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from openpyxl.utils.cell import (
    column_index_from_string
)

from .utils import (
    dump_json,
    write_text
)

from .strategy_discovery import (
    discover_reconciliation_strategy,
    get_available_strategies
)

from .strategies.base import (
    StrategyContext,
    StrategyDetection
)

RECONCILIATION_STATUS = {
    "MATCH",
    "DIVERGE",
    "NOT_RUN",
    "ERROR"
}

def _normalize_parameter_name(
    value: Any
) -> str:
    """
    Normaliza nombres de variables para comparar Excel
    contra archivos de parámetros.

    Ejemplos:
      LN_ING_BCI_TRAMO_MEDIO
        -> ln_ing_bci_tramo_medio

      RT UTIL 24 acot
        -> rt_util_24_acot
    """
    text = str(
        value
    ).strip().lower()

    text = unicodedata.normalize(
        "NFKD",
        text
    )

    text = "".join(
        character
        for character in text
        if not unicodedata.combining(
            character
        )
    )

    text = re.sub(
        r"[^a-z0-9]+",
        "_",
        text
    )

    text = re.sub(
        r"_+",
        "_",
        text
    )

    return text.strip(
        "_"
    )

DEFAULT_PARAMETER_ALIASES = {
    "intercept": {
        "intercept",
        "intercepto",
        "const",
        "constant"
    },

    "ln_ing_bci_tramo_medio": {
        "ln_ing_bci_tramo_medio",
        "l_ing_bci_medio_acot",
        "ln_ing_bci_medio_acot"
    },

    "flag_bex_enalta": {
        "flag_bex_enalta",
        "flg_bex_enalta"
    },

    "ln_t": {
        "ln_t",
        "distancia_def"
    },

    "h_ln_t": {
        "h_ln_t",
        "h_distancia_def"
    }
}
def _build_alias_index(
    configured_aliases: dict | None = None
) -> dict[str, set[str]]:
    """
    Construye un índice de nombres equivalentes.

    Los alias configurados complementan, no reemplazan,
    los alias generales.
    """
    alias_index = {
        key: set(values)
        for key, values
        in DEFAULT_PARAMETER_ALIASES.items()
    }

    configured_aliases = (
        configured_aliases
        or {}
    )

    for canonical_name, aliases in (
        configured_aliases.items()
    ):
        normalized_canonical = (
            _normalize_parameter_name(
                canonical_name
            )
        )

        if isinstance(
            aliases,
            str
        ):
            aliases = [
                aliases
            ]

        normalized_aliases = {
            _normalize_parameter_name(
                alias
            )
            for alias in aliases
        }

        normalized_aliases.add(
            normalized_canonical
        )

        alias_index.setdefault(
            normalized_canonical,
            set()
        ).update(
            normalized_aliases
        )

    return alias_index
def _possible_parameter_names(
    excel_name: str,
    alias_index: dict[str, set[str]]
) -> set[str]:
    """
    Obtiene nombres posibles para una variable Excel.
    """
    normalized_name = (
        _normalize_parameter_name(
            excel_name
        )
    )

    possible_names = {
        normalized_name
    }

    for canonical_name, aliases in (
        alias_index.items()
    ):
        normalized_aliases = {
            _normalize_parameter_name(
                alias
            )
            for alias in aliases
        }

        if (
            normalized_name == canonical_name
            or normalized_name in normalized_aliases
        ):
            possible_names.add(
                canonical_name
            )

            possible_names.update(
                normalized_aliases
            )

    return possible_names
def _iter_parameter_files(
    project_root: Path,
    discovery_config: dict
):
    """
    Recorre archivos de parámetros permitidos.
    """
    search_paths = discovery_config.get(
        "search_paths",
        [
            "data/params"
        ]
    )

    include_extensions = {
        str(extension).lower()
        for extension in discovery_config.get(
            "include_extensions",
            [
                ".csv",
                ".json",
                ".yaml",
                ".yml"
            ]
        )
    }

    exclude_paths = [
        str(value)
        .replace("\\", "/")
        .lower()
        for value in discovery_config.get(
            "exclude_paths",
            []
        )
    ]

    max_file_bytes = int(
        discovery_config.get(
            "max_file_bytes",
            2_000_000
        )
    )

    seen_paths = set()

    for configured_search_path in search_paths:
        base_path = _resolve_project_file(
            project_root=project_root,
            configured_path=str(
                configured_search_path
            )
        )

        if not base_path.exists():
            continue

        if base_path.is_file():
            candidate_paths = [
                base_path
            ]
        else:
            candidate_paths = (
                base_path.rglob("*")
            )

        for path in candidate_paths:
            try:
                if not path.is_file():
                    continue

                if (
                    path.suffix.lower()
                    not in include_extensions
                ):
                    continue

                if path.stat().st_size > max_file_bytes:
                    continue

            except (
                FileNotFoundError,
                OSError
            ):
                continue

            normalized_path = str(
                path
            ).replace(
                "\\",
                "/"
            ).lower()

            if any(
                excluded_path in normalized_path
                for excluded_path in exclude_paths
            ):
                continue

            if path in seen_paths:
                continue

            seen_paths.add(
                path
            )

            yield path
def _load_parameter_candidate(
    path: Path
) -> pd.DataFrame | None:
    """
    Convierte un archivo candidato a DataFrame cuando
    su estructura permite una comparación de parámetros.
    """
    suffix = path.suffix.lower()

    try:
        if suffix == ".csv":
            dataframe = pd.read_csv(
                path,
                encoding="utf-8-sig"
            )

        elif suffix == ".json":
            data = json.loads(
                path.read_text(
                    encoding="utf-8"
                )
            )

            if isinstance(
                data,
                list
            ):
                dataframe = pd.DataFrame(
                    data
                )

            elif isinstance(
                data,
                dict
            ):
                try:
                    dataframe = pd.DataFrame(
                        data
                    )
                except ValueError:
                    dataframe = pd.DataFrame([
                        data
                    ])

            else:
                return None

        elif suffix in {
            ".yaml",
            ".yml"
        }:
            try:
                import yaml
            except ImportError:
                return None

            data = yaml.safe_load(
                path.read_text(
                    encoding="utf-8"
                )
            )

            if isinstance(
                data,
                list
            ):
                dataframe = pd.DataFrame(
                    data
                )

            elif isinstance(
                data,
                dict
            ):
                try:
                    dataframe = pd.DataFrame(
                        data
                    )
                except ValueError:
                    dataframe = pd.DataFrame([
                        data
                    ])

            else:
                return None

        else:
            return None

    except (
        ValueError,
        UnicodeDecodeError,
        json.JSONDecodeError,
        OSError
    ):
        return None

    if dataframe.empty:
        return None

    dataframe.columns = [
        str(column).strip()
        for column in dataframe.columns
    ]

    return dataframe

def _score_parameter_candidate(
    path: Path,
    dataframe: pd.DataFrame,
    excel_variable_names: list[str],
    excel_beta_values: np.ndarray,
    beta_ln_t: float,
    beta_h_ln_t: float,
    alias_index: dict[str, set[str]],
    absolute_tolerance: float,
    relative_tolerance: float
) -> dict:
    """
    Puntúa un archivo como posible fuente de parámetros.

    La identificación se basa principalmente en nombres
    y estructura. La coincidencia de valores se registra,
    pero no se utiliza como condición obligatoria para
    seleccionar el archivo.
    """
    if dataframe.empty:
        return {
            "path": str(path),
            "discovery_score": 0.0,
            "value_match_score": 0.0,
            "name_coverage": 0.0,
            "value_coverage": 0.0,
            "temporal_name_coverage": 0.0,
            "temporal_value_coverage": 0.0,
            "matched_variables": [],
            "unmatched_variables": list(
                excel_variable_names
            ),
            "resolved_mapping": {},
            "temporal_mapping": {},
            "row_count": 0,
            "column_count": 0
        }

    normalized_columns = {
        _normalize_parameter_name(
            column
        ): column
        for column in dataframe.columns
    }

    matched_variables = []
    unmatched_variables = []
    resolved_mapping = {}
    value_match_records = []

    parameter_row = dataframe.iloc[0]

    for excel_name, excel_beta in zip(
        excel_variable_names,
        excel_beta_values
    ):
        possible_names = _possible_parameter_names(
            excel_name=excel_name,
            alias_index=alias_index
        )

        matching_column = next(
            (
                normalized_columns[possible_name]
                for possible_name in sorted(
                    possible_names
                )
                if possible_name
                in normalized_columns
            ),
            None
        )

        if matching_column is None:
            unmatched_variables.append(
                excel_name
            )

            continue

        matched_variables.append(
            excel_name
        )

        resolved_mapping[
            excel_name
        ] = matching_column

        try:
            candidate_beta = float(
                parameter_row[
                    matching_column
                ]
            )

            value_matches = bool(
                np.isclose(
                    float(excel_beta),
                    candidate_beta,
                    atol=absolute_tolerance,
                    rtol=relative_tolerance
                )
            )

        except (
            TypeError,
            ValueError
        ):
            candidate_beta = None
            value_matches = False

        value_match_records.append({
            "excel_variable": excel_name,
            "parameter_column": matching_column,
            "excel_value": float(excel_beta),
            "parameter_value": candidate_beta,
            "matches": value_matches
        })

    temporal_expectations = {
        "LN_T": beta_ln_t,
        "H_LN_T": beta_h_ln_t
    }

    temporal_mapping = {}
    temporal_value_records = []

    for excel_name, excel_beta in (
        temporal_expectations.items()
    ):
        possible_names = _possible_parameter_names(
            excel_name=excel_name,
            alias_index=alias_index
        )

        matching_column = next(
            (
                normalized_columns[possible_name]
                for possible_name in sorted(
                    possible_names
                )
                if possible_name
                in normalized_columns
            ),
            None
        )

        if matching_column is None:
            continue

        temporal_mapping[
            excel_name
        ] = matching_column

        try:
            candidate_beta = float(
                parameter_row[
                    matching_column
                ]
            )

            value_matches = bool(
                np.isclose(
                    float(excel_beta),
                    candidate_beta,
                    atol=absolute_tolerance,
                    rtol=relative_tolerance
                )
            )

        except (
            TypeError,
            ValueError
        ):
            candidate_beta = None
            value_matches = False

        temporal_value_records.append({
            "excel_variable": excel_name,
            "parameter_column": matching_column,
            "excel_value": float(excel_beta),
            "parameter_value": candidate_beta,
            "matches": value_matches
        })

    total_variables = len(
        excel_variable_names
    )

    name_coverage = (
        len(matched_variables)
        / total_variables
        if total_variables
        else 0.0
    )

    value_coverage = (
        sum(
            record["matches"]
            for record in value_match_records
        )
        / total_variables
        if total_variables
        else 0.0
    )

    temporal_count = len(
        temporal_expectations
    )

    temporal_name_coverage = (
        len(temporal_mapping)
        / temporal_count
        if temporal_count
        else 0.0
    )

    temporal_value_coverage = (
        sum(
            record["matches"]
            for record
            in temporal_value_records
        )
        / temporal_count
        if temporal_count
        else 0.0
    )

    normalized_file_name = (
        path.name.lower()
    )

    filename_bonus = (
        0.03
        if any(
            token in normalized_file_name
            for token in {
                "theta",
                "beta",
                "coef",
                "param"
            }
        )
        else 0.0
    )

    single_row_bonus = (
        0.05
        if len(dataframe) == 1
        else 0.0
    )

    # Score para identificar el archivo.
    # No depende de que los valores sean iguales.
    discovery_score = (
        name_coverage * 0.70
        + temporal_name_coverage * 0.20
        + single_row_bonus
        + filename_bonus
    )

    discovery_score = min(
        float(discovery_score),
        1.0
    )

    # Score separado, utilizado para reportar la
    # coincidencia numérica, no para identificar.
    value_match_score = (
        value_coverage * 0.80
        + temporal_value_coverage * 0.20
    )

    return {
        "path": str(path),
        "score": discovery_score,
        "discovery_score": discovery_score,
        "value_match_score": float(
            value_match_score
        ),
        "name_coverage": float(
            name_coverage
        ),
        "value_coverage": float(
            value_coverage
        ),
        "temporal_name_coverage": float(
            temporal_name_coverage
        ),
        "temporal_value_coverage": float(
            temporal_value_coverage
        ),
        "matched_variables": (
            matched_variables
        ),
        "unmatched_variables": (
            unmatched_variables
        ),
        "resolved_mapping": (
            resolved_mapping
        ),
        "temporal_mapping": (
            temporal_mapping
        ),
        "value_comparisons": (
            value_match_records
        ),
        "temporal_value_comparisons": (
            temporal_value_records
        ),
        "row_count": int(
            len(dataframe)
        ),
        "column_count": int(
            len(dataframe.columns)
        )
    }

def _discover_theta_file(
    project_root: Path,
    discovery_config: dict,
    model_inputs: dict,
    absolute_tolerance: float,
    relative_tolerance: float
) -> dict:
    """
    Busca y selecciona automáticamente el archivo que
    contiene las betas del modelo.

    No selecciona un archivo cuando la evidencia es baja
    o existe un empate ambiguo.
    """
    alias_index = _build_alias_index(
        discovery_config.get(
            "aliases",
            {}
        )
    )

    candidates = []

    for path in _iter_parameter_files(
        project_root=project_root,
        discovery_config=discovery_config
    ):
        dataframe = _load_parameter_candidate(
            path
        )

        if dataframe is None:
            continue

        candidate = _score_parameter_candidate(
            path=path,
            dataframe=dataframe,
            excel_variable_names=model_inputs[
                "variable_names"
            ],
            excel_beta_values=model_inputs[
                "beta_values"
            ],
            beta_ln_t=model_inputs[
                "beta_ln_t"
            ],
            beta_h_ln_t=model_inputs[
                "beta_h_ln_t"
            ],
            alias_index=alias_index,
            absolute_tolerance=absolute_tolerance,
            relative_tolerance=relative_tolerance
        )

        candidates.append(
            candidate
        )

    candidates.sort(
        key=lambda item: (
            -item["discovery_score"],
            -item["name_coverage"],
            -item["temporal_name_coverage"],
            item["path"]
        )
    )

    if not candidates:
        return {
            "status": "NOT_FOUND",
            "selected_path": None,
            "confidence": 0.0,
            "candidates": []
        }

    best_candidate = candidates[0]

    minimum_name_coverage = float(
        discovery_config.get(
            "minimum_name_coverage",
            0.80
        )
    )

    minimum_temporal_name_coverage = float(
        discovery_config.get(
            "minimum_temporal_name_coverage",
            0.50
        )
    )

    minimum_confidence = float(
        discovery_config.get(
            "minimum_confidence",
            0.75
        )
    )

    qualifies = bool(
        best_candidate[
            "name_coverage"
        ] >= minimum_name_coverage
        and best_candidate[
            "temporal_name_coverage"
        ] >= minimum_temporal_name_coverage
        and best_candidate[
            "discovery_score"
        ] >= minimum_confidence
    )

    if not qualifies:
        return {
            "status": "LOW_CONFIDENCE",
            "selected_path": None,
            "confidence": best_candidate[
                "score"
            ],
            "best_candidate": (
                best_candidate
            ),
            "candidates": candidates[:20]
        }

    ambiguity_margin = float(
        discovery_config.get(
            "ambiguity_margin",
            0.03
        )
    )

    if len(candidates) > 1:
        second_candidate = candidates[1]

        is_ambiguous = (
            best_candidate["score"]
            - second_candidate["score"]
            <= ambiguity_margin
        )

        if is_ambiguous:
            return {
                "status": "AMBIGUOUS",
                "selected_path": None,
                "confidence": best_candidate[
                    "score"
                ],
                "best_candidate": (
                    best_candidate
                ),
                "second_candidate": (
                    second_candidate
                ),
                "candidates": candidates[:20]
            }

    return {
        "status": "SELECTED",
        "selected_path": best_candidate[
            "path"
        ],
        "confidence": best_candidate[
            "score"
        ],
        "resolved_mapping": best_candidate[
            "resolved_mapping"
        ],
        "temporal_mapping": best_candidate[
            "temporal_mapping"
        ],
        "selected_candidate": best_candidate,
        "candidates": candidates[:20]
    }
def _not_run_result(
    reason: str,
    missing_items: list[str] | None = None
) -> dict:
    """
    Construye un resultado estructurado cuando la
    reconciliación no se ejecuta.
    """
    return {
        "status": "NOT_RUN",
        "mode": None,
        "reason": reason,
        "missing_items": (
            missing_items
            or []
        ),
        "scope": None,
        "end_to_end_from_raw_inputs": False,
        "periods_compared": 0,
        "matching_periods": 0,
        "non_matching_periods": 0,
        "curve_match": False,
        "all_betas_mapped": False,
        "model_betas_match": False,
        "temporal_betas_match": False,
        "periods_match_expected_range": False,
        "max_absolute_difference": None,
        "max_relative_difference": None
    }


def _error_result(
    exc: Exception
) -> dict:
    """
    Construye un resultado estructurado cuando ocurre
    un error durante la reconciliación.
    """
    return {
        "status": "ERROR",
        "mode": "FORMULA_RECONSTRUCTION",
        "reason": (
            f"{type(exc).__name__}: {exc}"
        ),
        "missing_items": [],
        "scope": (
            "Reconstrucción de la fórmula utilizando "
            "valores transformados almacenados en Excel"
        ),
        "end_to_end_from_raw_inputs": False,
        "periods_compared": 0,
        "matching_periods": 0,
        "non_matching_periods": 0,
        "curve_match": False,
        "all_betas_mapped": False,
        "model_betas_match": False,
        "temporal_betas_match": False,
        "periods_match_expected_range": False,
        "max_absolute_difference": None,
        "max_relative_difference": None
    }


def _get_config_value(
    config: dict,
    path: list[str],
    default: Any = None
) -> Any:
    """
    Obtiene un valor anidado de configuración sin producir
    KeyError cuando una sección no existe.
    """
    current: Any = config

    for key in path:
        if not isinstance(
            current,
            dict
        ):
            return default

        if key not in current:
            return default

        current = current[key]

    return current


def _resolve_project_file(
    project_root: Path,
    configured_path: str
) -> Path:
    """
    Resuelve una ruta configurada.

    Si la ruta es relativa, se interpreta desde project_root.
    """
    path = Path(
        configured_path
    )

    if path.is_absolute():
        return path

    return (
        project_root
        / path
    )


def _column_to_index(
    column: str | int
) -> int:
    """
    Convierte una letra de columna Excel o un número
    a índice entero basado en 1.
    """
    if isinstance(
        column,
        int
    ):
        return column

    value = str(
        column
    ).strip()

    if value.isdigit():
        return int(
            value
        )

    return column_index_from_string(
        value.upper()
    )


def _normalise_name(
    value: Any
) -> str:
    return (
        str(value)
        .strip()
        .lower()
    )


def _require_cell_value(
    ws,
    coordinate: str,
    description: str
) -> Any:
    value = ws[
        coordinate
    ].value

    if value is None:
        raise ValueError(
            f"{coordinate} no contiene {description}."
        )

    return value


def _extract_excel_model_inputs(
    ws,
    excel_config: dict
) -> dict:
    """
    Extrae nombres, valores transformados y betas principales
    desde el bloque configurado del Excel.
    """
    variables_config = excel_config.get(
        "variables",
        {}
    )

    start_row = int(
        variables_config.get(
            "start_row",
            4
        )
    )

    end_row = int(
        variables_config.get(
            "end_row",
            13
        )
    )

    name_column = _column_to_index(
        variables_config.get(
            "name_column",
            "A"
        )
    )

    value_column = _column_to_index(
        variables_config.get(
            "value_column",
            "B"
        )
    )

    beta_column = _column_to_index(
        variables_config.get(
            "beta_column",
            "C"
        )
    )

    variable_names = []
    transformed_values = []
    beta_values = []

    for row in range(
        start_row,
        end_row + 1
    ):
        variable_name = ws.cell(
            row=row,
            column=name_column
        ).value

        transformed_value = ws.cell(
            row=row,
            column=value_column
        ).value

        beta_value = ws.cell(
            row=row,
            column=beta_column
        ).value

        if variable_name is None:
            raise ValueError(
                f"No existe nombre de variable "
                f"en la fila {row}."
            )

        if transformed_value is None:
            raise ValueError(
                f"No existe valor transformado "
                f"en la fila {row}."
            )

        if beta_value is None:
            raise ValueError(
                f"No existe beta en la fila {row}."
            )

        variable_names.append(
            str(variable_name).strip()
        )

        transformed_values.append(
            float(transformed_value)
        )

        beta_values.append(
            float(beta_value)
        )

    temporal_config = excel_config.get(
        "temporal_betas",
        {}
    )

    ln_t_cell = str(
        temporal_config.get(
            "ln_t",
            "C14"
        )
    )

    h_ln_t_cell = str(
        temporal_config.get(
            "h_ln_t",
            "C15"
        )
    )

    beta_ln_t = float(
        _require_cell_value(
            ws,
            ln_t_cell,
            "el beta temporal LN_T"
        )
    )

    beta_h_ln_t = float(
        _require_cell_value(
            ws,
            h_ln_t_cell,
            "el beta temporal H_LN_T"
        )
    )

    return {
        "variable_names": variable_names,
        "transformed_values": np.asarray(
            transformed_values,
            dtype=float
        ),
        "beta_values": np.asarray(
            beta_values,
            dtype=float
        ),
        "beta_ln_t": beta_ln_t,
        "beta_h_ln_t": beta_h_ln_t,
        "ln_t_cell": ln_t_cell,
        "h_ln_t_cell": h_ln_t_cell
    }


def _extract_excel_curve(
    ws,
    excel_config: dict
) -> dict:
    """
    Extrae periodos y resultados cacheados desde el Excel.
    """
    periods_config = excel_config.get(
        "periods",
        {}
    )

    results_config = excel_config.get(
        "expected_results",
        {}
    )

    periods_row = int(
        periods_config.get(
            "row",
            37
        )
    )

    period_start_column = _column_to_index(
        periods_config.get(
            "start_column",
            "B"
        )
    )

    period_end_column = _column_to_index(
        periods_config.get(
            "end_column",
            "BG"
        )
    )

    results_row = int(
        results_config.get(
            "row",
            38
        )
    )

    result_start_column = _column_to_index(
        results_config.get(
            "start_column",
            "B"
        )
    )

    result_end_column = _column_to_index(
        results_config.get(
            "end_column",
            "BG"
        )
    )

    period_column_count = (
        period_end_column
        - period_start_column
    )

    result_column_count = (
        result_end_column
        - result_start_column
    )

    if (
        period_column_count
        != result_column_count
    ):
        raise ValueError(
            "El rango de periodos y el rango de resultados "
            "no tienen la misma cantidad de columnas."
        )

    periods = []
    expected_values = []
    coordinates = []

    for offset in range(
        period_column_count + 1
    ):
        period_column = (
            period_start_column
            + offset
        )

        result_column = (
            result_start_column
            + offset
        )

        period = ws.cell(
            row=periods_row,
            column=period_column
        ).value

        expected_value = ws.cell(
            row=results_row,
            column=result_column
        ).value

        if (
            period is None
            and expected_value is None
        ):
            continue

        if period is None:
            raise ValueError(
                "Existe un resultado sin periodo en "
                f"{ws.cell(results_row, result_column).coordinate}."
            )

        if expected_value is None:
            raise ValueError(
                "Existe un periodo sin resultado cacheado en "
                f"{ws.cell(periods_row, period_column).coordinate}."
            )

        periods.append(
            float(period)
        )

        expected_values.append(
            float(expected_value)
        )

        coordinates.append(
            ws.cell(
                row=results_row,
                column=result_column
            ).coordinate
        )

    if not periods:
        raise ValueError(
            "No se encontraron periodos ni resultados "
            "en el rango configurado."
        )

    return {
        "periods": np.asarray(
            periods,
            dtype=float
        ),
        "expected_values": np.asarray(
            expected_values,
            dtype=float
        ),
        "coordinates": coordinates
    }


def _load_theta(
    theta_path: Path
) -> pd.DataFrame:
    """
    Carga y normaliza el archivo de coeficientes.
    """
    theta = pd.read_csv(
        theta_path,
        encoding="utf-8-sig"
    )

    if theta.empty:
        raise ValueError(
            f"{theta_path} no contiene registros."
        )

    theta.columns = [
        str(column).strip()
        for column in theta.columns
    ]

    return theta


def _reconstruct_formula(
    transformed_values: np.ndarray,
    beta_values: np.ndarray,
    periods: np.ndarray,
    beta_ln_t: float,
    beta_h_ln_t: float
) -> dict:
    """
    Reconstruye el cálculo principal de la curva EAD.
    """
    if (
        len(transformed_values)
        != len(beta_values)
    ):
        raise ValueError(
            "La cantidad de variables transformadas no coincide "
            "con la cantidad de betas principales."
        )

    base_score = float(
        np.dot(
            transformed_values,
            beta_values
        )
    )

    ln_t = np.log(
        periods
    )

    h_ln_t = np.maximum(
        0.0,
        ln_t - np.log(6.0)
    )

    calculated_values = (
        base_score
        + ln_t * beta_ln_t
        + h_ln_t * beta_h_ln_t
    )

    return {
        "base_score": base_score,
        "ln_t": ln_t,
        "h_ln_t": h_ln_t,
        "calculated_values": calculated_values
    }


def _compare_curve(
    periods: np.ndarray,
    expected_values: np.ndarray,
    calculated_values: np.ndarray,
    coordinates: list[str],
    absolute_tolerance: float,
    relative_tolerance: float
) -> pd.DataFrame:
    """
    Compara los resultados reconstruidos contra los
    valores cacheados en el Excel.
    """
    if (
        len(expected_values)
        != len(calculated_values)
    ):
        raise ValueError(
            "La cantidad de resultados esperados no coincide "
            "con la cantidad de resultados calculados."
        )

    absolute_difference = np.abs(
        calculated_values
        - expected_values
    )

    relative_difference = np.divide(
        absolute_difference,
        np.maximum(
            np.abs(expected_values),
            1e-15
        )
    )

    within_tolerance = np.isclose(
        calculated_values,
        expected_values,
        atol=absolute_tolerance,
        rtol=relative_tolerance
    )

    return pd.DataFrame({
        "excel_cell": coordinates,
        "period": periods.astype(int),
        "excel_expected": expected_values,
        "python_calculated": calculated_values,
        "absolute_difference": absolute_difference,
        "relative_difference": relative_difference,
        "within_tolerance": within_tolerance
    })


def _compare_main_betas(
    variable_names: list[str],
    beta_values: np.ndarray,
    theta: pd.DataFrame,
    variable_mapping: dict,
    absolute_tolerance: float,
    relative_tolerance: float
) -> pd.DataFrame:
    """
    Compara betas por nombre funcional, no por posición.
    """
    theta_row = theta.iloc[0]

    normalized_mapping = {
        _normalise_name(
            excel_name
        ): str(
            python_name
        ).strip()
        for excel_name, python_name
        in variable_mapping.items()
    }

    records = []

    for excel_name, excel_beta in zip(
        variable_names,
        beta_values
    ):
        normalized_excel_name = _normalise_name(
            excel_name
        )

        python_name = normalized_mapping.get(
            normalized_excel_name
        )

        if python_name is None:
            records.append({
                "excel_variable": excel_name,
                "python_variable": None,
                "excel_beta": float(excel_beta),
                "python_beta": np.nan,
                "absolute_difference": np.nan,
                "relative_difference": np.nan,
                "within_tolerance": False,
                "mapping_status": "NO_MAPPED"
            })

            continue

        if python_name not in theta.columns:
            records.append({
                "excel_variable": excel_name,
                "python_variable": python_name,
                "excel_beta": float(excel_beta),
                "python_beta": np.nan,
                "absolute_difference": np.nan,
                "relative_difference": np.nan,
                "within_tolerance": False,
                "mapping_status": "MISSING_IN_THETA"
            })

            continue

        python_beta = float(
            theta_row[
                python_name
            ]
        )

        absolute_difference = abs(
            float(excel_beta)
            - python_beta
        )

        relative_difference = (
            absolute_difference
            / max(
                abs(
                    float(excel_beta)
                ),
                1e-15
            )
        )

        within_tolerance = bool(
            np.isclose(
                float(excel_beta),
                python_beta,
                atol=absolute_tolerance,
                rtol=relative_tolerance
            )
        )

        records.append({
            "excel_variable": excel_name,
            "python_variable": python_name,
            "excel_beta": float(excel_beta),
            "python_beta": python_beta,
            "absolute_difference": absolute_difference,
            "relative_difference": relative_difference,
            "within_tolerance": within_tolerance,
            "mapping_status": "MAPPED"
        })

    return pd.DataFrame(
        records
    )


def _compare_temporal_betas(
    beta_ln_t: float,
    beta_h_ln_t: float,
    theta: pd.DataFrame,
    temporal_mapping: dict,
    absolute_tolerance: float,
    relative_tolerance: float
) -> pd.DataFrame:
    """
    Compara los coeficientes temporales LN_T y H_LN_T.
    """
    theta_row = theta.iloc[0]

    ln_python_name = str(
        temporal_mapping.get(
            "LN_T",
            "distancia_def"
        )
    ).strip()

    h_ln_python_name = str(
        temporal_mapping.get(
            "H_LN_T",
            "h_distancia_def"
        )
    ).strip()

    records = []

    for (
        excel_name,
        excel_beta,
        python_name
    ) in [
        (
            "LN_T",
            beta_ln_t,
            ln_python_name
        ),
        (
            "H_LN_T",
            beta_h_ln_t,
            h_ln_python_name
        )
    ]:
        if python_name not in theta.columns:
            records.append({
                "excel_variable": excel_name,
                "python_variable": python_name,
                "excel_beta": float(excel_beta),
                "python_beta": np.nan,
                "absolute_difference": np.nan,
                "relative_difference": np.nan,
                "within_tolerance": False,
                "mapping_status": "MISSING_IN_THETA"
            })

            continue

        python_beta = float(
            theta_row[
                python_name
            ]
        )

        absolute_difference = abs(
            float(excel_beta)
            - python_beta
        )

        relative_difference = (
            absolute_difference
            / max(
                abs(
                    float(excel_beta)
                ),
                1e-15
            )
        )

        within_tolerance = bool(
            np.isclose(
                float(excel_beta),
                python_beta,
                atol=absolute_tolerance,
                rtol=relative_tolerance
            )
        )

        records.append({
            "excel_variable": excel_name,
            "python_variable": python_name,
            "excel_beta": float(excel_beta),
            "python_beta": python_beta,
            "absolute_difference": absolute_difference,
            "relative_difference": relative_difference,
            "within_tolerance": within_tolerance,
            "mapping_status": "MAPPED"
        })

    return pd.DataFrame(
        records
    )


def _safe_max(
    values: pd.Series
) -> float | None:
    """
    Devuelve el máximo de una serie o None cuando no hay datos.
    """
    if values.empty:
        return None

    numeric_values = pd.to_numeric(
        values,
        errors="coerce"
    ).dropna()

    if numeric_values.empty:
        return None

    return float(
        numeric_values.max()
    )

def _load_production_callable(
    project_root: Path,
    module_name: str,
    function_name: str
):
    """
    Importa dinámicamente una función productiva desde
    el repositorio analizado.
    """
    project_root_text = str(
        project_root
    )

    added_to_path = False

    if project_root_text not in sys.path:
        sys.path.insert(
            0,
            project_root_text
        )

        added_to_path = True

    try:
        module = importlib.import_module(
            module_name
        )

        function = getattr(
            module,
            function_name,
            None
        )

        if function is None:
            raise AttributeError(
                f"El módulo {module_name} no contiene "
                f"la función {function_name}."
            )

        if not callable(function):
            raise TypeError(
                f"{module_name}.{function_name} "
                "no es invocable."
            )

        return function

    finally:
        # No retirar el path si los módulos importados pueden
        # necesitar importaciones diferidas desde el proyecto.
        if added_to_path:
            pass

def _build_production_input(
    model_inputs: dict,
    variable_mapping: dict,
    theta: pd.DataFrame,
    production_config: dict
) -> pd.DataFrame:
    """
    Construye el DataFrame transformado requerido por ead_predict.

    Utiliza las variables transformadas almacenadas en Excel.
    Agrega entradas controladas para linea y suma_saldos.
    """
    normalized_mapping = {
        _normalise_name(
            excel_name
        ): str(
            python_name
        ).strip()
        for excel_name, python_name
        in variable_mapping.items()
    }

    row = {}

    for excel_name, transformed_value in zip(
        model_inputs["variable_names"],
        model_inputs["transformed_values"]
    ):
        normalized_excel_name = _normalise_name(
            excel_name
        )

        python_name = normalized_mapping.get(
            normalized_excel_name
        )

        if python_name is None:
            raise ValueError(
                "No existe mapeo para la variable Excel: "
                f"{excel_name}"
            )

        row[python_name] = float(
            transformed_value
        )

    # ead_predict obtiene las columnas del propio param_T.
    # Por ello se valida que todas las variables estén presentes.
    theta_columns = [
        str(column).strip()
        for column in theta.columns
        if str(column).strip() not in {
            "distancia_def",
            "h_distancia_def"
        }
    ]

    missing_input_columns = [
        column
        for column in theta_columns
        if column not in row
    ]

    if missing_input_columns:
        raise ValueError(
            "Faltan variables transformadas para ejecutar "
            "ead_predict: "
            + ", ".join(
                missing_input_columns
            )
        )

    controlled_line = float(
        production_config.get(
            "controlled_line",
            1.0
        )
    )

    balance_periods = int(
        production_config.get(
            "balance_periods",
            60
        )
    )

    controlled_balance = float(
        production_config.get(
            "controlled_balance",
            0.0
        )
    )

    row["linea"] = controlled_line

    row["suma_saldos"] = [
        controlled_balance
        for _ in range(
            balance_periods
        )
    ]

    return pd.DataFrame([
        row
    ])

def _extract_curve_from_result(
    result,
    expected_length: int = 60
) -> np.ndarray:
    """
    Extrae la curva retornada por ead_predict.

    La función productiva devuelve:
      (curve_dataframe, transformed_dataframe)
    """
    if not isinstance(
        result,
        tuple
    ):
        raise TypeError(
            "ead_predict no devolvió una tupla."
        )

    if len(result) < 1:
        raise ValueError(
            "ead_predict devolvió una tupla vacía."
        )

    curve_result = result[0]

    if isinstance(
        curve_result,
        pd.DataFrame
    ):
        if "curve" in curve_result.columns:
            value = curve_result.iloc[0][
                "curve"
            ]
        elif curve_result.shape[1] == 1:
            value = curve_result.iloc[
                0,
                0
            ]
        else:
            raise ValueError(
                "No se pudo identificar la columna de curva "
                "en el DataFrame retornado."
            )

    elif isinstance(
        curve_result,
        pd.Series
    ):
        value = curve_result.iloc[0]

    else:
        value = curve_result

    curve = np.asarray(
        value,
        dtype=float
    ).reshape(-1)

    if len(curve) != expected_length:
        raise ValueError(
            "La curva productiva tiene "
            f"{len(curve)} periodos; se esperaban "
            f"{expected_length}."
        )

    return curve

def _run_production_function_reconciliation(
    project_root: Path,
    model_inputs: dict,
    curve_data: dict,
    theta: pd.DataFrame,
    variable_mapping: dict,
    production_config: dict,
    absolute_tolerance: float,
    relative_tolerance: float
) -> tuple[dict, pd.DataFrame]:
    """
    Ejecuta directamente source.engine.utils.ead_predict.

    La entrada utiliza valores transformados del Excel.
    linea se fija en 1 y suma_saldos en cero para comparar
    el factor EAD sin ajustes monetarios posteriores.
    """
    enabled = bool(
        production_config.get(
            "enabled",
            False
        )
    )

    if not enabled:
        return (
            {
                "status": "NOT_RUN",
                "reason": (
                    "La reconciliación de función productiva "
                    "está deshabilitada."
                ),
                "function_executed": False
            },
            pd.DataFrame()
        )

    module_name = str(
        production_config.get(
            "module",
            "source.engine.utils"
        )
    ).strip()

    function_name = str(
        production_config.get(
            "function",
            "ead_predict"
        )
    ).strip()

    production_function = _load_production_callable(
        project_root=project_root,
        module_name=module_name,
        function_name=function_name
    )

    production_input = _build_production_input(
        model_inputs=model_inputs,
        variable_mapping=variable_mapping,
        theta=theta,
        production_config=production_config
    )

    # param_probs aparece en la firma, pero el cuerpo de
    # ead_predict proporcionado no utiliza ese parámetro.
    param_probs = production_config.get(
        "param_probs",
        None
    )

    production_result = production_function(
        production_input,
        theta,
        param_probs
    )

    production_curve_full = _extract_curve_from_result(
        production_result,
        expected_length=int(
            production_config.get(
                "curve_periods",
                60
            )
        )
    )

    periods = curve_data[
        "periods"
    ].astype(int)

    # El periodo 1 ocupa la posición 0.
    positions = periods - 1

    if np.any(
        positions < 0
    ):
        raise ValueError(
            "Se encontraron periodos menores que 1."
        )

    if np.any(
        positions >= len(
            production_curve_full
        )
    ):
        raise ValueError(
            "Los periodos del Excel exceden la longitud "
            "de la curva productiva."
        )

    production_curve = production_curve_full[
        positions
    ]

    expected_values = curve_data[
        "expected_values"
    ]

    absolute_difference = np.abs(
        production_curve
        - expected_values
    )

    relative_difference = np.divide(
        absolute_difference,
        np.maximum(
            np.abs(
                expected_values
            ),
            1e-15
        )
    )

    within_tolerance = np.isclose(
        production_curve,
        expected_values,
        atol=absolute_tolerance,
        rtol=relative_tolerance
    )

    comparison = pd.DataFrame({
        "excel_cell": curve_data[
            "coordinates"
        ],
        "period": periods,
        "excel_expected": expected_values,
        "production_calculated": (
            production_curve
        ),
        "absolute_difference": (
            absolute_difference
        ),
        "relative_difference": (
            relative_difference
        ),
        "within_tolerance": (
            within_tolerance
        )
    })

    curve_match = bool(
        within_tolerance.all()
    )

    result = {
        "status": (
            "MATCH"
            if curve_match
            else "DIVERGE"
        ),
        "mode": "PRODUCTION_FUNCTION",
        "function": (
            f"{module_name}.{function_name}"
        ),
        "function_executed": True,
        "controlled_line": float(
            production_config.get(
                "controlled_line",
                1.0
            )
        ),
        "controlled_balance": float(
            production_config.get(
                "controlled_balance",
                0.0
            )
        ),
        "periods_compared": int(
            len(periods)
        ),
        "matching_periods": int(
            within_tolerance.sum()
        ),
        "non_matching_periods": int(
            (
                ~within_tolerance
            ).sum()
        ),
        "curve_match": curve_match,
        "max_absolute_difference": (
            float(
                absolute_difference.max()
            )
        ),
        "max_relative_difference": (
            float(
                relative_difference.max()
            )
        ),
        "scope": (
            "Ejecución directa de ead_predict usando "
            "variables transformadas del Excel, linea=1 "
            "y suma_saldos=0."
        ),
        "end_to_end_from_raw_inputs": False
    }

    return (
        result,
        comparison
    )

def _build_summary(
    model_inputs: dict,
    curve_data: dict,
    curve_comparison: pd.DataFrame,
    beta_comparison: pd.DataFrame,
    temporal_beta_comparison: pd.DataFrame,
    formula_result: dict,
    reconciliation_config: dict
) -> dict:
    """
    Construye el resultado estructurado de la reconciliación.
    """
    expected_periods_config = (
        reconciliation_config.get(
            "expected_periods",
            {}
        )
    )

    expected_start = int(
        expected_periods_config.get(
            "start",
            3
        )
    )

    expected_end = int(
        expected_periods_config.get(
            "end",
            60
        )
    )

    periods = curve_data[
        "periods"
    ]

    expected_period_array = np.arange(
        expected_start,
        expected_end + 1
    )

    periods_match_expected_range = bool(
        len(periods)
        == len(expected_period_array)
        and np.array_equal(
            periods.astype(int),
            expected_period_array
        )
    )

    curve_match = bool(
        curve_comparison[
            "within_tolerance"
        ].all()
    )

    all_betas_mapped = bool(
        not beta_comparison.empty
        and (
            beta_comparison[
                "mapping_status"
            ]
            == "MAPPED"
        ).all()
    )

    model_betas_match = bool(
        all_betas_mapped
        and beta_comparison[
            "within_tolerance"
        ].all()
    )

    all_temporal_betas_mapped = bool(
        not temporal_beta_comparison.empty
        and (
            temporal_beta_comparison[
                "mapping_status"
            ]
            == "MAPPED"
        ).all()
    )

    temporal_betas_match = bool(
        all_temporal_betas_mapped
        and temporal_beta_comparison[
            "within_tolerance"
        ].all()
    )

    overall_match = bool(
        curve_match
        and periods_match_expected_range
        and model_betas_match
        and temporal_betas_match
    )

    status = (
        "MATCH"
        if overall_match
        else "DIVERGE"
    )

    return {
        "status": status,
        "mode": "FORMULA_RECONSTRUCTION",
        "scope": (
            "Reconstrucción de la fórmula EAD usando "
            "valores transformados almacenados en Excel"
        ),
        "end_to_end_from_raw_inputs": False,
        "sheet": reconciliation_config.get(
            "sheet",
            "Hoja1"
        ),
        "periods_compared": int(
            len(periods)
        ),
        "first_period": (
            int(periods[0])
            if len(periods)
            else None
        ),
        "last_period": (
            int(periods[-1])
            if len(periods)
            else None
        ),
        "expected_first_period": expected_start,
        "expected_last_period": expected_end,
        "periods_match_expected_range": (
            periods_match_expected_range
        ),
        "matching_periods": int(
            curve_comparison[
                "within_tolerance"
            ].sum()
        ),
        "non_matching_periods": int(
            (
                ~curve_comparison[
                    "within_tolerance"
                ]
            ).sum()
        ),
        "max_absolute_difference": _safe_max(
            curve_comparison[
                "absolute_difference"
            ]
        ),
        "max_relative_difference": _safe_max(
            curve_comparison[
                "relative_difference"
            ]
        ),
        "curve_match": curve_match,
        "all_betas_mapped": all_betas_mapped,
        "model_betas_match": model_betas_match,
        "all_temporal_betas_mapped": (
            all_temporal_betas_mapped
        ),
        "temporal_betas_match": (
            temporal_betas_match
        ),
        "base_score_excel": float(
            formula_result[
                "base_score"
            ]
        ),
        "variables_compared": len(
            model_inputs[
                "variable_names"
            ]
        ),
        "absolute_tolerance": float(
            _get_config_value(
                reconciliation_config,
                [
                    "tolerances",
                    "absolute"
                ],
                1e-10
            )
        ),
        "relative_tolerance": float(
            _get_config_value(
                reconciliation_config,
                [
                    "tolerances",
                    "relative"
                ],
                1e-9
            )
        )
    }


def _write_csv(
    path: Path,
    dataframe: pd.DataFrame
) -> None:
    """
    Exporta un DataFrame con codificación compatible con Excel.
    """
    dataframe.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
        quoting=csv.QUOTE_MINIMAL
    )


def _write_reconciliation_markdown(
    result: dict,
    output_dir: Path
) -> None:
    """
    Genera el reporte 08_reconciliacion.md.
    """
    status = result.get(
        "status",
        "NOT_RUN"
    )

    lines = [
        "# Reconciliación numérica",
        "",
        f"- Estado: **{status}**"
    ]

    mode = result.get(
        "mode",
        "No disponible"
    )

    components = result.get(
        "components",
        []
    )

    if mode == "AUTO":
        lines.extend([
            (
                "- Modo: "
                f"**{mode}**"
            ),
            (
                "- Estrategia seleccionada: "
                f"**{result.get('selected_strategy', 'Ninguna')}**"
            ),
            (
                "- Confianza de estrategia: "
                f"**{result.get('strategy_confidence', 0.0)}**"
            ),
            (
                "- Comparaciones realizadas: "
                f"**{result.get('comparisons', 0)}**"
            ),
            (
                "- Coincidencias: "
                f"**{result.get('matches', 0)}**"
            ),
            (
                "- Diferencias: "
                f"**{result.get('differences', 0)}**"
            )
        ])

        if result.get(
            "reason"
        ):
            lines.append(
                "- Motivo: "
                f"{result.get('reason')}"
            )

        for component in components:
            lines.extend([
                "",
                (
                    "## "
                    f"{component.get('title', 'Componente')}"
                ),
                "",
                (
                    "- Estrategia: "
                    f"**{component.get('strategy', '')}**"
                ),
                (
                    "- Estado: "
                    f"**{component.get('status', 'NOT_RUN')}**"
                ),
                (
                    "- Confianza: "
                    f"**{component.get('confidence', 0.0)}**"
                ),
                (
                    "- Comparaciones: "
                    f"**{component.get('comparisons', 0)}**"
                ),
                (
                    "- Coincidencias: "
                    f"**{component.get('matches', 0)}**"
                ),
                (
                    "- Diferencias: "
                    f"**{component.get('differences', 0)}**"
                )
            ])

            if component.get(
                "reason"
            ):
                lines.append(
                    "- Motivo: "
                    f"{component.get('reason')}"
                )

            artifacts = component.get(
                "artifacts",
                []
            )

            if artifacts:
                lines.extend([
                    "",
                    "### Artefactos",
                    ""
                ])

                for artifact in artifacts:
                    lines.append(
                        f"- `{artifact}`"
                    )

        write_text(
            output_dir
            / "08_reconciliacion.md",
            "\n".join(lines)
        )

        return
        
    if status in {
        "NOT_RUN",
        "ERROR"
    }:
        lines.extend([
            (
                "- Motivo: "
                f"{result.get('reason', '')}"
            )
        ])

        missing_items = result.get(
            "missing_items",
            []
        )

        if missing_items:
            lines.extend([
                "",
                "## Elementos faltantes",
                ""
            ])

            for item in missing_items:
                lines.append(
                    f"- `{item}`"
                )

        write_text(
            output_dir
            / "08_reconciliacion.md",
            "\n".join(lines)
        )

        return

    max_absolute_difference = result.get(
        "max_absolute_difference"
    )

    max_relative_difference = result.get(
        "max_relative_difference"
    )

    lines.extend([
        (
            "- Modo: "
            f"**{result.get('mode', '')}**"
        ),
        (
            "- Periodos comparados: "
            f"**{result.get('periods_compared', 0)}**"
        ),
        (
            "- Rango de periodos: "
            f"**{result.get('first_period')} a "
            f"{result.get('last_period')}**"
        ),
        (
            "- Periodos dentro de tolerancia: "
            f"**{result.get('matching_periods', 0)}**"
        ),
        (
            "- Periodos fuera de tolerancia: "
            f"**{result.get('non_matching_periods', 0)}**"
        ),
        (
            "- Diferencia absoluta máxima: "
            f"**{max_absolute_difference:.16g}**"
        ),
        (
            "- Diferencia relativa máxima: "
            f"**{max_relative_difference:.16g}**"
        ),
        (
            "- Betas principales mapeadas: "
            f"**{result.get('all_betas_mapped', False)}**"
        ),
        (
            "- Betas principales coincidentes: "
            f"**{result.get('model_betas_match', False)}**"
        ),
        (
            "- Betas temporales coincidentes: "
            f"**{result.get('temporal_betas_match', False)}**"
        ),
        (
            "- Rango esperado completo: "
            f"**{result.get('periods_match_expected_range', False)}**"
        ),
        "",
        "## Alcance",
        "",
        str(
            result.get(
                "scope",
                ""
            )
        ),
        "",
        (
            "Esta validación no ejecuta todavía el flujo "
            "end-to-end desde variables crudas."
        ),
        "",
        "## Resultado",
        ""
    ])

    if status == "MATCH":
        lines.append(
            "La fórmula principal reconstruida en Python "
            "coincide con los resultados almacenados en el "
            "Excel dentro de las tolerancias configuradas. "
            "Los coeficientes se compararon por nombre "
            "funcional, independientemente de su orden físico."
        )

    else:
        failed_components = []

        if not result.get(
            "curve_match",
            False
        ):
            failed_components.append(
                "curva"
            )

        if not result.get(
            "all_betas_mapped",
            False
        ):
            failed_components.append(
                "mapeo de betas principales"
            )

        if not result.get(
            "model_betas_match",
            False
        ):
            failed_components.append(
                "betas principales"
            )

        if not result.get(
            "temporal_betas_match",
            False
        ):
            failed_components.append(
                "betas temporales"
            )

        if not result.get(
            "periods_match_expected_range",
            False
        ):
            failed_components.append(
                "rango de periodos"
            )

        lines.append(
            "Se detectaron diferencias o elementos pendientes "
            "en: "
            + ", ".join(
                failed_components
            )
            + "."
        )

    write_text(
        output_dir
        / "08_reconciliacion.md",
        "\n".join(lines)
    )


def _write_reconciliation_outputs(
    result: dict,
    curve_comparison: pd.DataFrame | None,
    beta_comparison: pd.DataFrame | None,
    temporal_beta_comparison: pd.DataFrame | None,
    output_dir: Path
) -> None:
    """
    Guarda los artefactos estructurados de reconciliación.
    """
    artifacts_dir = (
        output_dir
        / "artifacts"
    )

    artifacts_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    dump_json(
        artifacts_dir
        / "reconciliation.json",
        result
    )

    if curve_comparison is not None:
        _write_csv(
            artifacts_dir
            / "reconciliation_periods.csv",
            curve_comparison
        )

    if beta_comparison is not None:
        _write_csv(
            artifacts_dir
            / "reconciliation_betas.csv",
            beta_comparison
        )

    if temporal_beta_comparison is not None:
        _write_csv(
            artifacts_dir
            / "reconciliation_temporal_betas.csv",
            temporal_beta_comparison
        )

    _write_reconciliation_markdown(
        result=result,
        output_dir=output_dir
    )


def _run_formula_reconstruction(
    wb,
    project_root: Path,
    output_dir: Path,
    reconciliation_config: dict
) -> dict:
    """
    Ejecuta la modalidad FORMULA_RECONSTRUCTION.
    """
    sheet_name = str(
        reconciliation_config.get(
            "sheet",
            "Hoja1"
        )
    )

    if sheet_name not in wb.sheetnames:
        result = _not_run_result(
            reason=(
                f"No se encontró la hoja "
                f"'{sheet_name}' en el Excel."
            ),
            missing_items=[
                sheet_name
            ]
        )

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    ws = wb[
        sheet_name
    ]

    excel_config = reconciliation_config.get(
        "excel",
        {}
    )

    absolute_tolerance = float(
        _get_config_value(
            reconciliation_config,
            [
                "tolerances",
                "absolute"
            ],
            1e-10
        )
    )

    relative_tolerance = float(
        _get_config_value(
            reconciliation_config,
            [
                "tolerances",
                "relative"
            ],
            1e-9
        )
    )

    model_inputs = _extract_excel_model_inputs(
        ws=ws,
        excel_config=excel_config
    )
    discovery_config = (
        reconciliation_config.get(
            "parameter_discovery",
            {}
        )
    )

    discovery_enabled = bool(
        discovery_config.get(
            "enabled",
            True
        )
    )

    if discovery_enabled:
        discovery_result = _discover_theta_file(
            project_root=project_root,
            discovery_config=discovery_config,
            model_inputs=model_inputs,
            absolute_tolerance=absolute_tolerance,
            relative_tolerance=relative_tolerance
        )

        artifacts_dir = (
            output_dir
            / "artifacts"
        )

        artifacts_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        dump_json(
            artifacts_dir
            / "parameter_discovery.json",
            discovery_result
        )
        if (
            discovery_result.get(
                "status"
            )
            != "SELECTED"
        ):
            result = _not_run_result(
                reason=(
                    "No se pudo identificar con suficiente "
                    "confianza el archivo de betas. Estado: "
                    f"{discovery_result.get('status')}"
                )
            )

            result[
                "parameter_discovery"
            ] = discovery_result

            _write_reconciliation_outputs(
                result=result,
                curve_comparison=None,
                beta_comparison=None,
                temporal_beta_comparison=None,
                output_dir=output_dir
            )

            return result

        theta_path = Path(
            discovery_result[
                "selected_path"
            ]
        )

    else:
        theta_path_text = str(
            _get_config_value(
                reconciliation_config,
                [
                    "theta_file",
                    "path"
                ],
                ""
            )
        ).strip()

        if not theta_path_text:
            result = _not_run_result(
                reason=(
                    "El descubrimiento automático está "
                    "deshabilitado y no se configuró theta_file."
                )
            )

            _write_reconciliation_outputs(
                result=result,
                curve_comparison=None,
                beta_comparison=None,
                temporal_beta_comparison=None,
                output_dir=output_dir
            )

            return result

        theta_path = _resolve_project_file(
            project_root=project_root,
            configured_path=theta_path_text
        )

        if not theta_path.is_file():
            result = _not_run_result(
                reason=(
                    "No se encontró el archivo manual "
                    "de parámetros."
                ),
                missing_items=[
                    str(theta_path)
                ]
            )

            _write_reconciliation_outputs(
                result=result,
                curve_comparison=None,
                beta_comparison=None,
                temporal_beta_comparison=None,
                output_dir=output_dir
            )

            return result
        discovery_result = {
            "status": "MANUAL",
            "selected_path": str(
                theta_path
            ),
            "confidence": None
        }
    curve_data = _extract_excel_curve(
        ws=ws,
        excel_config=excel_config
    )

    theta = _load_theta(
        theta_path
    )

    formula_result = _reconstruct_formula(
        transformed_values=model_inputs[
            "transformed_values"
        ],
        beta_values=model_inputs[
            "beta_values"
        ],
        periods=curve_data[
            "periods"
        ],
        beta_ln_t=model_inputs[
            "beta_ln_t"
        ],
        beta_h_ln_t=model_inputs[
            "beta_h_ln_t"
        ]
    )

    curve_comparison = _compare_curve(
        periods=curve_data[
            "periods"
        ],
        expected_values=curve_data[
            "expected_values"
        ],
        calculated_values=formula_result[
            "calculated_values"
        ],
        coordinates=curve_data[
            "coordinates"
        ],
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance
    )

    # =========================================================
    # USAR EL MAPEO IDENTIFICADO DURANTE EL DESCUBRIMIENTO
    # =========================================================

    if (
        discovery_result.get(
            "status"
        )
        == "SELECTED"
    ):
        variable_mapping = dict(
            discovery_result.get(
                "resolved_mapping",
                {}
            )
        )

        temporal_mapping = dict(
            discovery_result.get(
                "temporal_mapping",
                {}
            )
        )

    else:
        # Respaldo manual únicamente cuando el descubrimiento
        # automático está deshabilitado.
        variable_mapping = dict(
            reconciliation_config.get(
                "variable_mapping",
                {}
            )
        )

        temporal_mapping = dict(
            reconciliation_config.get(
                "temporal_variable_mapping",
                {}
            )
        )


    if not variable_mapping:
        raise ValueError(
            "No se pudo construir el mapeo entre las "
            "variables del Excel y las columnas del archivo "
            "de parámetros seleccionado."
        )

    if not temporal_mapping:
        raise ValueError(
            "No se pudo construir el mapeo de los "
            "coeficientes temporales."
        )


    beta_comparison = _compare_main_betas(
        variable_names=model_inputs[
            "variable_names"
        ],
        beta_values=model_inputs[
            "beta_values"
        ],
        theta=theta,
        variable_mapping=variable_mapping,
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance
    )

    temporal_beta_comparison = (
        _compare_temporal_betas(
            beta_ln_t=model_inputs[
                "beta_ln_t"
            ],
            beta_h_ln_t=model_inputs[
                "beta_h_ln_t"
            ],
            theta=theta,
            temporal_mapping=temporal_mapping,
            absolute_tolerance=absolute_tolerance,
            relative_tolerance=relative_tolerance
        )
    )

    production_config = reconciliation_config.get(
        "production_function",
        {}
    )

    try:
        (
            production_result,
            production_comparison
        ) = _run_production_function_reconciliation(
            project_root=project_root,
            model_inputs=model_inputs,
            curve_data=curve_data,
            theta=theta,
            variable_mapping=variable_mapping,
            production_config=production_config,
            absolute_tolerance=absolute_tolerance,
            relative_tolerance=relative_tolerance
        )

    except Exception as exc:
        production_result = {
            "status": "ERROR",
            "mode": "PRODUCTION_FUNCTION",
            "function": (
                f"{production_config.get('module', '')}."
                f"{production_config.get('function', '')}"
            ),
            "function_executed": False,
            "reason": (
                f"{type(exc).__name__}: {exc}"
            ),
            "curve_match": False,
            "periods_compared": 0,
            "matching_periods": 0,
            "non_matching_periods": 0,
            "end_to_end_from_raw_inputs": False
        }

        production_comparison = pd.DataFrame()

    result = _build_summary(
        model_inputs=model_inputs,
        curve_data=curve_data,
        curve_comparison=curve_comparison,
        beta_comparison=beta_comparison,
        temporal_beta_comparison=(
            temporal_beta_comparison
        ),
        formula_result=formula_result,
        reconciliation_config=(
            reconciliation_config
        )
    )

    selected_candidate = (
        discovery_result.get(
            "selected_candidate",
            {}
        )
    )

    try:
        selected_theta_file = str(
            theta_path.relative_to(
                project_root
            )
        )
    except ValueError:
        selected_theta_file = str(
            theta_path
        )

    result["parameter_discovery"] = {
        "status": discovery_result.get(
            "status"
        ),
        "selected_file": selected_theta_file,
        "confidence": discovery_result.get(
            "confidence"
        ),
        "name_coverage": selected_candidate.get(
            "name_coverage"
        ),
        "value_coverage": selected_candidate.get(
            "value_coverage"
        ),
        "temporal_name_coverage": (
            selected_candidate.get(
                "temporal_name_coverage"
            )
        ),
        "temporal_value_coverage": (
            selected_candidate.get(
                "temporal_value_coverage"
            )
        ),
        "matched_variables": (
            selected_candidate.get(
                "matched_variables",
                []
            )
        ),
        "unmatched_variables": (
            selected_candidate.get(
                "unmatched_variables",
                []
            )
        ),
        "resolved_mapping": variable_mapping,
        "temporal_mapping": temporal_mapping
    }
    formula_status = result.get(
        "status",
        "NOT_RUN"
    )

    production_status = production_result.get(
        "status",
        "NOT_RUN"
    )

    result["formula_reconstruction"] = {
        "status": formula_status,
        "curve_match": result.get(
            "curve_match",
            False
        ),
        "periods_compared": result.get(
            "periods_compared",
            0
        ),
        "matching_periods": result.get(
            "matching_periods",
            0
        ),
        "non_matching_periods": result.get(
            "non_matching_periods",
            0
        ),
        "max_absolute_difference": result.get(
            "max_absolute_difference"
        ),
        "max_relative_difference": result.get(
            "max_relative_difference"
        )
    }

    result["production_function"] = (
        production_result
    )

    if (
        formula_status == "DIVERGE"
        or production_status == "DIVERGE"
    ):
        result["status"] = "DIVERGE"

    elif (
        formula_status == "MATCH"
        and production_status == "MATCH"
    ):
        result["status"] = "MATCH"

    elif production_status == "ERROR":
        result["status"] = "ERROR"

    else:
        result["status"] = formula_status

    result["theta_file"] = (
        selected_theta_file
    )

    if not production_comparison.empty:
        _write_csv(
            output_dir
            / "artifacts"
            / "reconciliation_production_function.csv",
            production_comparison
        )

    _write_reconciliation_outputs(
        result=result,
        curve_comparison=curve_comparison,
        beta_comparison=beta_comparison,
        temporal_beta_comparison=(
            temporal_beta_comparison
        ),
        output_dir=output_dir
    )

    return result

def _build_auto_summary(
    discovery_result: dict,
    components: list[dict]
) -> dict:
    """
    Consolida los componentes ejecutados por las estrategias
    genéricas en un resultado común de reconciliación.
    """
    executed_components = [
        component
        for component in components
        if component.get(
            "status"
        )
        in {
            "MATCH",
            "DIVERGE"
        }
    ]

    error_components = [
        component
        for component in components
        if component.get(
            "status"
        )
        == "ERROR"
    ]

    diverging_components = [
        component
        for component in components
        if component.get(
            "status"
        )
        == "DIVERGE"
    ]

    matching_components = [
        component
        for component in components
        if component.get(
            "status"
        )
        == "MATCH"
    ]

    if diverging_components:
        status = "DIVERGE"

    elif error_components:
        status = "ERROR"

    elif executed_components and (
        len(matching_components)
        == len(executed_components)
    ):
        status = "MATCH"

    else:
        status = "NOT_RUN"

    comparisons = sum(
        int(
            component.get(
                "comparisons",
                0
            )
        )
        for component in components
    )

    matches = sum(
        int(
            component.get(
                "matches",
                0
            )
        )
        for component in components
    )

    differences = sum(
        int(
            component.get(
                "differences",
                0
            )
        )
        for component in components
    )

    return {
        "status": status,
        "mode": "AUTO",
        "scope": (
            "Reconciliación numérica basada en estrategias "
            "seleccionadas automáticamente mediante evidencia "
            "estructural del Excel y del repositorio."
        ),
        "end_to_end_from_raw_inputs": False,

        "strategy_discovery": discovery_result,

        "selected_strategy": discovery_result.get(
            "strategy"
        ),

        "strategy_confidence": discovery_result.get(
            "confidence",
            0.0
        ),

        "components": components,

        "components_detected": len(
            components
        ),

        "components_executed": len(
            executed_components
        ),

        "components_matching": len(
            matching_components
        ),

        "components_diverging": len(
            diverging_components
        ),

        "components_with_error": len(
            error_components
        ),

        "comparisons": comparisons,
        "matches": matches,
        "differences": differences,

        # Campos de compatibilidad con report.py.
        "periods_compared": comparisons,
        "matching_periods": matches,
        "non_matching_periods": differences,
        "curve_match": bool(
            comparisons > 0
            and differences == 0
        ),

        # Estos conceptos son específicos del adaptador EAD.
        # En modo genérico no deben asumirse.
        "all_betas_mapped": None,
        "model_betas_match": None,
        "temporal_betas_match": None,
        "periods_match_expected_range": None,

        "max_absolute_difference": _max_component_metric(
            components=components,
            metric="max_absolute_difference"
        ),

        "max_relative_difference": _max_component_metric(
            components=components,
            metric="max_relative_difference"
        ),

        "reason": (
            None
            if status in {
                "MATCH",
                "DIVERGE"
            }
            else (
                "No se ejecutó ninguna estrategia numérica "
                "con evidencia suficiente."
            )
        )
    }


def _max_component_metric(
    components: list[dict],
    metric: str
) -> float | None:
    """
    Obtiene el máximo de una métrica opcional entre
    todos los componentes ejecutados.
    """
    values = []

    for component in components:
        value = component.get(
            metric
        )

        if value is None:
            continue

        try:
            values.append(
                float(value)
            )

        except (
            TypeError,
            ValueError
        ):
            continue

    if not values:
        return None

    return max(
        values
    )


def _get_strategy_by_name(
    strategy_name: str,
    reconciliation_config: dict
):
    """
    Obtiene la instancia de la estrategia seleccionada.
    """
    strategies = get_available_strategies(
        reconciliation_config
    )

    for strategy in strategies:
        if strategy.name == strategy_name:
            return strategy

    return None


def _run_auto_reconciliation(
    wb,
    wb_values,
    project_root: Path,
    output_dir: Path,
    reconciliation_config: dict,
    excel_inventory: dict | None = None,
    rules: list[dict] | None = None,
    project_candidates: list[dict] | None = None
) -> dict:
    """
    Ejecuta el descubrimiento y la reconciliación mediante
    estrategias genéricas.

    No presupone nombres de hojas, filas, periodos,
    variables, coeficientes ni funciones productivas.
    """
    print(
        "[RECONCILIACIÓN] "
        "Construyendo contexto de estrategias",
        flush=True
    )

    context = StrategyContext(
        workbook=wb,
        workbook_values=wb_values,
        excel_inventory=(
            excel_inventory
            or {}
        ),
        rules=(
            rules
            or []
        ),
        project_root=project_root,
        project_candidates=(
            project_candidates
            or []
        ),
        output_dir=output_dir,
        config=reconciliation_config
    )

    print("\n========== CONTEXT ==========")

    print(
        "Workbook:",
        type(context.workbook)
    )

    print(
        "Workbook values:",
        type(context.workbook_values)
    )

    print(
        "Sheets:",
        context.workbook.sheetnames
        if context.workbook
        else None
    )

    print(
        "Inventory keys:",
        list(
            context.excel_inventory.keys()
        )
    )

    print(
        "Rules:",
        len(
            context.rules
        )
    )

    print(
        "Candidates:",
        len(
            context.project_candidates
        )
    )

    print(
        "Config keys:",
        list(
            context.config.keys()
        )
    )

    print("=============================\n")
    print(
        "[RECONCILIACIÓN] "
        "Descubriendo estrategia numérica",
        flush=True
    )

    discovery_result = (
        discover_reconciliation_strategy(
            context
        )
    )

    artifacts_dir = (
        output_dir
        / "artifacts"
    )

    artifacts_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    dump_json(
        artifacts_dir
        / "strategy_discovery.json",
        discovery_result
    )

    discovery_status = discovery_result.get(
        "status"
    )

    print(
        "[RECONCILIACIÓN] "
        f"Descubrimiento: {discovery_status}",
        flush=True
    )

    if discovery_status != "SELECTED":
        result = _not_run_result(
            reason=(
                "No se seleccionó una estrategia numérica. "
                "Estado del descubrimiento: "
                f"{discovery_status}."
            )
        )

        result["mode"] = "AUTO"

        result[
            "strategy_discovery"
        ] = discovery_result

        result[
            "components"
        ] = []

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    strategy_name = str(
        discovery_result.get(
            "strategy",
            ""
        )
    ).strip()

    strategy = _get_strategy_by_name(
        strategy_name=strategy_name,
        reconciliation_config=(
            reconciliation_config
        )
    )

    if strategy is None:
        result = _not_run_result(
            reason=(
                "La estrategia fue seleccionada, pero no "
                "se encontró su implementación: "
                f"{strategy_name}."
            )
        )

        result["mode"] = "AUTO"
        result[
            "strategy_discovery"
        ] = discovery_result

        result[
            "components"
        ] = []

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    print(
        "[RECONCILIACIÓN] "
        f"Ejecutando estrategia: {strategy_name}",
        flush=True
    )

    # Se ejecuta de nuevo detect() para reconstruir
    # StrategyDetection con su payload original.
    #
    # Esto evita depender de convertir manualmente el
    # diccionario serializado nuevamente a dataclass.
    try:
        detection = strategy.detect(
            context
        )

    except Exception as exc:
        component = strategy.error(
            exc
        )

        result = _build_auto_summary(
            discovery_result=discovery_result,
            components=[
                component
            ]
        )

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    minimum_confidence = float(
        reconciliation_config.get(
            "strategy_discovery",
            {}
        ).get(
            "minimum_confidence",
            0.80
        )
    )

    if (
        detection.status != "DETECTED"
        or detection.confidence
        < minimum_confidence
    ):
        result = _not_run_result(
            reason=(
                "La estrategia seleccionada no mantuvo "
                "evidencia suficiente al reconstruir su "
                "detección."
            )
        )

        result["mode"] = "AUTO"

        result[
            "strategy_discovery"
        ] = discovery_result

        result["components"] = []

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    try:
        component = strategy.reconcile(
            context=context,
            detection=detection
        )

    except Exception as exc:
        component = strategy.error(
            exc=exc,
            detection=detection
        )

    print(
        "[RECONCILIACIÓN] "
        f"Estrategia {strategy_name}: "
        f"{component.get('status', 'ERROR')}",
        flush=True
    )

    components = [
        component
    ]

    result = _build_auto_summary(
        discovery_result=discovery_result,
        components=components
    )

    _write_reconciliation_outputs(
        result=result,
        curve_comparison=None,
        beta_comparison=None,
        temporal_beta_comparison=None,
        output_dir=output_dir
    )

    return result

def run_reconciliation(
    wb,
    project_root,
    output_dir,
    config,
    wb_values=None,
    excel_inventory=None,
    rules=None,
    project_candidates=None
) -> dict:
    """
    Punto de entrada de la reconciliación numérica.

    Modos soportados:

      auto
        Descubre y ejecuta una estrategia genérica.

      formula_reconstruction
        Mantiene temporalmente la reconciliación EAD heredada.

    Genera:

      - 08_reconciliacion.md
      - artifacts/reconciliation.json
      - artifacts/strategy_discovery.json
      - artefactos CSV propios de cada estrategia
    """
    project_root = Path(
        project_root
    )

    output_dir = Path(
        output_dir
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    reconciliation_config = (
        config.get(
            "reconciliation",
            {}
        )
        if isinstance(
            config,
            dict
        )
        else {}
    )

    enabled = bool(
        reconciliation_config.get(
            "enabled",
            False
        )
    )

    if not enabled:
        result = _not_run_result(
            reason=(
                "Reconciliación deshabilitada "
                "en la configuración."
            )
        )

        _write_reconciliation_outputs(
            result=result,
            curve_comparison=None,
            beta_comparison=None,
            temporal_beta_comparison=None,
            output_dir=output_dir
        )

        return result

    mode = str(
        reconciliation_config.get(
            "mode",
            "auto"
        )
    ).strip().lower()

    print(
        "[RECONCILIACIÓN] "
        f"Modo configurado: {mode}",
        flush=True
    )

    # =====================================================
    # MODO GENÉRICO
    # =====================================================

    if mode == "auto":
        try:
            return _run_auto_reconciliation(
                wb=wb,
                wb_values=(
                    wb_values
                    if wb_values is not None
                    else wb
                ),
                project_root=project_root,
                output_dir=output_dir,
                reconciliation_config=(
                    reconciliation_config
                ),
                excel_inventory=excel_inventory,
                rules=rules,
                project_candidates=(
                    project_candidates
                )
            )

        except Exception as exc:
            result = {
                "status": "ERROR",
                "mode": "AUTO",
                "reason": (
                    f"{type(exc).__name__}: {exc}"
                ),
                "scope": (
                    "Descubrimiento y ejecución de "
                    "estrategias genéricas."
                ),
                "components": [],
                "periods_compared": 0,
                "matching_periods": 0,
                "non_matching_periods": 0,
                "curve_match": False,
                "max_absolute_difference": None,
                "max_relative_difference": None
            }

            _write_reconciliation_outputs(
                result=result,
                curve_comparison=None,
                beta_comparison=None,
                temporal_beta_comparison=None,
                output_dir=output_dir
            )

            return result

    # =====================================================
    # MODO EAD HEREDADO
    # =====================================================

    if mode == "formula_reconstruction":
        try:
            return _run_formula_reconstruction(
                wb=(
                    wb_values
                    if wb_values is not None
                    else wb
                ),
                project_root=project_root,
                output_dir=output_dir,
                reconciliation_config=(
                    reconciliation_config
                )
            )

        except Exception as exc:
            result = _error_result(
                exc
            )

            _write_reconciliation_outputs(
                result=result,
                curve_comparison=None,
                beta_comparison=None,
                temporal_beta_comparison=None,
                output_dir=output_dir
            )

            return result

    # =====================================================
    # MODO NO SOPORTADO
    # =====================================================

    result = _not_run_result(
        reason=(
            "Modo de reconciliación no soportado: "
            f"{mode}"
        )
    )

    result["mode"] = mode.upper()

    _write_reconciliation_outputs(
        result=result,
        curve_comparison=None,
        beta_comparison=None,
        temporal_beta_comparison=None,
        output_dir=output_dir
    )

    return result