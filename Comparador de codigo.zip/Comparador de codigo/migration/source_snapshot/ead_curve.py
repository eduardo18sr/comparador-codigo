from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from ..strategies.base import ReconciliationStrategy, StrategyContext, StrategyDetection, write_component_csv


class EADCurveAdapter(ReconciliationStrategy):
    """Adaptador explícito para el caso EAD heredado.

    Este archivo conserva la lógica específica fuera del núcleo genérico.
    Solo debe activarse cuando el YAML seleccione adapter.name=ead_curve.
    """

    name = "ead_curve"
    title = "Curva EAD"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        config = context.config.get("adapter", {}) or {}
        enabled = config.get("name") == self.name
        return StrategyDetection(
            strategy=self.name,
            confidence=1.0 if enabled else 0.0,
            status="DETECTED" if enabled else "NOT_DETECTED",
            sheet=config.get("sheet"),
            payload={"adapter_config": config},
            reason=None if enabled else "El adaptador ead_curve no fue seleccionado explícitamente.",
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        try:
            config = detection.payload["adapter_config"]
            sheet = config.get("sheet")
            if not sheet or sheet not in context.workbook.sheetnames:
                return self.not_run("La hoja configurada para el adaptador EAD no existe.", detection)

            excel = config.get("excel", {})
            variables = excel.get("variables", {})
            ws = context.workbook[sheet]
            ws_values = context.workbook_values[sheet] if context.workbook_values else ws
            start_row = int(variables["start_row"])
            end_row = int(variables["end_row"])
            name_column = variables.get("name_column", "A")
            value_column = variables.get("value_column", "B")
            beta_column = variables.get("beta_column", "C")

            names = [str(ws[f"{name_column}{row}"].value).strip() for row in range(start_row, end_row + 1)]
            transformed = np.asarray([float(ws_values[f"{value_column}{row}"].value) for row in range(start_row, end_row + 1)])
            betas = np.asarray([float(ws_values[f"{beta_column}{row}"].value) for row in range(start_row, end_row + 1)])

            periods_cfg = excel["periods"]
            results_cfg = excel["expected_results"]
            periods = self._row_values(ws_values, periods_cfg)
            expected = self._row_values(ws_values, results_cfg)
            temporal = excel.get("temporal_betas", {})
            beta_ln_t = float(ws_values[temporal["ln_t"]].value)
            beta_h_ln_t = float(ws_values[temporal["h_ln_t"]].value)
            calculated = float(np.dot(transformed, betas)) + np.log(periods) * beta_ln_t + np.maximum(0.0, np.log(periods) - np.log(6.0)) * beta_h_ln_t

            tolerances = context.config.get("tolerances", {})
            atol = float(tolerances.get("absolute", 1e-10))
            rtol = float(tolerances.get("relative", 1e-9))
            within = np.isclose(calculated, expected, atol=atol, rtol=rtol)
            comparison = pd.DataFrame({
                "period": periods.astype(int),
                "expected": expected,
                "calculated": calculated,
                "absolute_difference": np.abs(calculated - expected),
                "within_tolerance": within,
            })
            artifact = write_component_csv(context, "adapter_ead_curve.csv", comparison)
            differences = int((~within).sum())
            return {
                "strategy": self.name,
                "title": self.title,
                "status": "MATCH" if differences == 0 else "DIVERGE",
                "confidence": detection.confidence,
                "comparisons": len(within),
                "matches": int(within.sum()),
                "differences": differences,
                "variables": names,
                "artifacts": [artifact],
            }
        except Exception as exc:
            return self.error(exc, detection)

    @staticmethod
    def _row_values(ws: Any, config: dict) -> np.ndarray:
        from openpyxl.utils.cell import column_index_from_string

        row = int(config["row"])
        start = column_index_from_string(str(config["start_column"]).upper())
        end = column_index_from_string(str(config["end_column"]).upper())
        return np.asarray([float(ws.cell(row, column).value) for column in range(start, end + 1)])
