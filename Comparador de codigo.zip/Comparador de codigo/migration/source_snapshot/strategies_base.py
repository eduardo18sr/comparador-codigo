from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


VALID_STATUSES = {
    "MATCH",
    "DIVERGE",
    "NOT_RUN",
    "ERROR",
}


@dataclass
class StrategyContext:
    workbook: Any
    workbook_values: Any | None = None
    excel_inventory: dict = field(default_factory=dict)
    rules: list[dict] = field(default_factory=list)
    project_root: Path | str = Path(".")
    project_candidates: list[dict] = field(default_factory=list)
    output_dir: Path | str = Path(".")
    config: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.project_root = Path(self.project_root)
        self.output_dir = Path(self.output_dir)


@dataclass
class StrategyDetection:
    strategy: str
    confidence: float
    status: str = "CANDIDATE"
    sheet: str | None = None
    evidence: list[dict] = field(default_factory=list)
    payload: dict = field(default_factory=dict)
    reason: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


class ReconciliationStrategy(ABC):
    name = "base"
    title = "Reconciliación"

    @abstractmethod
    def detect(self, context: StrategyContext) -> StrategyDetection:
        raise NotImplementedError

    @abstractmethod
    def reconcile(
        self,
        context: StrategyContext,
        detection: StrategyDetection,
    ) -> dict:
        raise NotImplementedError

    def not_run(self, reason: str, detection: StrategyDetection | None = None) -> dict:
        return {
            "strategy": self.name,
            "title": self.title,
            "status": "NOT_RUN",
            "reason": reason,
            "confidence": detection.confidence if detection else 0.0,
            "comparisons": 0,
            "matches": 0,
            "differences": 0,
            "artifacts": [],
        }

    def error(self, exc: Exception, detection: StrategyDetection | None = None) -> dict:
        return {
            "strategy": self.name,
            "title": self.title,
            "status": "ERROR",
            "reason": f"{type(exc).__name__}: {exc}",
            "confidence": detection.confidence if detection else 0.0,
            "comparisons": 0,
            "matches": 0,
            "differences": 0,
            "artifacts": [],
        }


def safe_float(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def normalized_name(value: Any) -> str:
    import re
    import unicodedata

    text = unicodedata.normalize("NFKD", str(value).strip().lower())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return re.sub(r"_+", "_", text).strip("_")


def write_component_csv(context: StrategyContext, name: str, dataframe: Any) -> str:
    artifacts_dir = context.output_dir / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    path = artifacts_dir / name
    dataframe.to_csv(path, index=False, encoding="utf-8-sig")
    return str(path)
