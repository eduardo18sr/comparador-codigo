from __future__ import annotations

import math
import re
from typing import Any

import numpy as np
import pandas as pd
from openpyxl.formula.tokenizer import Tokenizer

from .base import ReconciliationStrategy, StrategyContext, StrategyDetection, safe_float, write_component_csv


class ScalarFormulaStrategy(ReconciliationStrategy):
    name = "scalar_formula"
    title = "Reconciliación de resultados escalares"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        candidates = []
        for ws in context.workbook.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    if not (isinstance(cell.value, str) and cell.value.startswith("=")):
                        continue
                    cached = None
                    if context.workbook_values and ws.title in context.workbook_values.sheetnames:
                        cached = context.workbook_values[ws.title][cell.coordinate].value
                    label = self._nearest_label(ws, cell.row, cell.column)
                    if safe_float(cached) is None or label is None:
                        continue
                    candidates.append({
                        "sheet": ws.title,
                        "cell": cell.coordinate,
                        "formula": cell.value,
                        "cached_value": cached,
                        "label": label,
                    })
        confidence = min(0.95, 0.55 + 0.05 * len(candidates)) if candidates else 0.0
        return StrategyDetection(
            strategy=self.name,
            confidence=confidence,
            status="DETECTED" if candidates else "NOT_DETECTED",
            sheet=candidates[0]["sheet"] if candidates else None,
            evidence=[{"type": "scalar_formula_cells", "count": len(candidates)}],
            payload={"candidates": candidates},
            reason=None if candidates else "No se encontraron fórmulas escalares con valor cacheado y etiqueta.",
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        try:
            atol, rtol = self._tolerances(context)
            records = []
            for item in detection.payload.get("candidates", []):
                ws = context.workbook[item["sheet"]]
                calculated, reason = self._evaluate_supported_formula(ws, item["formula"])
                expected = safe_float(item["cached_value"])
                supported = calculated is not None and expected is not None
                within = bool(np.isclose(calculated, expected, atol=atol, rtol=rtol)) if supported else False
                records.append({
                    **item,
                    "recalculated_value": calculated,
                    "supported": supported,
                    "reason": reason,
                    "within_tolerance": within,
                })
            comparison = pd.DataFrame(records)
            supported = comparison[comparison["supported"]] if not comparison.empty else comparison
            comparisons = len(supported)
            matches = int(supported["within_tolerance"].sum()) if comparisons else 0
            differences = comparisons - matches
            status = "NOT_RUN" if comparisons == 0 else ("MATCH" if differences == 0 else "DIVERGE")
            artifact = write_component_csv(context, "strategy_scalar_formula.csv", comparison)
            return {
                "strategy": self.name,
                "title": self.title,
                "status": status,
                "confidence": detection.confidence,
                "comparisons": comparisons,
                "matches": matches,
                "differences": differences,
                "unsupported": len(comparison) - comparisons,
                "artifacts": [artifact],
            }
        except Exception as exc:
            return self.error(exc, detection)

    @staticmethod
    def _nearest_label(ws: Any, row: int, column: int) -> str | None:
        for offset in range(1, 4):
            candidate_column = column - offset
            if candidate_column > 0:
                value = ws.cell(row, candidate_column).value
                if isinstance(value, str) and value.strip() and not value.startswith("="):
                    return value.strip()
        value = ws.cell(row - 1, column).value if row > 1 else None
        return value.strip() if isinstance(value, str) and value.strip() else None

    def _evaluate_supported_formula(self, ws: Any, formula: str) -> tuple[float | None, str]:
        expression = formula.lstrip("=").strip()
        if re.search(r"[A-Za-z_][A-Za-z0-9_]*!", expression):
            return None, "Referencias entre hojas no soportadas por el evaluador seguro."
        tokenized = Tokenizer("=" + expression)
        built = []
        supported_functions = {"SUM", "PRODUCT", "ABS", "LN", "LOG", "EXP", "MAX", "MIN", "ROUND", "POWER", "SQRT"}
        for token in tokenized.items:
            value = token.value
            if token.type == "OPERAND" and token.subtype == "RANGE":
                if ":" in value:
                    cells = ws[value]
                    flat = [safe_float(cell.value) for row in cells for cell in row]
                    if any(item is None for item in flat):
                        return None, f"Rango no numérico: {value}"
                    built.append(repr(flat))
                else:
                    cell_value = safe_float(ws[value].value)
                    if cell_value is None:
                        return None, f"Celda no numérica: {value}"
                    built.append(repr(cell_value))
            elif token.type == "FUNC":
                name = value.rstrip("(").upper()
                if name and name not in supported_functions:
                    return None, f"Función no soportada: {name}"
                mapping = {"SUM": "sum", "PRODUCT": "product", "ABS": "abs", "LN": "ln", "LOG": "log", "EXP": "exp", "MAX": "max", "MIN": "min", "ROUND": "round", "POWER": "power", "SQRT": "sqrt"}
                built.append(mapping.get(name, "") + ("(" if value.endswith("(") else ")"))
            elif token.type == "SEP":
                built.append(",")
            elif token.type == "OPERATOR-INFIX":
                built.append("**" if value == "^" else value)
            elif token.type == "PAREN":
                built.append(value)
            elif token.type == "OPERAND" and token.subtype == "NUMBER":
                built.append(value)
            elif str(value).strip():
                built.append(value)
        safe_env = {
            "sum": lambda values: sum(values) if isinstance(values, list) else values,
            "product": lambda values: math.prod(values) if isinstance(values, list) else values,
            "abs": abs, "ln": math.log, "log": math.log, "exp": math.exp,
            "max": max, "min": min, "round": round, "power": pow, "sqrt": math.sqrt,
        }
        try:
            result = eval("".join(built), {"__builtins__": {}}, safe_env)
            return float(result), "Evaluada por el subconjunto seguro."
        except Exception as exc:
            return None, f"No evaluable: {type(exc).__name__}: {exc}"

    @staticmethod
    def _tolerances(context: StrategyContext) -> tuple[float, float]:
        config = context.config.get("tolerances", {})
        return float(config.get("absolute", 1e-8)), float(config.get("relative", 1e-6))
