from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .base import (
    ReconciliationStrategy,
    StrategyContext,
    StrategyDetection,
    normalized_name,
    safe_float,
    write_component_csv,
)


class ParameterTableStrategy(ReconciliationStrategy):
    name = "parameter_table"
    title = "Comparación de parámetros"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        blocks = self._excel_parameter_blocks(context)
        sources = self._parameter_sources(context)
        candidates = []

        for block in blocks:
            excel_names = {normalized_name(item["name"]) for item in block["records"]}
            if not excel_names:
                continue
            for source in sources:
                source_names = set(source["normalized_names"])
                overlap = excel_names & source_names
                name_coverage = len(overlap) / len(excel_names)
                if name_coverage == 0:
                    continue
                shape_bonus = 0.10 if source["orientation"] in {"wide", "long"} else 0.0
                score = min(1.0, name_coverage * 0.90 + shape_bonus)
                candidates.append({
                    "sheet": block["sheet"],
                    "block": block,
                    "source": source,
                    "name_coverage": name_coverage,
                    "confidence": score,
                })

        candidates.sort(key=lambda item: (-item["confidence"], item["source"]["path"]))
        if not candidates:
            return StrategyDetection(
                strategy=self.name,
                confidence=0.0,
                status="NOT_DETECTED",
                reason="No se encontró un bloque nombre-valor comparable con archivos de parámetros.",
            )

        best = candidates[0]
        return StrategyDetection(
            strategy=self.name,
            confidence=float(best["confidence"]),
            status="DETECTED",
            sheet=best["sheet"],
            evidence=[{
                "type": "name_overlap",
                "coverage": best["name_coverage"],
                "source": best["source"]["path"],
            }],
            payload={"candidate": best, "candidates": candidates[:20]},
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        try:
            candidate = detection.payload["candidate"]
            block = candidate["block"]
            source = candidate["source"]
            source_values = source["values"]
            atol, rtol = self._tolerances(context)
            rows = []

            for record in block["records"]:
                key = normalized_name(record["name"])
                excel_value = safe_float(record["value"])
                parameter_value = safe_float(source_values.get(key))
                mapped = key in source_values
                comparable = mapped and excel_value is not None and parameter_value is not None
                within = bool(np.isclose(excel_value, parameter_value, atol=atol, rtol=rtol)) if comparable else False
                rows.append({
                    "sheet": block["sheet"],
                    "excel_cell": record["value_cell"],
                    "excel_name": record["name"],
                    "parameter_file": source["path"],
                    "parameter_name": source["original_names"].get(key),
                    "excel_value": excel_value,
                    "parameter_value": parameter_value,
                    "mapped": mapped,
                    "comparable": comparable,
                    "within_tolerance": within,
                })

            comparison = pd.DataFrame(rows)
            comparable = comparison[comparison["comparable"]]
            comparisons = len(comparable)
            matches = int(comparable["within_tolerance"].sum()) if comparisons else 0
            differences = comparisons - matches
            status = "NOT_RUN" if comparisons == 0 else ("MATCH" if differences == 0 else "DIVERGE")
            artifact = write_component_csv(context, "strategy_parameter_table.csv", comparison)
            return {
                "strategy": self.name,
                "title": self.title,
                "status": status,
                "confidence": detection.confidence,
                "source": source["path"],
                "sheet": block["sheet"],
                "comparisons": comparisons,
                "matches": matches,
                "differences": differences,
                "name_coverage": candidate["name_coverage"],
                "artifacts": [artifact],
            }
        except Exception as exc:
            return self.error(exc, detection)

    def _excel_parameter_blocks(self, context: StrategyContext) -> list[dict]:
        blocks = []
        for ws in context.workbook.worksheets:
            current = []
            for row in range(1, ws.max_row + 1):
                name = ws.cell(row, 1).value
                value = ws.cell(row, 2).value
                if isinstance(name, str) and name.strip() and safe_float(value) is not None:
                    current.append({
                        "name": name.strip(),
                        "value": value,
                        "name_cell": ws.cell(row, 1).coordinate,
                        "value_cell": ws.cell(row, 2).coordinate,
                    })
                elif current:
                    if len(current) >= 3:
                        blocks.append({"sheet": ws.title, "records": current})
                    current = []
            if len(current) >= 3:
                blocks.append({"sheet": ws.title, "records": current})
        return blocks

    def _parameter_sources(self, context: StrategyContext) -> list[dict]:
        config = context.config.get("parameter_discovery", {})
        roots = config.get("search_paths", ["."])
        extensions = set(config.get("include_extensions", [".csv", ".json", ".yaml", ".yml"]))
        excluded = tuple(str(item).lower() for item in config.get("exclude_paths", []))
        max_bytes = int(config.get("max_file_bytes", 2_000_000))
        results = []

        for root_text in roots:
            base = Path(root_text)
            if not base.is_absolute():
                base = context.project_root / base
            paths = [base] if base.is_file() else base.rglob("*") if base.exists() else []
            for path in paths:
                if not path.is_file() or path.suffix.lower() not in extensions:
                    continue
                normalized_path = str(path).replace("\\", "/").lower()
                if any(token in normalized_path for token in excluded):
                    continue
                try:
                    if path.stat().st_size > max_bytes:
                        continue
                    dataframe = self._read_table(path)
                    parsed = self._to_name_value_map(dataframe)
                    if parsed:
                        parsed["path"] = str(path)
                        results.append(parsed)
                except Exception:
                    continue
        return results

    @staticmethod
    def _read_table(path: Path) -> pd.DataFrame:
        suffix = path.suffix.lower()
        if suffix == ".csv":
            return pd.read_csv(path, encoding="utf-8-sig")
        if suffix == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
        else:
            import yaml
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            try:
                return pd.DataFrame(data)
            except ValueError:
                return pd.DataFrame([data])
        return pd.DataFrame(data)

    @staticmethod
    def _to_name_value_map(df: pd.DataFrame) -> dict | None:
        if df.empty:
            return None
        df = df.copy()
        df.columns = [str(column).strip() for column in df.columns]
        if len(df) == 1:
            row = df.iloc[0]
            values = {normalized_name(col): row[col] for col in df.columns}
            originals = {normalized_name(col): col for col in df.columns}
            return {"orientation": "wide", "values": values, "original_names": originals, "normalized_names": list(values)}
        if len(df.columns) >= 2:
            first, second = df.columns[:2]
            values = {}
            originals = {}
            for _, row in df.iterrows():
                if pd.isna(row[first]):
                    continue
                key = normalized_name(row[first])
                values[key] = row[second]
                originals[key] = str(row[first])
            if values:
                return {"orientation": "long", "values": values, "original_names": originals, "normalized_names": list(values)}
        return None

    @staticmethod
    def _tolerances(context: StrategyContext) -> tuple[float, float]:
        config = context.config.get("tolerances", {})
        return float(config.get("absolute", 1e-8)), float(config.get("relative", 1e-6))
