from __future__ import annotations

import ast
from pathlib import Path

from .base import ReconciliationStrategy, StrategyContext, StrategyDetection


class ProductionFunctionStrategy(ReconciliationStrategy):
    name = "production_function"
    title = "Ejecución de función productiva"

    def detect(self, context: StrategyContext) -> StrategyDetection:
        config = context.config.get("function_discovery", {})
        allow_execution = bool(config.get("allow_execution", False))
        functions = []
        for path in context.project_root.rglob("*.py"):
            normalized_path = str(path).replace("\\", "/").lower()
            if any(token in normalized_path for token in ("/.git/", "/tests/", "/test/", "/.venv/", "/site-packages/")):
                continue
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source)
            except Exception:
                continue
            for node in ast.walk(tree):
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                arguments = [argument.arg for argument in node.args.args]
                return_shapes = self._return_shapes(node)
                functions.append({
                    "file": str(path),
                    "function": node.name,
                    "arguments": arguments,
                    "required_arguments": max(0, len(arguments) - len(node.args.defaults)),
                    "return_shapes": return_shapes,
                    "line": node.lineno,
                })
        mapped = [item for item in functions if self._is_explicitly_mapped(item, context)]
        confidence = 0.95 if mapped else 0.35 if functions else 0.0
        status = "DETECTED" if mapped else "NOT_DETECTED"
        reason = None if mapped else "Se encontraron funciones, pero no existe un contrato explícito y seguro de entradas/salidas."
        return StrategyDetection(
            strategy=self.name,
            confidence=confidence,
            status=status,
            evidence=[{"type": "python_functions", "count": len(functions), "safe_contracts": len(mapped)}],
            payload={"functions": functions[:500], "mapped_functions": mapped, "allow_execution": allow_execution},
            reason=reason,
        )

    def reconcile(self, context: StrategyContext, detection: StrategyDetection) -> dict:
        if not detection.payload.get("allow_execution", False):
            return self.not_run(
                "La ejecución dinámica está deshabilitada. Se requiere allow_execution=true y un contrato explícito.",
                detection,
            )
        mapped = detection.payload.get("mapped_functions", [])
        if not mapped:
            return self.not_run("No existe una función con contrato explícito de entradas y salidas.", detection)
        # La ejecución real se delega a un adaptador autorizado.
        return self.not_run(
            "La función fue identificada, pero la ejecución requiere un adaptador autorizado que construya entradas e interprete salidas.",
            detection,
        )

    @staticmethod
    def _return_shapes(node: ast.AST) -> list[str]:
        shapes = []
        for item in ast.walk(node):
            if isinstance(item, ast.Return):
                if isinstance(item.value, ast.Tuple):
                    shapes.append("tuple")
                elif isinstance(item.value, ast.Dict):
                    shapes.append("dict")
                elif isinstance(item.value, ast.List):
                    shapes.append("list")
                elif item.value is not None:
                    shapes.append(type(item.value).__name__)
        return sorted(set(shapes))

    @staticmethod
    def _is_explicitly_mapped(function: dict, context: StrategyContext) -> bool:
        contracts = context.config.get("function_discovery", {}).get("contracts", [])
        for contract in contracts:
            if contract.get("function") == function["function"] and contract.get("file") in function["file"]:
                function["contract"] = contract
                return True
        return False
