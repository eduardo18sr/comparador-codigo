from __future__ import annotations

from .strategies.base import (
    StrategyContext
)

from .strategies.parameter_table import (
    ParameterTableStrategy
)

from .strategies.scalar_formula import (
    ScalarFormulaStrategy
)

from .strategies.tabular_formula import (
    TabularFormulaStrategy
)

from .strategies.temporal_curve import (
    TemporalCurveStrategy
)

from .strategies.production_function import (
    ProductionFunctionStrategy
)

from .adapters.ead_curve import (
    EADCurveAdapter
)


def get_available_strategies(
    reconciliation_config: dict
):
    strategies = [
        ParameterTableStrategy(),
        ScalarFormulaStrategy(),
        TabularFormulaStrategy(),
        TemporalCurveStrategy(),
        ProductionFunctionStrategy()
    ]

    adapter_config = (
        reconciliation_config.get(
            "adapter"
        )
        or {}
    )

    if (
        adapter_config.get(
            "name"
        )
        == "ead_curve"
    ):
        strategies.append(
            EADCurveAdapter()
        )

    return strategies


def discover_reconciliation_strategy(
    context: StrategyContext
) -> dict:
    config = context.config.get(
        "strategy_discovery",
        {}
    )

    allowed_strategies = set(
        config.get(
            "allowed_strategies",
            [
                "parameter_table",
                "scalar_formula",
                "tabular_formula",
                "temporal_curve",
                "production_function"
            ]
        )
    )

    minimum_confidence = float(
        config.get(
            "minimum_confidence",
            0.80
        )
    )

    ambiguity_margin = float(
        config.get(
            "ambiguity_margin",
            0.03
        )
    )

    detections = []

    for strategy in get_available_strategies(
        context.config
    ):
        if (
            strategy.name
            not in allowed_strategies
            and strategy.name != "ead_curve"
        ):
            continue

        print(
            "[ESTRATEGIA] "
            f"Evaluando {strategy.name}",
            flush=True
        )

        try:
            detection = strategy.detect(
                context
            )

        except Exception as exc:
            detections.append({
                "strategy": strategy.name,
                "status": "ERROR",
                "confidence": 0.0,
                "reason": (
                    f"{type(exc).__name__}: {exc}"
                )
            })

            continue

        detections.append(
            detection.to_dict()
        )

        print(
            "[ESTRATEGIA] "
            f"{strategy.name}: "
            f"{detection.status} "
            f"| confianza={detection.confidence:.4f}",
            flush=True
        )

    eligible = [
        detection
        for detection in detections
        if detection.get(
            "status"
        )
        == "DETECTED"
    ]

    eligible.sort(
        key=lambda item: (
            -float(
                item.get(
                    "confidence",
                    0.0
                )
            ),
            item.get(
                "strategy",
                ""
            )
        )
    )

    if not eligible:
        return {
            "status": "NOT_SELECTED",
            "strategy": None,
            "confidence": 0.0,
            "reason": (
                "Ninguna estrategia identificó una "
                "estructura reconciliable."
            ),
            "candidates": detections
        }

    best = eligible[0]

    if (
        best.get(
            "confidence",
            0.0
        )
        < minimum_confidence
    ):
        return {
            "status": "LOW_CONFIDENCE",
            "strategy": None,
            "confidence": best.get(
                "confidence",
                0.0
            ),
            "best_candidate": best,
            "candidates": detections
        }

    if len(eligible) > 1:
        second = eligible[1]

        if (
            best["confidence"]
            - second["confidence"]
            <= ambiguity_margin
        ):
            return {
                "status": "AMBIGUOUS",
                "strategy": None,
                "confidence": best[
                    "confidence"
                ],
                "best_candidate": best,
                "second_candidate": second,
                "candidates": detections
            }

    return {
        "status": "SELECTED",
        "strategy": best[
            "strategy"
        ],
        "confidence": best[
            "confidence"
        ],
        "detection": best,
        "candidates": detections
    }