# HANDOFF_AS_IS.md

## 1. OBJETIVO ACTUAL
### Qué problema resuelve
Comparar implementaciones Excel contra código Python para determinar equivalencia funcional, semántica y, cuando aplica, numérica.

### Qué compara exactamente
- Reglas/fórmulas extraídas de Excel.
- Implementaciones encontradas en repositorios Python.
- Evidencia documental (Word/PDF cuando está disponible).

### Entradas soportadas realmente
CONFIRMADO:
- Excel (.xlsx)
- Código Python (repositorio)
- Reglas extraídas de Excel
NO CONFIRMADO:
- Cobertura completa para Word/PDF como fuente principal.

### Salidas
- Reporte Markdown.
- strategy_discovery.json
- reconciliation.json (referenciado en conversaciones).
- Evidencia de matching/no matching.

## 2. ESTADO ACTUAL
### Completas
- Inventariado de fórmulas.
- Matching semántico básico.
- Framework de estrategias.

### Parciales
- Strategy Discovery AUTO.
- Reconciliación numérica genérica.
- Adaptadores especializados.

### Faltantes
- Ejecución robusta multi-estrategia.
- Gobierno SDD.
- Contratos formales.

### Errores conocidos
- ImportError por exports en __init__.py.
- Strategy discovery retornando NOT_SELECTED.
- Reconciliación NOT_RUN para ciertos casos.

### Limitaciones
- Dependencia de heurísticas.
- Casos específicos aún influyen en diseño.

## 3. INVENTARIO DE ARCHIVOS
Solo confirmado por conversación:
- excel_code_compare/strategy_discovery.py: descubrimiento de estrategias.
- excel_code_compare/reconciliation.py: orquestación de reconciliación.
- excel_code_compare/cli.py: entrada principal.
- excel_code_compare/strategies/__init__.py: exportaciones.
- excel_code_compare/adapters/__init__.py: exportaciones.
- excel_code_compare/strategies/base.py: StrategyContext, StrategyDetection (inferido por imports observados).
- excel_code_compare/strategies/parameter_table.py
- excel_code_compare/strategies/scalar_formula.py
- excel_code_compare/strategies/tabular_formula.py
- excel_code_compare/strategies/temporal_curve.py
- excel_code_compare/strategies/production_function.py
- excel_code_compare/adapters/ead_curve.py
Estado detallado: NO CONFIRMADO.

## 4. FLUJO END-TO-END ACTUAL
Excel -> extracción de reglas -> inventario -> matching semántico -> strategy discovery -> reconciliación -> reporte.
Word/PDF: NO CONFIRMADO.

## 5. ARQUITECTURA REAL
Componentes observados:
- CLI
- Inventory/Mapping (módulos mencionados)
- Strategy Discovery
- Strategies
- Adapters
- Reconciliation
- Report

Separación exacta y dependencias completas: NO CONFIRMADO.

## 6. REGLAS DE NEGOCIO IMPLEMENTADAS
Confirmadas por reporte generado:
- Equivalencia de factor = 40/LN(2).
- Equivalencia función logística.
- Curvas temporales PD.
Varias reglas XL-0001..XL-0012 quedaron NO_VERIFICABLE o NO_LOCALIZADO.

## 7. HEURÍSTICAS Y HARDCODING
Confirmado:
- allowed_strategies = parameter_table, scalar_formula, tabular_formula, temporal_curve, production_function.
- minimum_confidence = 0.80.
- ambiguity_margin = 0.03.
Todo lo demás: NO CONFIRMADO.

## 8. MODELO DE DATOS
Confirmado:
- StrategyContext
- StrategyDetection
- detection.to_dict()
- strategy_discovery.json
- diccionarios de detección.
Resto: NO CONFIRMADO.

## 9. DEPENDENCIAS
Confirmado:
- Python
- Databricks
- openpyxl (mencionado previamente en proyecto)
Dependencias completas: NO CONFIRMADO.

## 10. PRUEBAS REALIZADAS
- Caso calculadora PYME: resultado NO DETERMINABLE.
- Strategy discovery: NOT_SELECTED, candidates=[].
- Verificación get_available_strategies(): 5 estrategias encontradas.

## 11. RESULTADOS VALIDADOS MANUALMENTE
- Existencia de 5 estrategias registradas.
- Problemas de import/export en __init__.py.
- Reporte con equivalencias XL-0002, XL-0004 y XL-0007.

## 12. DEUDA TÉCNICA
- Dependencia de exports manuales.
- Contratos incompletos.
- Arquitectura parcialmente acoplada a casos previos.
- Cobertura de pruebas insuficiente.

## 13. DECISIONES TOMADAS
- Avanzar hacia Spec-Driven Development.
- Usar enfoque Spec-Anchored recomendado.
- Evitar seguir parchando sin contratos.

## 14. ÁRBOL DEL REPOSITORIO ACTUAL
Ver CURRENT_REPOSITORY_TREE.txt.

## 15. COMANDOS DE EJECUCIÓN
Recarga observada:
importlib.reload(excel_code_compare.cli)

Resto: NO CONFIRMADO.

## 16. ARCHIVOS QUE DEBO DESCARGAR
Confirmados:
- Todo el directorio excel_code_compare.
- strategy_discovery.json.
- reportes generados.
- configuraciones CSV relacionadas.

## 17. PREGUNTAS ABIERTAS
- Estructura exacta del repositorio.
- Cobertura real Word/PDF.
- Contratos completos de datos.
- Dependencias exactas.
- Casos de prueba oficiales.
